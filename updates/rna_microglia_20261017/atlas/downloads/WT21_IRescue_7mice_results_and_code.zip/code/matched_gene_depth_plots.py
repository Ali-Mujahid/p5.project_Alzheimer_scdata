import csv,collections,statistics,math,pathlib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
p=pathlib.Path('work/IRescue_WT21_exclude_female1_20261029/results');prev=pathlib.Path('work/IRescue_Microglia_locus_20261028/results/same_set_mouse_expression.tsv');gene=pathlib.Path('work/IRescue_Microglia_DE_20261028/source_v4/gene_exposures.tsv')
def read(file):
 with file.open(newline='') as f:return list(csv.DictReader(f,delimiter='\t'))
genes={r['animal']:r for r in read(gene)};rows=[]
for r in read(prev):
 if r['method']!='IRescue' or (r['target']=='WT_21mo' and r['animal']=='WT_21mo_female_1'):continue
 g=genes[r['animal']];val=1e6*float(r['raw_set_count'])/float(g['gene_depth']);rows.append({'target':r['target'],'animal':r['animal'],'group':r['group'],'sex':r['sex'],'TE_expected_allocations':r['raw_set_count'],'matched_gene_UMIs':g['gene_depth'],'TE_per_million_matched_gene_UMIs':val})
for t in ['WT_6mo','WT_21mo','5xFAD_3mo','APOE4_TREM2_3mo']:
 z=[x for x in rows if x['target']==t];assert len(z)==(7 if t=='WT_21mo' else 8)
with (p/'four_comparisons_raw_matched_gene_depth_mouse_values.tsv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=rows[0].keys(),delimiter='\t',lineterminator='\n');w.writeheader();w.writerows(rows)
fig,axs=plt.subplots(2,2,figsize=(11,8),layout='constrained')
for ax,t in zip(axs.flat,['WT_6mo','WT_21mo','5xFAD_3mo','APOE4_TREM2_3mo']):
 for pos,g,color in [(0,'WT_3mo','#3288bd'),(1,t,'#d53e4f')]:
  rr=sorted([r for r in rows if r['target']==t and r['group']==g],key=lambda r:r['animal']);v=[r['TE_per_million_matched_gene_UMIs'] for r in rr]
  ax.boxplot([v],positions=[pos],widths=.5,patch_artist=True,showfliers=False,boxprops={'facecolor':color,'alpha':.25},medianprops={'color':'black'})
  for i,r in enumerate(rr):ax.scatter(pos+(i-(len(rr)-1)/2)*.08,r['TE_per_million_matched_gene_UMIs'],c=color,marker='^' if r['sex']=='male' else 'o',edgecolor='white',s=42,zorder=3)
 ax.set(xticks=[0,1],xticklabels=['WT_3mo',t],ylabel='TE allocations per million raw gene UMIs',title=t+(' · 3 target mice' if t=='WT_21mo' else ' · 4 target mice'));ax.tick_params(axis='x',rotation=12)
fig.suptitle('IRescue TE expression: same-nucleus raw gene-depth normalization\nWT_21mo_female_1 excluded only from WT_21mo; each point is one mouse',fontsize=12)
fig.savefig(p/'IRescue_four_comparisons_same_cell_gene_depth.pdf');fig.savefig(p/'IRescue_four_comparisons_same_cell_gene_depth.png',dpi=150);plt.close(fig)
# Direct normalization audit: identical seven mice and TE loci, two valid normalizations.
tmm=read(p/'four_comparisons_IRescue_mouse_values.tsv');rr=[r for r in rows if r['target']=='WT_21mo'];tt=[r for r in tmm if r['target']=='WT_21mo'];assert {r['animal'] for r in rr}=={r['animal'] for r in tt}
fig,axs=plt.subplots(1,2,figsize=(11,5),layout='constrained')
for ax,data,key,title in [(axs[0],rr,'TE_per_million_matched_gene_UMIs','Same-cell raw gene-depth normalization'),(axs[1],tt,'TE_per_million_gene_TMM_UMIs','Recomputed seven-mouse gene-TMM normalization')]:
 for pos,g,color in [(0,'WT_3mo','#3288bd'),(1,'WT_21mo','#d53e4f')]:
  r=sorted([x for x in data if x['group']==g],key=lambda x:x['animal']);v=[float(x[key]) for x in r];ax.boxplot([v],positions=[pos],widths=.5,patch_artist=True,showfliers=False,boxprops={'facecolor':color,'alpha':.25},medianprops={'color':'black'})
  for i,x in enumerate(r):ax.scatter(pos+(i-(len(r)-1)/2)*.09,float(x[key]),color=color,marker='^' if x['sex']=='male' else 'o',edgecolor='white',s=45)
 c=statistics.mean(float(x[key]) for x in data if x['group']=='WT_3mo');t=statistics.mean(float(x[key]) for x in data if x['group']=='WT_21mo');ax.set(title=f'{title}\nTarget/control mean ratio: {t/c:.3f}',xticks=[0,1],xticklabels=['WT_3mo','WT_21mo'],ylabel='TE allocations per million gene UMIs')
fig.suptitle('Same 7 mice and 9,725 TE intervals; normalization changes the comparison\nThe box center is a median; ratio in title uses mouse means',fontsize=12);fig.savefig(p/'WT21_same_mice_gene_depth_vs_gene_TMM.pdf');fig.savefig(p/'WT21_same_mice_gene_depth_vs_gene_TMM.png',dpi=150)
print('PASS raw matched gene normalization, seven WT21 mice and unchanged other group inputs')
