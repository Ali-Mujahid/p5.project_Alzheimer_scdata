args=commandArgs(trailingOnly=TRUE);stopifnot(length(args)==1);out=normalizePath(args[1]);suppressPackageStartupMessages({library(edgeR);library(rhdf5);library(jsonlite)})
P='/lisc/data/scratch/molecular_neurosciences/i-med/p5_Glial_TE_regulation_aging';root=file.path(P,'te-RNA/IRescue_Microglia_locus_20261028/results');src=file.path(P,'te-RNA/Microglia_WT21_exclude_female1_20261029');exclude='WT_21mo_female_1'
rd=function(p)read.delim(p,check.names=FALSE,stringsAsFactors=FALSE);put=function(x,n)write.table(x,file.path(out,n),sep='\t',row.names=FALSE,quote=FALSE,na='NA')
z=rd(gzfile(file.path(root,'IRescue_WT_3mo_vs_WT_21mo.TE_RNA_counts.tsv.gz'))); stopifnot(nrow(z)==9725,exclude %in% colnames(z));z=z[,colnames(z)!=exclude,drop=FALSE]
meta=rd(file.path(src,'gene_exposures.tsv'));Y=as.matrix(z[,-(1:8)]);storage.mode(Y)='double';ann=z[,1:8];rownames(Y)=ann$TE_locus
m=meta[match(colnames(Y),meta$animal),];stopifnot(identical(m$animal,colnames(Y)),ncol(Y)==7,!exclude%in%m$animal,all(is.finite(Y)),all(Y>=0),!anyDuplicated(rownames(Y)))
m$condition=factor(m$condition,levels=c('WT_3mo','WT_21mo'));m$sex=factor(m$sex,levels=c('female','male'));rownames(m)=m$animal
stopifnot(all(table(m$condition,m$sex)==matrix(c(2,1,2,2),nrow=2)));design=model.matrix(~sex+condition,m);stopifnot(qr(design)$rank==3,nrow(design)-ncol(design)==4)
put(z,'WT_3mo_vs_WT_21mo.IRescue_counts_7_mice.tsv');put(data.frame(animal=m$animal,design,check.names=FALSE),'WT21.design.tsv')
h5=file.path(P,'pre_processed_RNA/analysis_runs/RNA_ATAC_shared_gene_correspondence_20261021_v1/job-7529944/science/RNA/mouse_cluster_gene_pseudobulk.h5'); genes=h5read(h5,'Microglia22251_mouse_gene_counts'); animals=sort(unique(h5read(h5,'group_animal_id')));stopifnot(identical(dim(genes),c(55487L,20L)),length(animals)==20);colnames(genes)=animals;genes=genes[,m$animal,drop=FALSE];stopifnot(all(colSums(genes)==m$gene_depth))
gene=DGEList(genes);gene=calcNormFactors(gene,method='TMM');m$new_gene_TMM=gene$samples$norm.factors;m$new_gene_effective_depth=gene$samples$lib.size*gene$samples$norm.factors
sub=rd(file.path(root,'IRescue_locus_fit_subfamily_sums.tsv'));G=as.matrix(sub[,-1]);rownames(G)=sub[,1];storage.mode(G)='double';stopifnot(all(m$animal%in%colnames(G)),nrow(G)==1075);G=G[,m$animal,drop=FALSE];global=calcNormFactors(DGEList(G),method='TMMwsp');m$TE_TMMwsp_effective_depth=global$samples$lib.size*global$samples$norm.factors;put(m,'WT21.normalization_and_samples.tsv')
y0=DGEList(Y,lib.size=m$new_gene_effective_depth);keep=filterByExpr(y0,group=m$condition,min.count=5,min.total.count=15);stopifnot(sum(keep)>=30)
put(data.frame(ann,sweep(Y,2,m$new_gene_effective_depth,'/')*1e6,check.names=FALSE),'WT21.gene_TMM_CPM_7_mice.tsv')
summary=list()
for(nm in c('gene_TMM_primary','TE_TMMwsp_sensitivity')){
 exposure=if(nm=='gene_TMM_primary')m$new_gene_effective_depth else m$TE_TMMwsp_effective_depth
 y=DGEList(Y[keep,,drop=FALSE],lib.size=exposure);fit=glmQLFit(y,design,robust=TRUE,legacy=FALSE);test=glmQLFTest(fit,coef=3);res=topTags(test,n=Inf,sort.by='none')$table
 stopifnot(identical(rownames(res),rownames(Y)[keep]),all(is.finite(res$logFC)),all(is.finite(res$PValue)),all(res$PValue>=0 & res$PValue<=1))
 tab=cbind(ann,total_expected_count=rowSums(Y),mice_at_least_5=rowSums(Y>=5),status=ifelse(rowSums(Y)==0,'all_zero',ifelse(keep,'tested','low_expression')),log2FC=NA_real_,logCPM=NA_real_,QL_F=NA_real_,PValue=NA_real_,FDR=NA_real_,normalization=nm)
 tab[keep,c('log2FC','logCPM','QL_F','PValue','FDR')]=res[,c('logFC','logCPM','F','PValue','FDR')];stopifnot(max(abs(tab$FDR[keep]-p.adjust(tab$PValue[keep],'BH')))<1e-12)
 put(tab,paste0('WT21.',nm,'.all_TE_results.tsv'))
 for(q in c(.05,.10)){x=tab[!is.na(tab$FDR)&tab$FDR<q,,drop=FALSE];x=x[order(x$FDR),,drop=FALSE];put(x,paste0('WT21.',nm,'.FDR',if(q==.05)'005' else '010','.tsv'))}
 saveRDS(fit,file.path(out,paste0('WT21.',nm,'.fit.rds')))
 summary[[nm]]=data.frame(normalization=nm,TE_loci=nrow(Y),tested=sum(keep),all_zero=sum(rowSums(Y)==0),low_expression=sum(!keep & rowSums(Y)>0),up_FDR005=sum(res$FDR<.05&res$logFC>0),down_FDR005=sum(res$FDR<.05&res$logFC<0),up_FDR010=sum(res$FDR<.10&res$logFC>0),down_FDR010=sum(res$FDR<.10&res$logFC<0),min_P=min(res$PValue),min_FDR=min(res$FDR),residual_df=nrow(m)-ncol(design))
 pdf(file.path(out,paste0('WT21.',nm,'.QL_diagnostics.pdf')),width=10,height=5);par(mfrow=c(1,2));plotQLDisp(fit,main=paste(nm,'QL dispersion'));plotMD(test,main='WT21: excluding female 1');abline(h=0,lty=2);dev.off()
}
put(do.call(rbind,summary),'WT21.DE_summary.tsv');capture.output(sessionInfo(),file=file.path(out,'R_sessionInfo.txt'));write_json(list(status='completed',excluded=exclude,n_mice_control=4,n_mice_WT21=3,model='edgeR robust quasi-likelihood ~ sex + condition; residual df 4',test_scope='9725 fixed WT21 target-only peak-associated RepeatMasker TE intervals',primary='gene-derived TMM recalculated using only seven retained mice',sensitivity='TE TMMwsp recalculated on all 1075 IRescue locus-fit subfamilies using seven mice',fractional_counts_rounded=FALSE,other_contrasts_modified=FALSE),file.path(out,'models_COMPLETE.json'),auto_unbox=TRUE,pretty=TRUE)
