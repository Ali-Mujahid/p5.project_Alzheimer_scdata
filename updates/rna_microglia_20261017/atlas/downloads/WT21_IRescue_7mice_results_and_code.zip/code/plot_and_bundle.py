import csv,pathlib,collections,math,zipfile,hashlib
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
p=pathlib.Path('work/IRescue_WT21_exclude_female1_20261029');out=p/'results'; old=pathlib.Path('work/IRescue_Microglia_locus_20261028/results')
def read(path):
 with path.open(newline='') as f:return list(csv.DictReader(f,delimiter='\t'))
test=read(out/'WT21.gene_TMM_primary.all_TE_results.tsv'); counts=read(out/'WT_3mo_vs_WT_21mo.IRescue_counts_7_mice.tsv'); cpm=read(out/'WT21.gene_TMM_CPM_7_mice.tsv');m=read(out/'WT21.normalization_and_samples.tsv');byid={r['TE_locus']:r for r in cpm};assert len(counts)==len(test)==len(cpm)==9725 and len(byid)==9725 and len(m)==7 and not any(r['animal']=='WT_21mo_female_1' for r in m)
keys=list(counts[0]);animals=keys[8:];assert animals==[r['animal'] for r in m]
for r in test:assert r['TE_locus'] in byid
sig=[r for r in test if r['FDR']!='NA' and float(r['FDR'])<.1]; sig.sort(key=lambda r:float(r['FDR']));fig,axes=plt.subplots(1,2,figsize=(12,5),layout='constrained')
ax=axes[0]; plotted=[r for r in test if r['PValue']!='NA'];x=np.array([float(r['log2FC']) for r in plotted]); y=-np.log10(np.maximum([float(r['FDR']) for r in plotted],1e-300));col=['#d53e4f' if float(r['FDR'])<.05 and float(r['log2FC'])>0 else '#3288bd' if float(r['FDR'])<.05 else '#aaaaaa' for r in plotted];ax.scatter(x,y,c=col,s=14,alpha=.8);ax.axhline(-np.log10(.05),color='grey',linestyle='--');
for r in sig:ax.annotate(r['TE_subfamily'],(float(r['log2FC']),-np.log10(float(r['FDR']))),xytext=(4,-12),textcoords='offset points',fontsize=7)
ax.axvline(0,color='grey',linewidth=.6);ax.set(xlabel='log2 fold change (WT_21mo / WT_3mo)',ylabel='-log10 BH FDR',title=f'{len(plotted)} tested loci; {len(sig)} with FDR < 0.10')
ax=axes[1]
if sig:
 mat=np.array([[math.log2(1+float(byid[r['TE_locus']][a])) for a in animals] for r in sig]);means=mat.mean(axis=1,keepdims=True);sd=mat.std(axis=1,ddof=1,keepdims=True);mat=(mat-means)/np.where(sd>0,sd,1);im=ax.imshow(mat,cmap='RdBu_r',vmin=-2.5,vmax=2.5,aspect='auto');ax.set(xticks=range(7),xticklabels=animals,yticks=range(len(sig)),yticklabels=[r['TE_subfamily']+' | '+r['TE_locus'] for r in sig],title='FDR < 0.10 loci; row-scaled log2(1 + CPM)');ax.tick_params(axis='x',rotation=70,labelsize=7);ax.tick_params(axis='y',labelsize=7);fig.colorbar(im,ax=ax,label='Within-locus z-score')
else:ax.text(.5,.5,'No loci with FDR < 0.10',ha='center');ax.axis('off')
fig.suptitle('IRescue WT_21mo versus WT_3mo: female 1 excluded\nExploratory, sex-adjusted edgeR; three target and four control mice',fontsize=13);fig.savefig(out/'WT21_IRescue_updated_volcano_heatmap.pdf');fig.savefig(out/'WT21_IRescue_updated_volcano_heatmap.png',dpi=150);plt.close(fig)
previous=read(old/'same_set_mouse_expression.tsv'); keep_targets=['WT_6mo','WT_21mo','5xFAD_3mo','APOE4_TREM2_3mo']; rows=[]
for t in keep_targets:
 if t!='WT_21mo':
  for r in previous:
   if r['target']==t and r['method']=='IRescue':rows.append({'target':t,'animal':r['animal'],'group':r['group'],'sex':r['sex'],'TE_per_million_gene_TMM_UMIs':float(r['set_count_per_million_gene_UMIs']),'log2_1plus':float(r['log2_1plus_gene_normalized_set_expression']),'normalization':'original all-20 gene TMM, unchanged'})
 else:
  for meta in m:
   a=meta['animal']; raw=sum(float(r[a]) for r in counts);v=raw/float(meta['new_gene_effective_depth'])*1e6;rows.append({'target':t,'animal':a,'group':meta['condition'],'sex':meta['sex'],'TE_per_million_gene_TMM_UMIs':v,'log2_1plus':math.log2(1+v),'normalization':'gene TMM recalculated for 7 retained mice'})
with (out/'four_comparisons_IRescue_mouse_values.tsv').open('w') as f:w=csv.DictWriter(f,fieldnames=rows[0].keys(),delimiter='\t',lineterminator='\n');w.writeheader();w.writerows(rows)
fig,axs=plt.subplots(2,2,figsize=(11,8),layout='constrained')
for ax,t in zip(axs.flat,keep_targets):
 for pos,g,col in [(0,'WT_3mo','#3288bd'),(1,t,'#d53e4f')]:
  z=sorted([r for r in rows if r['target']==t and r['group']==g],key=lambda r:r['animal']);vals=[r['log2_1plus'] for r in z];assert len(z)==(3 if t=='WT_21mo' and g==t else 4)
  ax.boxplot([vals],positions=[pos],widths=.5,patch_artist=True,showfliers=False,boxprops={'facecolor':col,'alpha':.25},medianprops={'color':'black'})
  for i,r in enumerate(z):ax.scatter(pos+(i-(len(z)-1)/2)*.08,r['log2_1plus'],c=col,marker='^' if r['sex']=='male' else 'o',edgecolor='white',s=40)
 ax.set(xticks=[0,1],xticklabels=['WT_3mo',t],ylabel='log2(1 + TE / million gene-TMM UMIs)',title=t+(' · 3 target mice' if t=='WT_21mo' else ' · 4 target mice'));ax.tick_params(axis='x',rotation=12)
fig.suptitle('IRescue target-specific peak-bound TE sets\nWT_21mo_female_1 excluded only from WT_21mo; other comparisons unchanged',fontsize=12);fig.savefig(out/'four_comparisons_IRescue_updated_boxplots.pdf');fig.savefig(out/'four_comparisons_IRescue_updated_boxplots.png',dpi=150);plt.close(fig)
names=['WT_6mo','WT_21mo','5xFAD_3mo','APOE4_TREM2_3mo'];zip_path=out/'IRescue_four_comparisons_matrices_WT21_exclusion.zip'
with zipfile.ZipFile(zip_path,'w',compression=zipfile.ZIP_DEFLATED) as z:
 for t in names:
  name=f'IRescue_WT_3mo_vs_{t}.TE_RNA_counts.tsv';source=(out/'WT_3mo_vs_WT_21mo.IRescue_counts_7_mice.tsv') if t=='WT_21mo' else old/'Four_IRescue_TE_copy_count_matrices'/name;z.write(source,arcname=name)
 z.writestr('README.txt','WT_21mo comparison excludes WT_21mo_female_1; four controls and three WT_21mo mice. The other three matrices are byte-identical to the previous results. Counts are IRescue expected UMI-cluster allocations; fractional values are not observed integer transcripts.\n')
with zipfile.ZipFile(zip_path) as z:
 for t in names:
  name=f'IRescue_WT_3mo_vs_{t}.TE_RNA_counts.tsv';expected=(out/'WT_3mo_vs_WT_21mo.IRescue_counts_7_mice.tsv') if t=='WT_21mo' else old/'Four_IRescue_TE_copy_count_matrices'/name
  assert hashlib.sha256(z.read(name)).digest()==hashlib.sha256(expected.read_bytes()).digest()
print('PASS: seven WT21 animals; 9725 loci; other three raw matrices byte-identical; significant rows:',len(sig))
