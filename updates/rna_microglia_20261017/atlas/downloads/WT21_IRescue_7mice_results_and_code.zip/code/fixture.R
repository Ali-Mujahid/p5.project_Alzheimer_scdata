suppressPackageStartupMessages(library(edgeR));set.seed(428)
f=data.frame(sex=factor(c('female','female','male','male','female','male','male'),levels=c('female','male')),condition=factor(c(rep('control',4),rep('target',3)),levels=c('control','target')));d=model.matrix(~sex+condition,f);stopifnot(qr(d)$rank==3,nrow(d)-ncol(d)==4)
x=matrix(rnbinom(240*7,mu=80,size=20),240,7)+.125;x[1:30,5:7]=x[1:30,5:7]*8;x[31:60,5:7]=x[31:60,5:7]/8
y=DGEList(x,lib.size=rep(1e6,7));fit=glmQLFit(y,d,robust=TRUE,legacy=FALSE);test=glmQLFTest(fit,coef=3)$table;stopifnot(any(x%%1>0),median(test$logFC[1:30])>2,median(test$logFC[31:60])< -2,all(is.finite(test$PValue)));cat('PASS: 7-mouse fractional-count fixture, sex-adjusted design and effect directions\n')
