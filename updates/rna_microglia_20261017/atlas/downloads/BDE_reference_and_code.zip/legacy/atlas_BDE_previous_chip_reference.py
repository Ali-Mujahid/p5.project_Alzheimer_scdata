"""Build panel source tables using deposited mouse measurements and existing edgeR fits."""
from pathlib import Path
from xml.etree import ElementTree as ET
import zipfile, hashlib, json, gzip, shutil
import pandas as pd
import numpy as np

root = Path(__file__).resolve().parents[1]
out = root / "atlas_panels"
out.mkdir(exist_ok=True)
zhu = root.parent / "Zhu_microglia_TE_chromatin_states_20261123"
results = root / "results"
reference = root / "inputs/GSE218426_H3K27ac_ChIPseq_allNormTags.xlsx"
sizes = pd.read_csv(zhu/"source/mm10.chrom.sizes", sep="\t", header=None, index_col=0)[1]
ns = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
rows = []
with zipfile.ZipFile(reference) as workbook:
    strings = ["".join(s.itertext()) for s in ET.fromstring(workbook.read("xl/sharedStrings.xml"))]
    for _, row in ET.iterparse(workbook.open("xl/worksheets/sheet1.xml"), events=["end"]):
        if row.tag != ns + "row":
            continue
        values = {}
        for cell in row:
            val = cell.findtext(ns+"v")
            if val is not None:
                values[cell.get("r").rstrip("0123456789")] = strings[int(val)] if cell.get("t")=="s" else val
        if row.get("r") == "1":
            assert values["B"]=="Chr" and values["J"]=="Distance to TSS" and values["S"]=="Gene Type"
            assert all("Tag Count in 500 bp" in values[c] for c in ["T","U","V","W","X","Y","Z","AA"])
        elif "idr" in values.get("G","").lower() and values["B"] in sizes.index:
            chrom=values["B"]; start,end=int(values["C"]),int(values["D"])
            if 0 <= start < end <= sizes[chrom]:
                counts=[float(values[c]) for c in ["T","U","V","W","X","Y","Z","AA"]]
                assert all(x>=0 for x in counts)
                dist=pd.to_numeric(values.get("J"),errors="coerce")
                rows.append((chrom,start,end,values["A"],values["G"],dist,sum(counts),sum(x>0 for x in counts)))
        row.clear()
peaks=pd.DataFrame(rows,columns=["chr","start","end","reference_peak","IDR_source","distance_to_TSS","summed_normalized_tags","positive_libraries"])
peaks["distal_H3K27ac_supported"] = peaks.distance_to_TSS.abs().ge(3000) & peaks.positive_libraries.gt(0)
peaks.to_csv(out/"GSE218426_reference_peaks.tsv.gz",sep="\t",index=False,na_rep="NA")
d=pd.read_csv(results/"D_per_copy_states.tsv.gz",sep="\t").merge(
    pd.read_csv(results/"E_per_copy_age_overlap.tsv.gz",sep="\t"),on=["TE_locus","cluster_id"],validate="one_to_one")
loci=pd.read_csv(root/"inputs/Figure_C_copy_clusters.tsv.gz",sep="\t")
assert len(d)==len(loci)==267038 and d.TE_locus.is_unique
d=d.merge(loci,on=["TE_locus","cluster_id","chr","start","end"],validate="one_to_one")

def overlap(query, reference, use_midpoint=False):
    ans=pd.Series(0,index=query.index,dtype=int)
    for chrom,g in query.groupby("chr"):
        ref=reference.loc[reference.chr.eq(chrom)]
        starts=np.sort(ref.start.to_numpy()); ends=np.sort(ref.end.to_numpy())
        left=g.midpoint if use_midpoint else g.start
        right=left+1 if use_midpoint else g.end
        ans.loc[g.index]=np.searchsorted(starts,right,side="left")-np.searchsorted(ends,left,side="right")
    return ans

# Verify the interval convention against the prior project peak overlap at every ATAC region.
prior=pd.read_csv(root.parent/"ATAC_H3K27ac_TE_reanalysis_20261117/results/region_signals_clusters_overlap_H3corrected.tsv.gz",sep="\t",usecols=["chr","start","end","h3_overlap"])
assert np.array_equal(overlap(prior,peaks).gt(0),prior.h3_overlap)
distal=peaks[peaks.distal_H3K27ac_supported]
d["all_IDR_peak_overlaps"]=overlap(d,peaks)
d["distal_H3K27ac_peak_overlaps"]=overlap(d,distal)
d["midpoint_in_distal_H3K27ac_peak"]=overlap(d,distal,True).gt(0)
d.to_csv(out/"C1-C5_reference_by_copy.tsv.gz",sep="\t",index=False,na_rep="NA")
columns={"Promoter":d.regulatory_class.eq("Promoter"),
         "Distal H3K27ac":d.distal_H3K27ac_peak_overlaps.gt(0),
         "H3K27me3":d.regulatory_class.eq("Polycomb (H3K27me3)"),
         "H3K9me3":d.regulatory_class.eq("H3K9me3"),
         "No signal":d.regulatory_class.eq("No signal"),
         "All IDR sites":d.all_IDR_peak_overlaps.gt(0),
         "Distal midpoint":d.midpoint_in_distal_H3K27ac_peak}
summary=[]
for label, mask in columns.items():
    for group,g in d.groupby("cluster_id"):
        n=int(mask.loc[g.index].sum())
        summary.append(dict(cluster=group,feature=label,copies=n,total=len(g),value=100*n/len(g)))
pd.DataFrame(summary).to_csv(out/"Panel_D_values.tsv",sep="\t",index=False)
e=pd.read_csv(results/"E_age_enrichment.tsv",sep="\t")
for r in e.itertuples():
    group=d[d.cluster_id.eq(r.cluster_id)]
    assert len(group)==r.total and group.eligible_windows.gt(0).sum()==r.callable
    assert group[r.age_change].sum()==r.observed
    assert np.isclose(np.log2(r.observed/r.matched_expected),r.log2_observed_expected)
for src,name in [(results/"E_age_enrichment.tsv","Panel_E_values.tsv"),
                 (results/"E_matching_strata.tsv.gz","Panel_E_matching_strata.tsv.gz"),
                 (results/"D_state_fractions.tsv","Zhu_all_state_fractions.tsv"),
                 (zhu/"tables/GEO_state_crosswalk.tsv","Zhu_state_crosswalk.tsv"),
                 (root/"counts/mice.tsv","BDE_mice.tsv")]:
    shutil.copyfile(src,out/name)
for fn in ["rawP_summary.tsv","WT3_detected_rawP05_hits.tsv.gz","either_group_rawP05_hits.tsv.gz"]:
    shutil.copyfile(root/"genome_wide_WT3_detected_rawP"/fn,out/fn)
# Preserve every input row and the original full-precision number strings in manageable files.
shards=[]
source=root/"genome_wide_WT3_detected_padj"
cluster_total=0
for stem,origin in (("WT3_detected","WT3_detected_counts_and_padj"),("WT3_zero","WT3_zero_target_detected_counts_and_padj")):
    with gzip.open(source/(origin+".tsv.gz"),"rb") as src:
        header=src.readline()
        for i in range(1,100):
            first=src.readline()
            if not first: break
            name=f"TE_RNA_{stem}_{i:02d}.tsv.gz"
            with gzip.open(out/name,"wb",compresslevel=6) as dest:
                dest.write(header);dest.write(first);n=1
                while n<85000:
                    line=src.readline()
                    if not line:break
                    dest.write(line);n+=1
            shards.append(dict(name=name,rows=n))
            idx=header.decode().strip().split("\t").index("Figure_C_cluster")
            cluster_total+=pd.read_csv(out/name,sep="\t",usecols=[idx]).iloc[:,0].notna().sum()
assert cluster_total==len(d)
manifest=dict(shards=shards,source_sha256=hashlib.sha256(reference.read_bytes()).hexdigest(),
              IDR_peaks=len(peaks),distal_positive_peaks=len(distal),cluster_copies=len(d),checked_prior_regions=len(prior))
(out/"BDE_sources.json").write_text(json.dumps(manifest,indent=2)+"\n")
print(manifest)
print(pd.DataFrame(summary).query("feature=='Distal H3K27ac'").to_string(index=False))
