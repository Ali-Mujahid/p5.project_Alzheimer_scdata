"""Extract source counts with fixed Figure C membership and genome-wide model candidates."""
from pathlib import Path
from collections import Counter
import numpy as np
import pandas as pd
import gzip, json, shutil
out=Path(__file__).resolve().parents[1]
prior=out.parent/'Microglia_TE_RNA_ATAC_five_groups_20261123'
genome=prior/'tables/genome_mouse'
selected=prior/'two_panel/target_vs_WT3/higher_RNA_and_ATAC/tables/atlas_clusters/Microglia_TE_C1-C5.tsv.gz'
ids=pd.read_csv(selected,sep='\t',usecols=['TE_locus','cluster_id']).set_index('TE_locus').cluster_id
assert ids.index.is_unique
meta=pd.read_csv(genome/'RNA_mice.tsv',sep='\t')
shutil.copyfile(genome/'RNA_mice.tsv',out/'counts/mice.tsv')
samples=meta.animal.tolist()
cols=[s+'_RNA_expected_UMI' for s in samples]
ann=['TE_locus','chr','start','end','strand','TE_subfamily','TE_family','TE_class']
coverage=np.load(prior/'two_panel/data/per_mouse_TE_body_relative_coverage.npy',mmap_mode='r')
offset=0;filtered=[];selected_rows=[];background=[]
for d in pd.read_csv(genome/'TE_copy_matrix.tsv.gz',sep='\t',usecols=ann+cols,chunksize=100000):
    y=d[cols].to_numpy()
    assert np.isclose(np.nansum(y[y<0]),0) and np.isfinite(y[~np.isnan(y)]).all()
    assert np.array_equal(np.isnan(y),d.chr.eq('chrY').to_numpy()[:,None]&meta.sex.eq('female').to_numpy()[None,:])
    ysum=np.nansum(y,axis=1)
    cluster=d.TE_locus.map(ids)
    found=cluster.notna()
    q=d.loc[found,ann+cols].copy()
    q.insert(0,'cluster_id',cluster[found])
    selected_rows.append(q)
    pre=ysum>=14.999999
    filtered.append(d.loc[pre,['TE_locus','chr']+cols])
    active=(ysum>0)&(coverage[offset:offset+len(d)]>0).any(axis=1)
    assert (active|~found).all()
    q=d.loc[active,['TE_locus','chr','start','end','TE_family','TE_class']].copy()
    q['cluster_id']=cluster[active].fillna('background')
    background.append(q)
    offset+=len(d)
assert offset==len(coverage)==3651522
sel=pd.concat(selected_rows).set_index('TE_locus').loc[ids.index].reset_index()
assert (sel.cluster_id.to_numpy()==ids.to_numpy()).all() and len(sel)==267038
rename=dict(zip(cols,samples))
for cid,d in sel.groupby('cluster_id'):
    d=d.set_index('TE_locus')[cols].rename(columns=rename)
    d.to_csv(out/f'counts/{cid}.IRescue_expected.tsv.gz',sep='\t',float_format='%.12g',na_rep='NA')
    d.round().astype('Int64').to_csv(out/f'counts/{cid}.DESeq2_rounded.tsv.gz',sep='\t',na_rep='NA')
pd.concat(filtered).rename(columns=rename).to_csv(out/'inputs/genome_prefilter.tsv.gz',sep='\t',index=False,na_rep='NA',float_format='%.12g')
bg=pd.concat(background)
assert bg.TE_locus.is_unique
bg.to_csv(out/'inputs/assay_detected_background.tsv.gz',sep='\t',index=False)
print('Genome rows',offset,'>=15-total candidates',sum(map(len,filtered)),'C1-C5',len(sel),'background',len(bg))
