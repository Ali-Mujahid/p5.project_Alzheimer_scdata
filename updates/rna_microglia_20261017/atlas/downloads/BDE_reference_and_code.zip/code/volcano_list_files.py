"""Precompute the 0.05 downloads from the genome-wide fits and their original BH correction."""
from pathlib import Path
import pandas as pd, numpy as np, zipfile
root=Path(__file__).resolve().parents[1]
out=root/"atlas_zhu_volcano"
f=root/"atlas_panels/either_group_rawP05_hits.tsv.gz"
all_hits=pd.read_csv(f,sep="\t",dtype=str,keep_default_na=False)
rows=[]
for target,short in [("WT_21mo","WT21"),("5xFAD_3mo","5xFAD")]:
    hits=all_hits[all_hits.target_vs_WT_3mo.eq(target)].copy()
    assert hits.TE_locus.is_unique and hits.PValue.astype(float).lt(.05).all()
    with zipfile.ZipFile(out/f"{short}_vs_WT3_volcano_TE_lists.zip","w",compression=zipfile.ZIP_DEFLATED) as z:
        counts=[]
        for scope in ["WT3","either","clusters","C1","C2","C3","C4","C5"]:
            if scope=="WT3": chosen=hits[hits.WT_3mo_positive_mice.astype(int)>0]
            elif scope=="either":chosen=hits
            elif scope=="clusters":chosen=hits[hits.Figure_C_cluster.isin(["C1","C2","C3","C4","C5"])]
            else: chosen=hits[hits.Figure_C_cluster.eq(scope)]
            for measure,col in [("raw","PValue"),("BH","padj")]:
                d=chosen[chosen[col].astype(float)<.05].copy()
                d["scope"]=scope;d["significance_measure"]=measure;d["cutoff"]="0.05"
                d=d.iloc[np.argsort(d[col].astype(float),kind="stable")]
                assert np.array_equal(d.direction.eq("up"),d.logFC.astype(float)>0)
                stem=f"{scope}/{measure}_P_lt_0.05"
                z.writestr(stem+".tsv",d.to_csv(sep="\t",index=False))
                z.writestr(stem+".csv",d.to_csv(index=False))
                bed=d.assign(score=0)[["chr","start","end","TE_locus","score","strand"]]
                bed=bed.iloc[np.lexsort((bed.end.astype(int),bed.start.astype(int),bed.chr))]
                z.writestr(stem+".bed",bed.to_csv(index=False,header=False,sep="\t"))
                counts.append(dict(scope=scope,measure=measure,up=d.direction.eq("up").sum(),down=d.direction.eq("down").sum(),total=len(d)))
                if scope=="WT3" and measure=="raw":d.to_csv(out/f"{short}_vs_WT3_default_rawP05.tsv.gz",index=False,sep="\t")
        z.writestr("summary.tsv",pd.DataFrame(counts).to_csv(index=False,sep="\t"))
        z.writestr("README.txt",f"Microglial TE RNA, {target} versus WT_3mo. Each folder corresponds to a volcano TE set. WT3 selects all copies detected in at least one young control; either includes any tested copy in the pair. Counts use fractional IRescue per mouse. raw uses nominal P and BH uses the genome-wide adjusted P, both strictly below 0.05. TSV and CSV include source model statistics and mouse counts. BED6 has mm10 half-open coordinates, locus ID, unused score 0 and strand. Empty results have a header in tabular formats and zero BED intervals. Density and display-only dot spread preserve locus membership. See BDE_methods.md in the atlas.\n")
