"""Annotate the Figure C loci against mouse microglial ChromHMM and aging CpG calls."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
out=Path(__file__).resolve().parents[1]
dest=out/'results'
zhu=out.parent/'Zhu_microglia_TE_chromatin_states_20261123'
d=pd.read_csv(out/'inputs/assay_detected_background.tsv.gz',sep='\t')
selected=d.cluster_id.ne('background')
d['midpoint']=d.start+(d.end-d.start)//2
s=pd.read_csv(zhu/'source/cluster20_dense.bed',sep='\t',header=None,skiprows=1,
              usecols=[0,1,2,3],names=['chr','start','end','state'])
cross=pd.read_csv(zhu/'tables/GEO_state_crosswalk.tsv',sep='\t')
classes=['Uncalled','Promoter','Enhancer','Polycomb (H3K27me3)','H3K9me3','No signal']
code=np.array([0,1,1,2,2,3,4,5,5])
d['dense']=0
for chrom,g in d[selected].groupby('chr'):
    b=s[s.chr==chrom].sort_values('start')
    if b.empty:continue
    starts,ends=b.start.to_numpy(),b.end.to_numpy()
    assert np.all(starts[1:]>=ends[:-1])
    pos=g.midpoint.to_numpy()
    ix=np.searchsorted(starts,pos,side='right')-1
    ok=(ix>=0)&(pos<ends[ix])
    d.loc[g.index[ok],'dense']=b.state.to_numpy()[ix[ok]]
ann=d.loc[selected,['cluster_id','TE_locus','chr','start','end','midpoint','dense']].copy()
ann['native_state']=ann.dense.map(cross.set_index('dense').figure_label_used).fillna('Uncalled')
ann['regulatory_class']=np.array(classes)[code[ann.dense]]
ann.to_csv(dest/'D_per_copy_states.tsv.gz',sep='\t',index=False)
counts=pd.crosstab(ann.cluster_id,ann.regulatory_class).reindex(columns=classes,fill_value=0)
stats=counts.stack().rename('copies').reset_index()
stats['all_cluster_copies']=stats.cluster_id.map(counts.sum(axis=1))
stats['called_copies']=stats.cluster_id.map(counts.iloc[:,1:].sum(axis=1))
stats['fraction_all']=stats.copies/stats.all_cluster_copies
stats['fraction_called']=(stats.copies/stats.called_copies).where(stats.regulatory_class!='Uncalled')
stats.to_csv(dest/'D_state_fractions.tsv',sep='\t',index=False,na_rep='NA')

# Keep all 1-kb tiles with adequate data at the two endpoint ages, including tiles
# measured at those endpoints but missing at the intermediate age.
ages=['8wk','18mo']
fields=['chrom','start','end']+[f'{v}_{a}' for a in ages for v in ['methylated_calls','total_calls','CpG_call_records']]
bins=[]
for chunk in pd.read_csv(out/'inputs/mCG_1kb_all_ages.tsv.gz',sep='\t',usecols=fields,chunksize=170000):
    valid=np.logical_and.reduce([(chunk['total_calls_'+a]>=20)&(chunk['CpG_call_records_'+a]>=3) for a in ages])
    b=chunk[valid].copy()
    assert (b.end-b.start==1000).all() and (b.start%1000==0).all()
    n0,n1=[b['total_calls_'+a].to_numpy(dtype=np.int64) for a in ages]
    m0,m1=[b['methylated_calls_'+a].to_numpy(dtype=np.int64) for a in ages]
    ten_diff=10*(m1*n0-m0*n1)
    b['hypo']=ten_diff<=-(n0*n1);b['hyper']=ten_diff>=n0*n1
    bins.append(b[['chrom','start','end','hypo','hyper']])
tiles=pd.concat(bins,ignore_index=True)
assert not tiles.duplicated(['chrom','start']).any() and not (tiles.hypo&tiles.hyper).any()
d['eligible_windows']=0
for col in ['hypo','hyper']: d[col]=False
for chrom,g in d.groupby('chr'):
    b=tiles[tiles.chrom==chrom].sort_values('start')
    if b.empty:continue
    first=np.searchsorted(b.end,g.start,side='right');last=np.searchsorted(b.start,g.end,side='left')
    d.loc[g.index,'eligible_windows']=last-first
    for col in ['hypo','hyper']:
        prefix=np.r_[0,b[col].cumsum()]
        d.loc[g.index,col]=(prefix[last]-prefix[first])>0
    # Independent coordinate lookup across a deterministic sample of full TE spans.
    vals={v.start:(v.hypo,v.hyper) for v in b.itertuples()}
    for i in g.sample(min(12,len(g)),random_state=42).index:
        hits=[vals[k] for k in range(d.at[i,'start']//1000*1000,d.at[i,'end'],1000) if k in vals]
        assert len(hits)==d.at[i,'eligible_windows'] and all(any(v[j] for v in hits)==d.at[i,c] for j,c in enumerate(['hypo','hyper']))
eligible=d[d.eligible_windows>0].copy()
eligible['length_bin']=np.searchsorted([100,200,400,800,1600,3200,6400],eligible.end-eligible.start,side='right')
eligible['callable_span']=np.minimum(eligible.eligible_windows,3)
strata=['chr','TE_class','TE_family','length_bin','callable_span']
agg=eligible.groupby(strata,dropna=False).agg(background=('TE_locus','size'),hypo_n=('hypo','sum'),hyper_n=('hyper','sum'))
q=eligible[eligible.cluster_id!='background']
matches=q.groupby(['cluster_id']+strata,dropna=False).size().rename('cluster_copies').reset_index().join(agg,on=strata,validate='many_to_one')
matches.to_csv(dest/'E_matching_strata.tsv.gz',sep='\t',index=False)
report=[]
for label,g in matches.groupby('cluster_id'):
    copies=q[q.cluster_id==label]
    for col in ['hypo','hyper']:
        observed=int(copies[col].sum())
        expected=(g.cluster_copies*g[col+'_n']/g.background).sum()
        report.append(dict(cluster_id=label,age_change=col,total=int((d.cluster_id==label).sum()),callable=len(copies),
            observed=observed,matched_expected=expected,fraction_observed=observed/len(copies),fraction_expected=expected/len(copies),
            log2_observed_expected=np.log2(observed/expected)))
pd.DataFrame(report).to_csv(dest/'E_age_enrichment.tsv',sep='\t',index=False)
per=d.loc[selected,['cluster_id','TE_locus','eligible_windows','hypo','hyper']].copy()
per=per.astype({'hypo':'boolean','hyper':'boolean'})
per.loc[per.eligible_windows==0,['hypo','hyper']]=pd.NA
per.to_csv(dest/'E_per_copy_age_overlap.tsv.gz',sep='\t',index=False,na_rep='NA')
(dest/'reference_QC.json').write_text(json.dumps(dict(reference_tiles=len(tiles),hypo_tiles=int(tiles.hypo.sum()),hyper_tiles=int(tiles.hyper.sum()),
   reference_eligible_background=len(eligible),assay_detected_background=len(d),D_calls=int((ann.dense!=0).sum()),all_clusters=len(ann),
   E_callable=int(len(q)),E_excluded_chrY=int((ann.chr=='chrY').sum())),indent=2)+'\n')
print(counts.to_string(),pd.DataFrame(report).round(4).to_string(index=False),sep='\n')
