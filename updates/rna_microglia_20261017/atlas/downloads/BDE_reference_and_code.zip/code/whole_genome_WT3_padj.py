"""Genome-wide edgeR BH volcanoes for WT3-detected copies and for all testable copies."""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import numpy as np
import pandas as pd
from scipy.stats import false_discovery_control


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "genome_wide_WT3_detected_padj"
OUT.mkdir(exist_ok=True)
GROUPS = ["WT_3mo", "WT_21mo", "5xFAD_3mo"]
TITLES = {"WT_21mo": "WT 21 mo vs WT 3 mo", "5xFAD_3mo": "5xFAD 3 mo vs WT 3 mo"}
ANN = ["chr", "start", "end", "strand", "TE_subfamily", "TE_family", "TE_class"]
meta = pd.read_csv(ROOT / "counts/mice.tsv", sep="\t").set_index("animal")
mice = meta.index.tolist()
rna = pd.read_csv(ROOT / "inputs/any_RNA_genome.tsv.gz", sep="\t").set_index("TE_locus")
assert rna.index.is_unique and rna[mice].sum(axis=1).gt(0).all()
assert np.array_equal(rna[mice].isna(), np.outer(rna.chr.eq("chrY"), meta.sex.eq("female")))
assert not rna[mice].lt(0).any().any()
for group in GROUPS:
    cols = meta.index[meta.condition.eq(group)]
    rna[group + "_positive_mice"] = rna[cols].gt(0).sum(axis=1)
wt = rna.WT_3mo_positive_mice.gt(0)

# Recover mm10 annotations from the original matrix, then check the WT3 detection definition there.
genome = ROOT.parent / "Microglia_TE_RNA_ATAC_five_groups_20261123/tables/genome_mouse/TE_copy_matrix.tsv.gz"
parts = []
all_rows = 0
for chunk in pd.read_csv(genome, sep="\t", usecols=["TE_locus", *ANN, "WT_3mo_RNA_expected_UMI"],
                         chunksize=150000):
    all_rows += len(chunk)
    active = chunk.TE_locus.isin(rna.index)
    assert active[chunk.WT_3mo_RNA_expected_UMI.gt(0)].all()
    parts.append(chunk.loc[active])
ann = pd.concat(parts).set_index("TE_locus").loc[rna.index]
assert ann.index.is_unique and ann.chr.equals(rna.chr) and ann.WT_3mo_RNA_expected_UMI.gt(0).equals(wt)
master = ann[ANN].join(rna.drop(columns="chr"))
clusters = pd.read_csv(ROOT / "inputs/Figure_C_copy_clusters.tsv.gz", sep="\t",
                       usecols=["TE_locus", "cluster_id"]).set_index("TE_locus")
master["Figure_C_cluster"] = clusters.cluster_id.reindex(master.index)
plots = {}
summary = []
hit_frames = []
for target in GROUPS[1:]:
    pieces = []
    for scope in ["mixed", "males"]:
        path = ROOT / "results/all_models" / f"{target}.{scope}.edgeR.tsv.gz"
        d = pd.read_csv(path, sep="\t").set_index("TE_locus")
        assert (d.index.str.startswith("chrY:") == (scope == "males")).all()
        pieces.append(d)
    fit = pd.concat(pieces, verify_integrity=True)
    eligible = wt | rna[target + "_positive_mice"].gt(0)
    assert fit.index.sort_values().equals(rna.index[eligible].sort_values())
    assert fit.PValue.between(0, 1, inclusive="right").all() and np.isfinite(fit.logFC).all()
    fit["padj"] = false_discovery_control(fit.PValue, method="bh")
    assert fit.padj.ge(fit.PValue - 1e-15).all()
    for field in ["logFC", "PValue", "padj"]:
        master[f"{target}_vs_WT_3mo_{field}"] = fit[field].reindex(master.index)
    # Independently compare shared loci to the genome-wide BH values already exported for C1–C5.
    for cluster in ["C1", "C2", "C3", "C4", "C5"]:
        prev = pd.read_csv(ROOT / "all_copies/tables" / cluster / target / "All_TE_results.tsv.gz",
                           sep="\t", usecols=["TE_locus", "edgeR_contrast_BH"]).set_index("TE_locus")
        assert np.allclose(fit.padj.reindex(prev.index), prev.edgeR_contrast_BH,
                           atol=1e-12, rtol=1e-12, equal_nan=True)
    for name, d in [("WT3_detected", fit.loc[wt.reindex(fit.index)]), ("either_group", fit)]:
        plots[name, target] = d
        summary.append(dict(scope=name, target=target, annotated_copies=all_rows, BH_tests=len(fit),
                            plotted=len(d), WT3_detected=int(wt.reindex(d.index).sum()),
                            both_groups_detected=int((wt & rna[target + "_positive_mice"].gt(0)).reindex(d.index).sum()),
                            up_FDR05=int((d.padj.lt(.05) & d.logFC.gt(0)).sum()),
                            down_FDR05=int((d.padj.lt(.05) & d.logFC.lt(0)).sum()),
                            up_FDR10=int((d.padj.lt(.10) & d.logFC.gt(0)).sum()),
                            down_FDR10=int((d.padj.lt(.10) & d.logFC.lt(0)).sum()),
                            median_padj=d.padj.median()))
    hits = fit.loc[fit.padj.lt(.1), ["logFC", "PValue", "padj"]].sort_values(["padj", "PValue"])
    out = hits.join(master[ANN + ["Figure_C_cluster"] + [g + "_positive_mice" for g in GROUPS] + mice])
    out.insert(0, "contrast", target + "_vs_WT_3mo")
    out.insert(1, "WT3_detected", wt.reindex(out.index))
    out.insert(2, "test_cohort", np.where(out.chr.eq("chrY"), "males only", "sex-adjusted"))
    hit_frames.append(out)

summary = pd.DataFrame(summary)
summary.to_csv(OUT / "padj_summary.tsv", sep="\t", index=False)
hits = pd.concat(hit_frames)
hits.to_csv(OUT / "all_either_group_hits_FDR10.tsv", sep="\t", na_rep="NA")
hits.loc[hits.WT3_detected & hits.padj.lt(.05)].to_csv(OUT / "WT3_detected_hits_FDR05.tsv",
                                                      sep="\t", na_rep="NA")

# Keep primary and complementary copies in disjoint downloads. Together they give the full tests.
for name, mask in [("WT3_detected_counts_and_padj", wt), ("WT3_zero_target_detected_counts_and_padj", ~wt)]:
    master.loc[mask].to_csv(OUT / f"{name}.tsv.gz", sep="\t", na_rep="NA",
                            compression={"method": "gzip", "compresslevel": 3})

plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8.5, "pdf.fonttype": 42,
                     "axes.spines.top": False, "axes.spines.right": False, "axes.linewidth": .65,
                     "axes.labelcolor": "#20272c", "text.color": "#20272c"})
red, blue, grey = "#d53e4f", "#3288bd", "#bfc3c6"
for name, subtitle in [
        ("WT3_detected", "TE copies with RNA detected in at least one WT 3 mo mouse"),
        ("either_group", "TE copies with RNA detected in either group of each comparison")]:
    fig, axes = plt.subplots(1, 2, figsize=(7.65, 4.45), sharex=True, sharey=True)
    fig.subplots_adjust(left=.10, right=.974, bottom=.245, top=.726, wspace=.16)
    fig.text(.10, .94, "Genome-wide microglial TE RNA", size=14, weight="bold")
    fig.text(.10, .875, subtitle, size=9.2, color="#48565c")
    for ax, (target, title) in zip(axes, TITLES.items()):
        d = plots[name, target]
        sig = d.padj.lt(.05)
        y = -np.log10(d.padj)
        assert d.logFC.abs().max() < 6 and y.max() < 3.65
        ax.axhline(-np.log10(.05), color="#60686c", lw=.7, ls=(0, (4, 3)), zorder=0)
        ax.axvline(0, color="#c4c8ca", lw=.55, zorder=0)
        ax.scatter(d.loc[~sig, "logFC"], y[~sig], s=.65, c=grey, linewidths=0, rasterized=True)
        for locus, row in d.loc[sig].iterrows():
            color = red if row.logFC > 0 else blue
            ax.scatter(row.logFC, y.loc[locus], s=13, color=color, linewidths=0, zorder=3)
            ax.annotate(locus.rsplit(":", 1)[1], (row.logFC, y.loc[locus]),
                        xytext=(5 if row.logFC < 0 else -5, 5), textcoords="offset points",
                        color=color, ha="left" if row.logFC < 0 else "right", fontsize=8, weight="bold")
        ax.set(xlim=(-6, 6), ylim=(-.055, 3.65), xticks=[-6,-3,0,3,6], yticks=[0,1,2,3])
        ax.text(0, 1.16, title, transform=ax.transAxes, size=10.5, weight="bold")
        ax.text(0, 1.045, f"{len(d):,} copies   ·   {(sig & d.logFC.gt(0)).sum()} up   ·   {(sig & d.logFC.lt(0)).sum()} down",
                transform=ax.transAxes, color="#48565c")
        ax.tick_params(length=3, width=.65)
    axes[0].set_ylabel("−log₁₀(BH-adjusted P)")
    fig.text(.54, .147, "TE RNA log₂ fold change (target / WT 3 mo)", ha="center", fontsize=9)
    handles = [Line2D([], [], ls="none", marker="o", ms=4.3, color=c, markeredgewidth=0, label=l)
               for c,l in [(red,"Up (FDR < 0.05)"), (blue,"Down (FDR < 0.05)"), (grey,"FDR ≥ 0.05")]]
    fig.legend(handles=handles, loc="center", bbox_to_anchor=(.535,.068),
               ncol=3, frameon=False, columnspacing=1.5, handletextpad=.2)
    for ext in ["pdf", "png"]:
        fig.savefig(OUT / f"{name}_padj_volcano.{ext}", dpi=600, facecolor="white")
    plt.close(fig)
