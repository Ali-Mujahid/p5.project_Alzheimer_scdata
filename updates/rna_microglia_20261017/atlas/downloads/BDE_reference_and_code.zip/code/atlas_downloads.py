"""Build convenient cluster subsets and the covered reference intervals behind panel E."""
import gzip,json,shutil,zipfile
from pathlib import Path
import pandas as pd, numpy as np
root=Path(__file__).resolve().parents[1]; out=root/"atlas_panels"
manifest=json.loads((out/"BDE_sources.json").read_text())
for i,shard in enumerate(manifest["shards"]):
    d=pd.read_csv(out/shard["name"],sep="\t",dtype=str,keep_default_na=False)
    for cluster in ["C1","C2","C3","C4","C5"]:
        rows=d[d.Figure_C_cluster==cluster]
        name=out/f"TE_RNA_{cluster}_counts_and_edgeR.tsv.gz"
        with gzip.open(name, "wt" if i==0 else "at") as stream:
            rows.to_csv(stream,sep="\t",header=i==0,index=False)
cols=["chrom","start","end"]+[f"{f}_{a}" for a in ["8wk","18mo"] for f in ["methylated_calls","total_calls","CpG_call_records"]]
n=0; hypo=0; hyper=0; opened=set()
for d in pd.read_csv(root/"inputs/mCG_1kb_all_ages.tsv.gz",usecols=cols,sep="\t",chunksize=150000):
    d=d.loc[(d.total_calls_8wk>=20)&(d.total_calls_18mo>=20)&(d.CpG_call_records_8wk>=3)&(d.CpG_call_records_18mo>=3),cols].copy()
    diff=10*(d.methylated_calls_18mo*d.total_calls_8wk-d.methylated_calls_8wk*d.total_calls_18mo)
    factor=d.total_calls_8wk*d.total_calls_18mo
    d["hypo"]=diff<=-factor;d["hyper"]=diff>=factor
    n+=len(d);hypo+=d.hypo.sum();hyper+=d.hyper.sum()
    bucket=d.chrom.str.removeprefix("chr").map(lambda s:min((int(s)-1)//4+1,5) if s.isdigit() else 6)
    for part,chunk in d.groupby(bucket):
        with gzip.open(out/f"Panel_E_covered_tiles_{part}.tsv.gz","at" if part in opened else "wt") as f:
            chunk.to_csv(f,sep="\t",index=False,header=part not in opened)
        opened.add(part)
assert (n,hypo,hyper)==(2407854,27581,62189)
with zipfile.ZipFile(out/"BDE_reference_and_code.zip","w",compression=zipfile.ZIP_DEFLATED) as archive:
    for name in ["atlas_BDE.py","atlas_downloads.py","all_copies.R","reference.py","whole_genome_WT3_padj.py","whole_genome_WT3_rawP.py","prepare_counts.py","prepare_all_RNA.py"]:
        archive.write(root/"code"/name,"code/"+name)
    archive.write(root/"inputs/assay_detected_background.tsv.gz","inputs/assay_detected_background.tsv.gz")
    archive.write(root.parent/"Zhu_microglia_TE_chromatin_states_20261123/source/cluster20_dense.bed","reference/cluster20_dense.bed")
    archive.write(root/"counts/mice.tsv","counts/mice.tsv")
    archive.write(root/"METHODS.md","original_analysis_METHODS.md")
print(n,hypo,hyper,opened)
