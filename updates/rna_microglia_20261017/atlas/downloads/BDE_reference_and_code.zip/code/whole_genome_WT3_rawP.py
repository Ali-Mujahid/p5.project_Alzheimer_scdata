"""Export nominal edgeR calls and exact-coordinate volcanoes for two RNA detection rules."""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "genome_wide_WT3_detected_padj"
OUT = ROOT / "genome_wide_WT3_detected_rawP"
OUT.mkdir(exist_ok=True)
TITLES = {"WT_21mo": "WT 21 mo vs WT 3 mo", "5xFAD_3mo": "5xFAD 3 mo vs WT 3 mo"}
SCOPES = {
    "WT3_detected": "RNA detected in at least one WT 3 mo mouse",
    "either_group": "RNA detected in at least one mouse in either group"
}
THRESHOLD = 0.05
COLORS = {"up": "#d53e4f", "down": "#3288bd", "other": "#bfc3c6"}
files = ["WT3_detected_counts_and_padj.tsv.gz", "WT3_zero_target_detected_counts_and_padj.tsv.gz"]
data = pd.concat([pd.read_csv(SOURCE / name, sep="\t", index_col="TE_locus") for name in files],
                 verify_integrity=True)
previous = pd.read_csv(SOURCE / "padj_summary.tsv", sep="\t").set_index(["scope", "target"])
mice = pd.read_csv(ROOT / "counts/mice.tsv", sep="\t").set_index("animal")
wt = data.WT_3mo_positive_mice.gt(0)
assert np.array_equal(wt, data[mice.index[mice.condition.eq("WT_3mo")]].gt(0).any(axis=1))
stats = {}
for target in TITLES:
    prefix = target + "_vs_WT_3mo_"
    results = data[[prefix + c for c in ["logFC", "PValue", "padj"]]].copy()
    results.columns = ["logFC", "PValue", "padj"]
    eligible = wt | data[target + "_positive_mice"].gt(0)
    assert results.notna().all(axis=1).equals(eligible)
    assert results.loc[~eligible].isna().to_numpy().all()
    results = results.loc[eligible]
    fits = pd.concat([pd.read_csv(ROOT / "results/all_models" / f"{target}.{part}.edgeR.tsv.gz",
                                  sep="\t", index_col="TE_locus", usecols=["TE_locus", "logFC", "PValue"])
                      for part in ("mixed", "males")], verify_integrity=True)
    assert len(fits) == len(results)
    np.testing.assert_allclose(fits.loc[results.index], results[["logFC", "PValue"]], rtol=1e-10, atol=1e-15)
    assert results.PValue.between(0, 1, inclusive="right").all()
    stats[target] = results

plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8.5, "pdf.fonttype": 42,
                     "axes.spines.top": False, "axes.spines.right": False, "axes.linewidth": .7,
                     "axes.labelcolor": "#20272c", "text.color": "#20272c"})
max_y = int(np.ceil(max(-np.log10(r.PValue.min()) for r in stats.values())))
max_x = int(np.ceil(max(r.logFC.abs().max() for r in stats.values())))
annotations = ["chr", "start", "end", "strand", "TE_subfamily", "TE_family", "TE_class", "Figure_C_cluster"]
summary = []
for scope, subtitle in SCOPES.items():
    hit_frames = []
    fig, axes = plt.subplots(1, 2, sharex=True, sharey=True, figsize=(8.1, 4.7))
    fig.subplots_adjust(left=.096, right=.975, bottom=.22, top=.74, wspace=.15)
    fig.text(.096, .936, "Microglial TE RNA across the genome", fontsize=14, weight="bold")
    fig.text(.096, .879, subtitle, fontsize=9.5, color="#48565c")
    for ax, (target, title) in zip(axes, TITLES.items()):
        results = stats[target]
        if scope == "WT3_detected":
            results = results.loc[wt[wt].index]
        up = results.logFC.gt(0)
        down = results.logFC.lt(0)
        hit = results.PValue.lt(THRESHOLD)
        fdr_hit = results.padj.lt(THRESHOLD)
        assert not (fdr_hit & ~hit).any() and not (hit & ~(up | down)).any()
        counts = {"scope": scope, "target": target, "tested": len(results),
                  "rawP05_up": (hit & up).sum(), "rawP05_down": (hit & down).sum(),
                  "rawP05_total": hit.sum(), "FDR05_up": (fdr_hit & up).sum(),
                  "FDR05_down": (fdr_hit & down).sum()}
        np.testing.assert_array_equal([counts[k] for k in ("tested", "FDR05_up", "FDR05_down")],
                                      previous.loc[(scope, target), ["plotted", "up_FDR05", "down_FDR05"]])
        summary.append(counts)
        keep = annotations + ["WT_3mo_positive_mice", target + "_positive_mice"] + list(mice.index)
        table = data.loc[results.index[hit], keep].copy()
        table.rename(columns={target + "_positive_mice": "target_positive_mice"}, inplace=True)
        table.insert(0, "target_vs_WT_3mo", target)
        table = table.join(results.loc[hit])
        table["direction"] = np.where(table.logFC.gt(0), "up", "down")
        table["passes_genomewide_FDR05"] = table.padj.lt(THRESHOLD)
        hit_frames.append(table.sort_values("PValue"))
        y = -np.log10(results.PValue)
        ax.axhline(-np.log10(THRESHOLD), color="#535f65", ls=(0, (4, 3)), lw=.7, zorder=2)
        ax.axvline(0, color="#c4c8ca", lw=.6, zorder=0)
        for mask, color, size in ((~hit, "other", .65), (hit & down, "down", 1.05), (hit & up, "up", 1.05)):
            ax.scatter(results.logFC[mask], y[mask], s=size, color=COLORS[color], linewidths=0, rasterized=True)
        ax.set(xlim=(-max_x, max_x), ylim=(-.12, max_y), xticks=[-6,-3,0,3,6],
               yticks=np.arange(0, max_y+1, 2))
        ax.tick_params(length=3, width=.65)
        ax.text(0, 1.14, title, transform=ax.transAxes, fontsize=10.5, weight="bold")
        ax.text(0, 1.043, f"{len(results):,} copies   ·   {counts['rawP05_up']:,} up   ·   {counts['rawP05_down']:,} down",
                transform=ax.transAxes, fontsize=8.4, color="#48565c")
    axes[0].set_ylabel("−log₁₀(raw edgeR P)")
    fig.text(.536, .118, "TE RNA log₂ fold change (target / WT 3 mo)", ha="center", fontsize=9.2)
    handles = [Line2D([], [], marker="o", ls="none", ms=4, color=COLORS[key], markeredgewidth=0, label=label)
               for key, label in (("up", "Up (P < 0.05)"), ("down", "Down (P < 0.05)"), ("other", "P ≥ 0.05"))]
    fig.legend(handles=handles, loc="center", bbox_to_anchor=(.536, .055), ncol=3, frameon=False, handletextpad=.24)
    for ext in ("pdf", "png"):
        fig.savefig(OUT / f"{scope}_rawP_volcano.{ext}", dpi=600, facecolor="white")
    plt.close(fig)
    pd.concat(hit_frames).to_csv(OUT / f"{scope}_rawP05_hits.tsv.gz", sep="\t", na_rep="NA")
pd.DataFrame(summary).to_csv(OUT / "rawP_summary.tsv", sep="\t", index=False)
