"""Stream all TE copies with any RNA in the eleven mice, retaining even fractional signal."""
from pathlib import Path
import gzip
import numpy as np
import pandas as pd
out=Path(__file__).resolve().parents[1]
src=out.parent/'Microglia_TE_RNA_ATAC_five_groups_20261123/tables/genome_mouse/TE_copy_matrix.tsv.gz'
meta=pd.read_csv(out/'counts/mice.tsv',sep='\t')
cols=[m+'_RNA_expected_UMI' for m in meta.animal]
total=0
with gzip.open(out/'inputs/any_RNA_genome.tsv.gz','wt',compresslevel=4) as fd:
    for d in pd.read_csv(src,sep='\t',chunksize=125000,usecols=['TE_locus','chr']+cols):
        x=d[cols].to_numpy()
        keep=np.nansum(x,axis=1)>0
        d=d.loc[keep].rename(columns=dict(zip(cols,meta.animal)))
        d.to_csv(fd,sep='\t',index=False,header=(total==0),na_rep='NA',float_format='%.12g')
        total+=len(d)
print(total)
