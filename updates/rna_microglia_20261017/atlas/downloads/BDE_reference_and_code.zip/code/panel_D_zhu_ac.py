"""Measure Zhu microglial H3K27ac at the Figure C midpoints using GSE152020."""
from pathlib import Path
import json, hashlib, tarfile
import numpy as np
import pandas as pd

root = Path(__file__).resolve().parents[1]
source = root.parent / "Zhu_microglia_TE_chromatin_states_20261123/source"
out = root / "atlas_zhu_volcano"
out.mkdir(exist_ok=True)
archive = source / "GSE152020_Paired-Tag_H3K27ac_DNA_filtered_matrix.tar.gz"
meta_file = source / "2020_10_06_Paired-Tag_MetaData.xls"
meta = pd.read_csv(meta_file, sep="\t")
micro = meta.loc[meta.Membership.eq(20) & meta.Target.eq("H3K27ac")].copy()
assert micro.Cell_ID.is_unique and set(micro.Annotation) == {"BR_NonNeu_Microglia"}
assert set(meta.loc[meta.Annotation.eq("BR_NonNeu_Microglia"), "Membership"])=={20}
with tarfile.open(archive) as tar:
    members = {Path(e.name).name:e for e in tar if e.isfile()}
    barcodes = pd.read_csv(tar.extractfile(members["barcodes.tsv"]),header=None)[0]
    assert barcodes.is_unique and micro.Cell_ID.isin(barcodes).all()
    micro["library"]=micro.Tissue+"_R"+micro.Rep.astype(str)
    libs=sorted(micro.library.unique())
    group=barcodes.map(micro.set_index("Cell_ID").library).map({v:i for i,v in enumerate(libs)}).fillna(-1).to_numpy(int)
    assert sum(group>=0)==len(micro)==192
    features=pd.read_csv(tar.extractfile(members["bins.tsv"]),sep="\t",header=None)
    assert features[0].is_unique and features[0].equals(features[1])
    bins=features[0].str.extract(r"^(?P<chr>[^:]+):(?P<start>\d+)-(?P<end>\d+)$").astype({"start":int,"end":int})
    assert bins.start.mod(5000).eq(0).all() and bins.end.sub(bins.start).between(1,5000).all()
    counts=np.zeros((len(bins),len(libs)),dtype=np.int64)
    cell_counts=np.zeros(len(barcodes),dtype=np.int64)
    with tar.extractfile(members["matrix.mtx"]) as fh:
        line=fh.readline()
        while line.startswith(b"%"):line=fh.readline()
        nrow,ncol,nnz=map(int,line.split()); n=0
        assert (nrow,ncol)==(len(bins),len(barcodes))
        for block in pd.read_csv(fh,sep=" ",header=None,chunksize=400000):
            r,c,v=block.to_numpy().T
            assert r.min()>=1 and c.min()>=1 and r.max()<=nrow and c.max()<=ncol and v.min()>0
            selected=group[c-1]>=0
            np.add.at(counts,(r[selected]-1,group[c[selected]-1]),v[selected])
            np.add.at(cell_counts,c[selected]-1,v[selected])
            n+=len(r)
        assert n==nnz
for i,name in enumerate(libs):bins[name+"_tags"]=counts[:,i]
bins["H3K27ac_tags"]=counts.sum(axis=1)
bins["positive_libraries"]=(counts>0).sum(axis=1)
assert bins.H3K27ac_tags.sum()==cell_counts.sum()
bins=bins.sort_values(["chr","start"])
bins.to_csv(out/"Zhu_H3K27ac_microglia_5kb.tsv.gz",sep="\t",index=False)
micro["H3K27ac_tags"]=micro.Cell_ID.map(pd.Series(cell_counts,index=barcodes))
micro[["Cell_ID","Annotation","Membership","Target","Tissue","Rep","H3K27ac_tags"]].to_csv(out/"Zhu_H3K27ac_microglia_nuclei.tsv",sep="\t",index=False)
df=pd.read_csv(root/"results/D_per_copy_states.tsv.gz",sep="\t")
df=df.merge(pd.read_csv(root/"inputs/Figure_C_copy_clusters.tsv.gz",sep="\t"),
            on=["cluster_id","TE_locus","chr","start","end"],validate="one_to_one")
df=df.merge(pd.read_csv(root/"results/E_per_copy_age_overlap.tsv.gz",sep="\t"),on=["cluster_id","TE_locus"],validate="one_to_one")
assert len(df)==267038 and df.TE_locus.is_unique and np.array_equal(df.midpoint,df.start+(df.end-df.start)//2)
df["bin_start"]=df.midpoint//5000*5000
df=df.merge(bins[["chr","start","end","H3K27ac_tags","positive_libraries"]].rename(columns={"start":"bin_start","end":"bin_end"}),
            on=["chr","bin_start"],how="left",validate="many_to_one")
assayed=df.bin_end.notna()
assert df.loc[assayed,"midpoint"].lt(df.loc[assayed,"bin_end"]).all()
for col in ["bin_end","H3K27ac_tags","positive_libraries"]:df[col]=df[col].astype("Int64")
active=df.native_state.eq("Active enhancer")
assert np.array_equal(active,df.dense.eq(3))
df["active_enhancer_H3K27ac_supported"]=(active & df.H3K27ac_tags.gt(0)).where(assayed,pd.NA)
df.to_csv(out/"C1-C5_reference_by_copy.tsv.gz",sep="\t",index=False,na_rep="NA")
states=df.dense.gt(0)
found=df.H3K27ac_tags.gt(0)
features={"Promoter":(states,df.regulatory_class.eq("Promoter")),
          "H3K27ac enhancer":(assayed & states,active & found),
          "H3K27ac detected":(assayed,found),"Active enhancer":(states,active),
          "H3K27me3":(states,df.regulatory_class.eq("Polycomb (H3K27me3)")),
          "H3K9me3":(states,df.regulatory_class.eq("H3K9me3")),
          "No signal":(states,df.regulatory_class.eq("No signal"))}
rows=[]
for cluster,g in df.groupby("cluster_id"):
    for feature,(eligible,test) in features.items():
        idx=g.index;total=int(eligible.loc[idx].sum()); hits=int((eligible.loc[idx]&test.loc[idx]).sum())
        rows.append(dict(cluster=cluster,feature=feature,copies=hits,total=total,cluster_copies=len(g),unmeasured=len(g)-total,value=100*hits/total))
stats=pd.DataFrame(rows);stats.to_csv(out/"Panel_D_values.tsv",index=False,sep="\t")
print(stats[stats.feature.eq("H3K27ac enhancer")].to_string(index=False))
sha=lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((root/"atlas_panels/BDE_sources.json").read_text())
z=dict(series="GSE152020",assay="Paired-Tag H3K27ac",matrix_sha256=sha(archive),metadata_sha256=sha(meta_file),ChromHMM_BED_sha256=sha(source/"cluster20_dense.bed"),
       matrix_url="https://ftp.ncbi.nlm.nih.gov/geo/series/GSE152nnn/GSE152020/suppl/"+archive.name,
       metadata_url="https://raw.githubusercontent.com/cxzhu/Paired-Tag/b2f367391aba77b17c833cb5671058ee397a19af/rscripts/2020_10_06_Paired-Tag_MetaData.xls",
       microglia_nuclei=len(micro),frontal_cortex=int(micro.Tissue.eq("FC").sum()),hippocampus=int(micro.Tissue.eq("HC").sum()),deposited_bins=nrow,
       measured_cluster_loci=int(assayed.sum()),total_tags=int(cell_counts.sum()))
(out/"BDE_sources.json").write_text(json.dumps(dict(shards=manifest["shards"],cluster_copies=len(df),panel_D=z),indent=2)+"\n")
print(z)
