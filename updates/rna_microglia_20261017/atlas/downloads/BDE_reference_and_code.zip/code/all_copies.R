suppressPackageStartupMessages({library(data.table);library(edgeR);library(DESeq2)})
args=commandArgs(TRUE)
target=args[1];scope=args[2];method=args[3]
stopifnot(target%in%c("WT_21mo","5xFAD_3mo"),scope%in%c("mixed","males"),method%in%c("edgeR","DESeq2"))
options(stringsAsFactors=FALSE,digits=15)
dir.create("results/all_models",recursive=TRUE,showWarnings=FALSE)
prefix=file.path("results/all_models",paste(target,scope,method,sep="."))
meta=read.delim("counts/mice.tsv",check.names=FALSE)
m=meta[meta$condition%in%c("WT_3mo",target) & (scope=="mixed"|meta$sex=="male"),,drop=FALSE]
m$sex=factor(m$sex);m$condition=factor(m$condition,levels=c("WT_3mo",target));rownames(m)=m$animal
design=if(scope=="mixed") ~sex+condition else ~condition
x=model.matrix(design,m);stopifnot(qr(x)$rank==ncol(x))
expo=m$gene_effective_depth
d=fread(cmd="gzip -dc inputs/any_RNA_genome.tsv.gz",select=c("TE_locus","chr",m$animal),data.table=FALSE,na.strings="NA",check.names=FALSE)
if(scope=="mixed") d=d[d$chr!="chrY",,drop=FALSE]
y=as.matrix(d[,m$animal,drop=FALSE]);rownames(y)=d$TE_locus
rm(d);gc()
stopifnot(all(is.finite(y)),all(y>=0),!anyDuplicated(rownames(y)))
if(method=="DESeq2"){y=round(y);storage.mode(y)="integer"}
y=y[rowSums(y)>0,,drop=FALSE]
report=if(scope=="mixed") rep(TRUE,nrow(y)) else startsWith(rownames(y),"chrY:")
message(method," ",target," ",scope," fitting ",nrow(y),"; reporting ",sum(report))
if(method=="edgeR"){
 obj=DGEList(y,lib.size=expo);fit=glmQLFit(obj,x,robust=TRUE,legacy=FALSE)
 ans=glmQLFTest(fit,coef=ncol(x))$table
 stopifnot(identical(rownames(ans),rownames(y)))
}else{
 obj=DESeqDataSetFromMatrix(y,m,design)
 sizeFactors(obj)=expo/exp(mean(log(expo)))
 # Estimate dispersions over all nonzero loci. For the male-only sensitivity,
 # only Wald statistics for Y loci are needed; the dispersion trend remains genome-wide.
 obj=estimateDispersions(obj,quiet=TRUE)
 if(scope=="males") obj=obj[report,]
 obj=nbinomWaldTest(obj,quiet=TRUE)
 ans=as.data.frame(results(obj,contrast=c("condition",target,"WT_3mo"),alpha=.10))
 if(scope=="males"){stopifnot(identical(rownames(ans),rownames(y)[report]));report=rep(TRUE,nrow(ans))}
}
res=data.frame(TE_locus=rownames(ans)[report],ans[report,,drop=FALSE],check.names=FALSE)
fwrite(res,paste0(prefix,".tsv.gz"),sep="\t",na="NA")
fwrite(data.frame(target,scope,method,fit_rows=nrow(y),reported_rows=nrow(res),mice=nrow(m)),paste0(prefix,".qc.tsv"),sep="\t")
