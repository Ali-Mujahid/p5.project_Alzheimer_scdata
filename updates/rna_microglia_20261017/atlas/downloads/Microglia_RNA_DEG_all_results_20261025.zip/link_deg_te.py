#!/usr/bin/env python3
"""Annotate supported mouse-pseudobulk DEGs with nearby TE-overlapping peaks.

Peak proximity and five-group accessibility are descriptive; no peak-to-gene
link significance or TE-copy transcription is inferred.
"""
import argparse
import csv
import gzip
import heapq
import json
import math
import zipfile
from collections import defaultdict
from pathlib import Path


TARGETS = ("WT_6mo", "WT_21mo", "5xFAD_3mo", "APOE4_TREM2_3mo")
PEAK_SIGNAL = {"WT_6mo": "WT_6mo_ATAC", "WT_21mo": "WT_21mo_ATAC",
               "5xFAD_3mo": "FAD_ATAC", "APOE4_TREM2_3mo": "APOE_ATAC"}


def stream(path):
    with gzip.open(path, "rt", newline="") if str(path).endswith(".gz") else open(path, newline="") as f:
        yield from csv.DictReader(f, delimiter="\t")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--deg-dir", type=Path, required=True)
    p.add_argument("--peak-gene-pairs", type=Path, required=True)
    p.add_argument("--te-de-zip", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    a = p.parse_args()
    if not a.output.is_dir():
        raise ValueError("Output directory required")
    deg = defaultdict(list)
    for file in sorted(a.deg_dir.glob("*__*_vs_WT_3mo.all_tested.tsv.gz")):
        pop, rest = file.name.split("__", 1)
        target = rest.removesuffix("_vs_WT_3mo.all_tested.tsv.gz")
        if target not in TARGETS:
            continue
        for row in stream(file):
            if row["FDR"] != "NA" and float(row["FDR"]) <= 0.1:
                deg[(row["gene_id"], target)].append((pop, row))
    te = {}
    with zipfile.ZipFile(a.te_de_zip) as archive:
        for target in TARGETS:
            name = f"subfamily/{target}_vs_WT_3mo.all_features.tsv"
            with archive.open(name) as f:
                te[target] = {r["repName"]: r for r in csv.DictReader(
                    (b.decode("utf-8") for b in f), delimiter="\t")}
    # At most five nearby accessible TE peaks per DEG/population/contrast.
    best = defaultdict(list)
    scanned = 0
    for pair in stream(a.peak_gene_pairs):
        scanned += 1
        gene = pair["gene_id"]
        distance = abs(int(float(pair["distance_to_TSS_bp"])))
        if distance > 100000:
            continue
        control = float(pair["WT_3mo_ATAC"])
        for target in TARGETS:
            hit = deg.get((gene, target))
            if not hit:
                continue
            accessibility = float(pair[PEAK_SIGNAL[target]])
            change = math.log2((accessibility + 0.1) / (control + 0.1))
            if change < 0.5:
                continue
            names = [s.strip() for s in pair["TE_subfamilies"].replace("|", ";").split(";") if s.strip()]
            for pop, row in hit:
                key = (pop, target, gene)
                item = (-distance, change, pair["peak_id"], scanned, row, pair, names)
                heap = best[key]
                if len(heap) < 5:
                    heapq.heappush(heap, item)
                elif item > heap[0]:
                    heapq.heapreplace(heap, item)
    cols = ("population contrast gene_id gene_symbol gene_log2FC gene_FDR peak_id chrom "
            "start0 end distance_to_TSS_bp TE_subfamilies TE_families TE_classes "
            "WT_3mo_ATAC target_ATAC ATAC_log2_change TE_RNA_log2FC TE_RNA_FDR "
            "association_scope").split()
    rows = []
    for (pop, target, gene), heap in best.items():
        for negative_distance, change, peak_id, _, grow, pair, names in sorted(heap, reverse=True):
            for name in names:
                t = te[target].get(name, {})
                rows.append(dict(population=pop, contrast=f"{target}_vs_WT_3mo",
                    gene_id=gene, gene_symbol=grow["gene_symbol"],
                    gene_log2FC=grow["log2FC"], gene_FDR=grow["FDR"],
                    peak_id=peak_id, chrom=pair["chrom"], start0=pair["start0"],
                    end=pair["end"], distance_to_TSS_bp=-negative_distance,
                    TE_subfamilies=name, TE_families=pair["TE_families"],
                    TE_classes=pair["TE_classes"], WT_3mo_ATAC=pair["WT_3mo_ATAC"],
                    target_ATAC=pair[PEAK_SIGNAL[target]], ATAC_log2_change=change,
                    TE_RNA_log2FC=t.get("edgeR_logFC", "NA"),
                    TE_RNA_FDR=t.get("FDR_within_contrast", "NA"),
                    association_scope="gene_FDR010_and_nearby_TE_peak_100kb_accessibility_increase_descriptive"))
    rows.sort(key=lambda r: (r["population"], r["contrast"], float(r["gene_FDR"]),
                             int(r["distance_to_TSS_bp"]), r["peak_id"]))
    with gzip.open(a.output / "DEG_nearby_TE_peak_candidates.tsv.gz", "wt", newline="") as f:
        writer = csv.DictWriter(f, cols, delimiter="\t")
        writer.writeheader(); writer.writerows(rows)
    summary = {"scanned_peak_gene_pairs": scanned, "tested_positive_DEG_gene_target_pairs": len(deg),
               "candidate_rows": len(rows), "candidate_genes": len({(r['population'],r['contrast'],r['gene_id']) for r in rows}),
               "filters": "gene FDR <=0.1; TE-overlap peak <=100kb of gene TSS; target ATAC log2 change >=0.5; up to five nearest peaks per gene and population",
               "interpretation": "Proximity and group-level concordance only; no causal peak-to-gene link or individual TE-copy RNA expression. TE-subfamily RNA FDR remains separately reported."}
    (a.output / "DEG_TE_association_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary))


if __name__ == "__main__":
    main()
