#!/usr/bin/env python3
"""Render Microglia DEG figures and compact browser payload from verified tables."""
import argparse
import csv
import gzip
import json
import math
from collections import defaultdict
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.colors import LinearSegmentedColormap

LOW = "#3288bd"
HIGH = "#d53e4f"
MIDDLE = "#ffffff"
TARGETS = ("WT_6mo", "WT_21mo", "5xFAD_3mo", "APOE4_TREM2_3mo")


def tsv(path):
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "rt", newline="") as f:
        yield from csv.DictReader(f, delimiter="\t")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--results", type=Path, required=True)
    p.add_argument("--links", type=Path)
    p.add_argument("--out", type=Path, required=True)
    a = p.parse_args()
    a.out.mkdir(parents=True, exist_ok=True)
    summaries = list(tsv(a.results / "DEG_summary.tsv"))
    if len(summaries) != 100:
        raise ValueError("Expected 25 populations times four contrasts")
    color = LinearSegmentedColormap.from_list("low_to_high", [LOW, MIDDLE, HIGH])
    total = {}
    for target in TARGETS:
        name = f"{target}_vs_WT_3mo"
        path = a.results / f"all_microglia__{name}.all_tested.tsv.gz"
        rows = list(tsv(path))
        total[target] = rows
    fig, axes = plt.subplots(2, 2, figsize=(12, 9), constrained_layout=True)
    payload_volcano = {}
    for ax, target in zip(axes.flat, TARGETS):
        rows = total[target]
        x = np.asarray([float(r["log2FC"]) for r in rows])
        pv = np.asarray([max(float(r["PValue"]), 1e-300) for r in rows])
        q = np.asarray([float(r["FDR"]) for r in rows])
        y = -np.log10(pv)
        ok = q < 0.1
        ax.scatter(x[~ok], y[~ok], s=3, color="#b8bec5", alpha=.5, rasterized=True)
        ax.scatter(x[ok & (x < 0)], y[ok & (x < 0)], s=8, color=LOW, alpha=.85, rasterized=True)
        ax.scatter(x[ok & (x >= 0)], y[ok & (x >= 0)], s=8, color=HIGH, alpha=.85, rasterized=True)
        ax.axvline(0, color="#777", lw=.7)
        ax.set(xlabel="log₂ fold change", ylabel="−log₁₀ p value", title=f"{target} vs WT_3mo · {ok.sum()} DEGs (FDR < 0.1)")
        ordered = sorted(rows, key=lambda r: float(r["PValue"]))
        payload_volcano[target] = [[r["gene_id"], r["gene_symbol"], round(float(r["log2FC"]), 4),
                                    round(-math.log10(max(float(r["PValue"]), 1e-300)), 4),
                                    round(float(r["FDR"]), 6)] for r in ordered[:1200]]
        for r in [z for z in ordered if float(z["FDR"]) < .1][:5]:
            ax.annotate(r["gene_symbol"] or r["gene_id"],
                        (float(r["log2FC"]), -math.log10(max(float(r["PValue"]), 1e-300))),
                        fontsize=6)
    fig.suptitle("Microglia mouse-level differential RNA · sex-adjusted edgeR QL")
    fig.savefig(a.out / "Microglia_total_DEG_volcano.pdf")
    fig.savefig(a.out / "Microglia_total_DEG_volcano.png", dpi=180)
    plt.close(fig)

    chosen = []
    for target in TARGETS:
        sig = [r for r in total[target] if float(r["FDR"]) < .1]
        sig.sort(key=lambda r: float(r["FDR"]))
        chosen.extend(r["gene_id"] for r in sig[:20])
    chosen = list(dict.fromkeys(chosen))[:70]
    index = {t: {r["gene_id"]: r for r in total[t]} for t in TARGETS}
    labels = []
    values = []
    payload_genes = []
    for gid in chosen:
        row = next(index[t][gid] for t in TARGETS if gid in index[t])
        labels.append(row["gene_symbol"] or gid)
        change = [float(index[t][gid]["log2FC"]) if gid in index[t] else 0 for t in TARGETS]
        values.append(change)
        payload_genes.append([gid, labels[-1], [round(x, 4) for x in change]])
    fig, ax = plt.subplots(figsize=(8, max(5, len(labels) * .22 + 1.5)), constrained_layout=True)
    if values:
        mat = np.asarray(values)
        vmax = max(1, float(np.quantile(np.abs(mat), .95)))
        im = ax.imshow(mat, aspect="auto", cmap=color, vmin=-vmax, vmax=vmax)
        fig.colorbar(im, ax=ax, label="log₂ fold change vs WT_3mo")
        ax.set_yticks(range(len(labels)), labels, fontsize=6)
    ax.set_xticks(range(4), TARGETS, rotation=35, ha="right")
    ax.set_title("Genes with FDR < 0.1 in at least one contrast")
    fig.savefig(a.out / "Microglia_total_DEG_log2FC_heatmap.pdf")
    fig.savefig(a.out / "Microglia_total_DEG_log2FC_heatmap.png", dpi=180)
    plt.close(fig)

    stats = {(r["population"], r["contrast"]): r for r in summaries}
    matrix = np.full((24, 4), np.nan)
    for i in range(24):
        for j, target in enumerate(TARGETS):
            row = stats[(f"MG{i}", f"{target}_vs_WT_3mo")]
            if row["status"] == "tested":
                matrix[i, j] = int(row["FDR_0_10"])
    fig, ax = plt.subplots(figsize=(8, 9), constrained_layout=True)
    image = ax.imshow(np.ma.masked_invalid(np.log1p(matrix)), aspect="auto", cmap=color,
                      vmin=0, vmax=max(1, np.nanmax(np.log1p(matrix))))
    ax.set_xticks(range(4), TARGETS, rotation=35, ha="right")
    ax.set_yticks(range(24), [f"MG{i}" for i in range(24)])
    for i in range(24):
        for j in range(4):
            ax.text(j, i, "–" if np.isnan(matrix[i,j]) else str(int(matrix[i,j])),
                    ha="center", va="center", fontsize=7)
    fig.colorbar(image, ax=ax, label="log(1 + number of DEGs at FDR < 0.1)")
    ax.set_title("Microglia subclusters · mouse-supported contrasts\nDash: insufficient mice or testable genes")
    fig.savefig(a.out / "Microglia_subcluster_DEG_count_heatmap.pdf")
    fig.savefig(a.out / "Microglia_subcluster_DEG_count_heatmap.png", dpi=180)
    plt.close(fig)

    links = []
    if a.links and a.links.exists():
        for r in tsv(a.links):
            if len(links) < 4000:
                links.append({k:r[k] for k in ("population","contrast","gene_symbol","gene_log2FC","gene_FDR",
                     "peak_id","chrom","start0","end","distance_to_TSS_bp","TE_subfamilies",
                     "ATAC_log2_change","TE_RNA_log2FC","TE_RNA_FDR")})
    by_population = {"all_microglia": payload_volcano}
    for row in summaries:
        if row["population"] == "all_microglia" or row["status"] != "tested":
            continue
        pop = row["population"]
        target = row["contrast"].removesuffix("_vs_WT_3mo")
        path = a.results / f"{pop}__{row['contrast']}.all_tested.tsv.gz"
        selected = sorted(tsv(path), key=lambda r: float(r["PValue"]))[:350]
        by_population.setdefault(pop, {})[target] = [[r["gene_id"],r["gene_symbol"],
            round(float(r["log2FC"]),4),round(-math.log10(max(float(r["PValue"]),1e-300)),4),
            round(float(r["FDR"]),6)] for r in selected]
    data = {"schema":"microglia_DEG_atlas_v1", "low":LOW,"high":HIGH,
            "method":"mouse pseudobulk; 20 mice; edgeR robust QL; sex plus condition; FDR within population and contrast",
            "scope":"22,251 provisional Microglia-like RNA cells; 24 Leiden 1.8 subclusters",
            "contrasts":list(TARGETS),"summary":summaries,"volcano":payload_volcano,
            "volcano_by_population":by_population,
            "differential_heatmap_genes":payload_genes,"TE_peak_candidate_links":links,
            "association_limit":"Nearby TE-overlapping ATAC peak and group-level concordance only; no statistically supported disease TE RNA subfamily at FDR 0.1."}
    (a.out / "Microglia_DEG_atlas_data.json").write_text(json.dumps(data,separators=(",", ":"), allow_nan=False))
    print(json.dumps({"volcano_points":{k:len(v) for k,v in payload_volcano.items()},
                      "heatmap_genes":len(chosen),"links":len(links)}))


if __name__ == "__main__":
    main()
