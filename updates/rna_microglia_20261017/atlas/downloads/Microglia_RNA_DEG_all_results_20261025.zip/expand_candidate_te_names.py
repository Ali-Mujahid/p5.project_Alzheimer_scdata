#!/usr/bin/env python3
"""Split semicolon-delimited TE names in the saved 7664384 candidates."""
import argparse
import csv
import gzip
import zipfile
from pathlib import Path


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--input", type=Path, required=True)
    p.add_argument("--te-de-zip", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    a = p.parse_args()
    with zipfile.ZipFile(a.te_de_zip) as archive:
        te = {}
        for target in ("WT_6mo", "WT_21mo", "5xFAD_3mo", "APOE4_TREM2_3mo"):
            with archive.open(f"subfamily/{target}_vs_WT_3mo.all_features.tsv") as f:
                te[target] = {r["repName"]: r for r in csv.DictReader(
                    (b.decode() for b in f), delimiter="\t")}
    if a.output.exists():
        raise FileExistsError(a.output)
    with gzip.open(a.input, "rt", newline="") as source, gzip.open(a.output, "wt", newline="") as target_file:
        reader = csv.DictReader(source, delimiter="\t")
        writer = csv.DictWriter(target_file, fieldnames=reader.fieldnames, delimiter="\t")
        writer.writeheader()
        count = 0
        for row in reader:
            group = row["contrast"].removesuffix("_vs_WT_3mo")
            for name in row["TE_subfamilies"].replace("|", ";").split(";"):
                name = name.strip()
                if not name:
                    continue
                clean = row.copy()
                clean["TE_subfamilies"] = name
                lookup = te[group].get(name, {})
                clean["TE_RNA_log2FC"] = lookup.get("edgeR_logFC", "NA")
                clean["TE_RNA_FDR"] = lookup.get("FDR_within_contrast", "NA")
                writer.writerow(clean)
                count += 1
    print("Expanded named TE candidate rows:", count)


if __name__ == "__main__":
    main()
