#!/usr/bin/env python3
"""Sum existing raw RNA counts by mouse and saved Microglia Leiden 1.8 cluster."""
import argparse
import csv
import json
from pathlib import Path

import h5py
import numpy as np


def decode(x):
    return x.decode() if isinstance(x, bytes) else str(x)


def main():
    p = argparse.ArgumentParser()
    for key in ("atlas", "core", "highres", "total", "output"):
        p.add_argument("--" + key, required=True, type=Path)
    a = p.parse_args()
    with a.core.open(newline="") as f:
        rows = [r for r in csv.DictReader(f, delimiter="\t") if r["core"] == "1"]
    labels = json.loads(a.highres.read_text())["labels"]
    assert len(rows) == len(labels) == 22251
    assert sorted(set(labels)) == list(range(24))
    ids = [r["cell_id"] for r in rows]
    positions = np.asarray([int(r["global_row"]) for r in rows], dtype=np.int64)
    assert np.all(positions[1:] > positions[:-1])
    mice = sorted(set(r["animal_id"] for r in rows))
    assert len(mice) == 20
    mouse_index = {v: i for i, v in enumerate(mice)}
    group = np.asarray([int(c) * 20 + mouse_index[r["animal_id"]]
                        for c, r in zip(labels, rows)], dtype=np.int32)
    cell_counts = np.bincount(group, minlength=480)
    assert cell_counts.sum() == 22251
    with h5py.File(a.atlas, "r") as source, h5py.File(a.total, "r") as previous:
        x = source["X"]
        assert tuple(x.attrs["shape"]) == (2281619, 55487)
        raw_ids = [decode(v) for v in source["obs/cell_id"][positions]]
        assert raw_ids == ids, "High-resolution labels and raw count cell axis differ"
        features = [decode(v) for v in source["var/feature_id"][:]]
        assert features == [decode(v) for v in previous["feature_id"][:]], "Gene axis differs"
        indptr = x["indptr"][:]
        assert len(indptr) == 2281620 and indptr[0] == 0
        assert np.all(indptr[1:] >= indptr[:-1])
        counts = np.zeros((55487, 480), dtype=np.int64)
        for j, (row, g) in enumerate(zip(positions, group)):
            start, end = int(indptr[row]), int(indptr[row + 1])
            ix = x["indices"][start:end]
            values = x["data"][start:end]
            assert len(ix) == len(values) and np.all(ix >= 0) and np.all(ix < 55487)
            assert np.all(values > 0) and np.all(ix[1:] > ix[:-1])
            counts[ix, g] += values
            if (j + 1) % 4000 == 0:
                print("cells", j + 1, flush=True)
        old = previous["Microglia22251_mouse_gene_counts"][:]
        assert old.shape == (20, 55487), "Saved R matrix has mouse × gene HDF5 storage order"
        old = old.T
        assert np.array_equal(counts.reshape(55487, 24, 20).sum(axis=1), old), \
            "High-resolution sums do not reproduce accepted total mouse counts"
        assert a.output.parent.is_dir() and not a.output.exists()
        with h5py.File(a.output, "x") as out:
            out.create_dataset("counts", data=counts, compression="gzip", compression_opts=4)
            out.create_dataset("cell_counts", data=cell_counts)
            out.create_dataset("gene_id", data=previous["gene_id"][:])
            out.create_dataset("gene_symbol", data=previous["gene_symbol"][:])
            out.create_dataset("mice", data=np.asarray(mice, dtype="S64"))
            out.attrs["source"] = str(a.atlas)
            out.attrs["selected_cells"] = 22251
            out.attrs["clusters"] = 24
            out.attrs["total_mouse_counts_exact_match"] = True
    print("PASS: 22,251 selected cells, 24 clusters, 20 mice; exact total-count match", flush=True)


if __name__ == "__main__":
    main()
