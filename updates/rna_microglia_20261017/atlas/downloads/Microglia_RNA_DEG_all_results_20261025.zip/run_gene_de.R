#!/usr/bin/env Rscript
suppressPackageStartupMessages({library(rhdf5); library(edgeR); library(jsonlite)})
args <- commandArgs(trailingOnly=TRUE)
if (length(args)!=3L) stop("Usage: run_gene_de.R total.h5 highres.h5 output_directory")
total_file <- args[1]; high_file <- args[2]; out <- args[3]
if (!dir.exists(out)) stop("Output directory must exist")
targets <- c("WT_6mo", "WT_21mo", "5xFAD_3mo", "APOE4_TREM2_3mo")
ref <- "WT_3mo"
total <- h5read(total_file,"Microglia22251_mouse_gene_counts")
raw <- h5read(high_file,"counts")
if (identical(dim(raw),c(480L,55487L))) raw <- t(raw)
cell_counts <- as.integer(h5read(high_file,"cell_counts"))
mice <- as.character(h5read(high_file,"mice"))
ids <- as.character(h5read(total_file,"gene_id"))
symbols <- as.character(h5read(total_file,"gene_symbol"))
if (!identical(dim(total),c(55487L,20L)) || !identical(dim(raw),c(55487L,480L)) ||
    length(cell_counts)!=480L || length(mice)!=20L || length(unique(mice))!=20L ||
    length(ids)!=55487L || length(symbols)!=55487L ||
    anyNA(total) || any(total<0) || any(total!=round(total)) ||
    anyNA(raw) || any(raw<0) || any(raw!=round(raw))) stop("Source axes/raw integer counts invalid")
raw3 <- array(raw,c(55487L,20L,24L))
if (!isTRUE(all.equal(apply(raw3,c(1,2),sum),total,check.attributes=FALSE)) ||
    sum(cell_counts)!=22251L) stop("High-resolution counts do not conserve accepted total")
condition <- sub("_(female|male)_[12]$","",mice)
sex <- ifelse(grepl("_female_",mice),"female","male")
if (!identical(as.integer(sort(table(condition))),rep(4L,5L)) ||
    !setequal(unique(condition),c(ref,targets)) ||
    any(table(condition,sex)!=2L)) stop("Five groups must have 2 female and 2 male mice")
support <- list(); summaries <- list(); tops <- list()
for (pop in c("all_microglia",paste0("MG",seq_len(24)-1L))) {
  cluster <- if (pop=="all_microglia") NA_integer_ else as.integer(sub("MG","",pop))
  mat <- if (is.na(cluster)) total else raw3[,,cluster+1L]
  rownames(mat) <- ids
  ncell <- if (is.na(cluster)) integer() else
           cell_counts[(cluster*20L+1L):((cluster+1L)*20L)]
  if (is.na(cluster)) {
    # The accepted total count matrix already has a reviewed 20-mouse cell depth table.
    depth <- read.delim(Sys.getenv("MICROGLIA_DEPTH_TSV"),check.names=FALSE)
    ncell <- depth$selected_cells[match(mice,depth$animal_id)]
  }
  if (length(ncell)!=20L || anyNA(ncell)) stop("Mouse cell-depth join failed")
  eligible <- ncell>=10L & colSums(mat)>0
  tab <- table(factor(condition[eligible],levels=c(ref,targets)))
  for (k in seq_along(mice)) support[[length(support)+1L]] <- data.frame(
    population=pop,animal_id=mice[k],condition=condition[k],sex=sex[k],
    cells=ncell[k],raw_UMIs=sum(mat[,k]),eligible=eligible[k])
  usable_groups <- names(tab)[tab>=3L]
  if (!(ref %in% usable_groups)) {
    for (target in targets) summaries[[length(summaries)+1L]] <- data.frame(
      population=pop,contrast=paste0(target,"_vs_",ref),status="insufficient_control_mice",
      n_control=unname(tab[ref]),n_target=unname(tab[target]),genes_tested=0L,
      FDR_0_05=NA_integer_,FDR_0_10=NA_integer_)
    next
  }
  keep_mouse <- eligible & condition %in% usable_groups
  groups <- factor(condition[keep_mouse],levels=c(ref,setdiff(usable_groups,ref)))
  sexes <- factor(sex[keep_mouse],levels=c("female","male"))
  design <- model.matrix(~sexes+groups)
  if (qr(design)$rank != ncol(design) || nrow(design)<=ncol(design)+1L) stop(paste("Rank or residual df",pop))
  y <- DGEList(counts=mat[,keep_mouse,drop=FALSE])
  keep_gene <- filterByExpr(y,design=design,min.count=10,min.total.count=15)
  if (sum(keep_gene)<100L) {
    for (target in targets) summaries[[length(summaries)+1L]] <- data.frame(
      population=pop,contrast=paste0(target,"_vs_",ref),status="too_few_testable_genes",
      n_control=unname(tab[ref]),n_target=unname(tab[target]),genes_tested=sum(keep_gene),
      FDR_0_05=NA_integer_,FDR_0_10=NA_integer_)
    next
  }
  y <- y[keep_gene,,keep.lib.sizes=FALSE]
  y <- calcNormFactors(y)
  y <- estimateDisp(y,design,robust=TRUE)
  fit <- glmQLFit(y,design,robust=TRUE)
  for (target in targets) {
    contrast <- paste0(target,"_vs_",ref)
    if (!(target %in% usable_groups)) {
      summaries[[length(summaries)+1L]] <- data.frame(
        population=pop,contrast=contrast,status="insufficient_target_mice",
        n_control=unname(tab[ref]),n_target=unname(tab[target]),genes_tested=0L,
        FDR_0_05=NA_integer_,FDR_0_10=NA_integer_)
      next
    }
    coefficient <- paste0("groups",target)
    if (!(coefficient %in% colnames(design))) stop(paste("Missing group coefficient",coefficient))
    test <- glmQLFTest(fit,coef=coefficient)
    z <- topTags(test,n=Inf,sort.by="none")$table
    ix <- match(rownames(z),ids)
    if (anyNA(ix)) stop("Gene ID axis mismatch")
    tabout <- data.frame(gene_id=ids[ix],gene_symbol=symbols[ix],
                         log2FC=z$logFC,logCPM=z$logCPM,F=z$F,PValue=z$PValue,FDR=z$FDR)
    path <- file.path(out,paste0(pop,"__",contrast,".all_tested.tsv.gz"))
    con <- gzfile(path,"wt"); write.table(tabout,con,sep="\t",quote=FALSE,row.names=FALSE); close(con)
    hit <- !is.na(tabout$FDR) & tabout$FDR<0.10
    sig <- tabout[hit,]
    if (nrow(sig)>0L) {
      sig <- sig[order(sig$FDR,-abs(sig$log2FC)),]
      tops[[length(tops)+1L]] <- cbind(population=pop,contrast=contrast,head(sig,100L))
    }
    summaries[[length(summaries)+1L]] <- data.frame(
      population=pop,contrast=contrast,status="tested",n_control=unname(tab[ref]),
      n_target=unname(tab[target]),genes_tested=nrow(tabout),
      FDR_0_05=sum(tabout$FDR<0.05,na.rm=TRUE),FDR_0_10=sum(hit))
  }
  cat(pop,"completed\n"); flush.console()
}
write.table(do.call(rbind,support),file.path(out,"population_mouse_support.tsv"),
            sep="\t",quote=FALSE,row.names=FALSE)
summary <- do.call(rbind,summaries)
write.table(summary,file.path(out,"DEG_summary.tsv"),sep="\t",quote=FALSE,row.names=FALSE)
if (length(tops)) write.table(do.call(rbind,tops),file.path(out,"top_DEGs_FDR010.tsv"),
                              sep="\t",quote=FALSE,row.names=FALSE)
write_json(list(method="edgeR robust quasi-likelihood; raw integer mouse pseudobulks; TMM; sex + condition",
                selected_cells=22251,animals=20,subclusters=24,control=ref,targets=targets,
                mouse_min_cells_per_population=10,mouse_min_per_group=3,
                result_summary=summary),file.path(out,"method_and_summary.json"),auto_unbox=TRUE,pretty=TRUE)
writeLines(capture.output(sessionInfo()),file.path(out,"sessionInfo.txt"))
cat("PASS: gene DEG contrasts and mouse support tables written\n")
