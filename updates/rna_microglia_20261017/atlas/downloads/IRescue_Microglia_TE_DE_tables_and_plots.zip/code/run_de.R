args=commandArgs(trailingOnly=TRUE);stopifnot(length(args)==2)
src=normalizePath(args[1]);out=normalizePath(args[2]);dir.create(file.path(out,'tables'))
suppressPackageStartupMessages({library(edgeR);library(jsonlite);library(pheatmap)})
stopifnot(packageVersion('edgeR') >= '4.4.0')
put=function(x,n)write.table(x,file.path(out,'tables',n),sep='\t',quote=FALSE,row.names=FALSE,na='NA')
rd=function(p)read.delim(p,check.names=FALSE,stringsAsFactors=FALSE)
inp='/lisc/data/scratch/molecular_neurosciences/i-med/p5_Glial_TE_regulation_aging/te-RNA/IRescue_Microglia_locus_20261028/results'
targets=c('WT_6mo','WT_21mo','5xFAD_3mo','APOE4_TREM2_3mo')
meta=rd(file.path(src,'gene_exposures.tsv'));stopifnot(nrow(meta)==20,sum(meta$cells)==22251,!anyDuplicated(meta$animal),all(meta$gene_effective_depth>0))
full=rd(file.path(inp,'IRescue_locus_fit_subfamily_sums.tsv'));G=as.matrix(full[,-1]);rownames(G)=full[,1];storage.mode(G)='double'
stopifnot(identical(colnames(G),meta$animal),all(is.finite(G)),all(G>=0))
# Infer composition factors from ALL 1,075 TE subfamilies, never the selected peak-bound subset.
global=DGEList(G);global=calcNormFactors(global,method='TMMwsp')
meta$TE_total_expected_UMIs=colSums(G);meta$TE_TMMwsp_factor=global$samples$norm.factors
meta$TE_TMMwsp_effective_depth=global$samples$lib.size*global$samples$norm.factors
put(meta,'normalization_and_mouse_metadata.tsv')

# Allocated known-effect API check: fractional data, sex-adjusted QL, expected effect signs.
set.seed(428);fm=data.frame(sex=factor(rep(c('female','female','male','male'),2)),condition=factor(rep(c('control','target'),each=4)))
fd=model.matrix(~sex+condition,fm);fc=matrix(rnbinom(240*8,mu=80,size=20),240,8)+0.125
fc[1:30,5:8]=fc[1:30,5:8]*8;fc[31:60,5:8]=fc[31:60,5:8]/8
fy=DGEList(fc,lib.size=rep(1e6,8));ff=glmQLFit(fy,fd,robust=TRUE,legacy=FALSE);ft=glmQLFTest(ff,coef=3)$table
stopifnot(length(ff$s2.post)==nrow(fc),length(ff$df.prior)%in%c(1L,nrow(fc)),length(ff$df.residual.adj)==nrow(fc),all(is.finite(ff$s2.post)),any(fc%%1>0),median(ft$logFC[1:30])>2,median(ft$logFC[31:60])< -2,all(is.finite(ft$PValue)))
write_json(list(status='passed_allocated_fractional_QL_fixture',features=240,sex_adjusted=TRUE,rounding=FALSE,edgeR=as.character(packageVersion('edgeR'))),file.path(out,'fixture.json'),auto_unbox=TRUE,pretty=TRUE)

summaries=list();globalP=list();qcAll=list();normAgreement=list();unionAnn=list();pairMatrices=list()
for(t in targets){
 z=rd(gzfile(file.path(inp,paste0('IRescue_WT_3mo_vs_',t,'.TE_RNA_counts.tsv.gz'))))
 ann=z[,1:8];Y=as.matrix(z[,-(1:8)]);storage.mode(Y)='double';rownames(Y)=ann$TE_locus
 m=meta[match(colnames(Y),meta$animal),];stopifnot(identical(m$animal,colnames(Y)),nrow(m)==8,all(is.finite(Y)),all(Y>=0),!anyDuplicated(rownames(Y)))
 m$condition=factor(m$condition,levels=c('WT_3mo',t));m$sex=factor(m$sex,levels=c('female','male'));rownames(m)=m$animal
 stopifnot(all(table(m$condition,m$sex)==2));design=model.matrix(~sex+condition,m);stopifnot(qr(design)$rank==3)
 put(data.frame(animal=m$animal,design,check.names=FALSE),paste0(t,'.design.tsv'))
 # Filter determined by abundance and group sizes only, using fixed gene exposure; shared across normalizations.
 y0=DGEList(Y,lib.size=m$gene_effective_depth)
 keep=filterByExpr(y0,group=m$condition,min.count=5,min.total.count=15)
 stopifnot(sum(keep)>=30)
 models=list()
 for(nm in c('gene_TMM_primary','TE_TMMwsp_sensitivity')){
  exposure=if(nm=='gene_TMM_primary')m$gene_effective_depth else m$TE_TMMwsp_effective_depth
  y=DGEList(Y[keep,,drop=FALSE],lib.size=exposure)
  cache=file.path(dirname(out),'results_v3',paste0(t,'.',nm,'.fit.rds'))
  if(t=='WT_6mo'){
   stopifnot(file.exists(cache));fit=readRDS(cache);stopifnot(identical(fit$counts,y$counts),identical(fit$design,design),max(abs(as.matrix(fit$offset)-matrix(log(exposure),nrow=nrow(y),ncol=ncol(y),byrow=TRUE)))<1e-10)
   cat('REUSED_COMPLETED_FIT',t,nm,'\n')
  } else fit=glmQLFit(y,design,robust=TRUE,legacy=FALSE)
  stopifnot(length(fit$s2.post)==nrow(y),length(fit$df.prior)%in%c(1L,nrow(y)),length(fit$df.residual.adj)==nrow(y))
  saveRDS(fit,file.path(out,paste0(t,'.',nm,'.fit.rds')))
  test=glmQLFTest(fit,coef=3);res=topTags(test,n=Inf,sort.by='none')$table
  stopifnot(identical(rownames(res),rownames(Y)[keep]),all(is.finite(res$PValue)),all(res$PValue>=0 & res$PValue<=1),all(is.finite(res$logFC)))
  tab=cbind(ann,total_expected_count=rowSums(Y),mice_at_least_5=rowSums(Y>=5),status=ifelse(rowSums(Y)==0,'all_zero',ifelse(keep,'tested','low_expression')),
       log2FC=NA_real_,logCPM=NA_real_,QL_F=NA_real_,PValue=NA_real_,FDR=NA_real_,normalization=nm)
  tab[keep,c('log2FC','logCPM','QL_F','PValue','FDR')]=res[,c('logFC','logCPM','F','PValue','FDR')]
  # BH within the prespecified tested TE-copy set for this comparison; zero/low rows retain NA.
  stopifnot(max(abs(tab$FDR[keep]-p.adjust(tab$PValue[keep],method='BH')))<1e-12)
  put(tab,paste0(t,'.',nm,'.all_TE_results.tsv'))
  for(q in c(.05,.1)){
   sig=tab[keep & !is.na(tab$FDR) & tab$FDR<q,,drop=FALSE];sig=sig[order(sig$FDR,-abs(sig$log2FC)),]
   put(sig,paste0(t,'.',nm,'.FDR',if(q==.05)'005' else '010','.tsv'))
  }
  models[[nm]]=tab
  summaries[[paste(t,nm)]]=data.frame(target=t,normalization=nm,TE_loci=nrow(Y),tested=sum(keep),all_zero=sum(rowSums(Y)==0),low_expression=sum(!keep & rowSums(Y)>0),
     up_FDR005=sum(res$FDR<.05 & res$logFC>0),down_FDR005=sum(res$FDR<.05 & res$logFC<0),up_FDR010=sum(res$FDR<.1 & res$logFC>0),down_FDR010=sum(res$FDR<.1 & res$logFC<0),
     min_p=min(res$PValue),min_FDR=min(res$FDR),residual_df=nrow(m)-ncol(design),common_NB_dispersion=as.numeric(fit$dispersion)[1],QL_df_prior_median=median(fit$df.prior),QL_variance_median=median(fit$s2.post))
  if(nm=='gene_TMM_primary'){
   globalP[[t]]=data.frame(target=t,TE_locus=rownames(Y)[keep],PValue=res$PValue,FDR_within_contrast=res$FDR)
   put(data.frame(TE_locus=rownames(Y)[keep],NB_dispersion=fit$dispersion,QL_var=fit$s2.post,QL_df_prior=fit$df.prior,QL_df_residual_adjusted=fit$df.residual.adj),paste0(t,'.fit_diagnostics.tsv'))
   pdf(file.path(out,paste0(t,'.QL_diagnostics.pdf')),width=10,height=5);par(mfrow=c(1,2));plotQLDisp(fit,main=paste(t,'QL dispersion'));plotMD(test,main=paste(t,'mean difference'));abline(h=0,lty=2);dev.off()
  }
 }
 a=models[[1]];b=models[[2]];ok=keep
 normAgreement[[t]]=data.frame(target=t,logFC_Spearman=cor(a$log2FC[ok],b$log2FC[ok],method='spearman'),sign_agreement=mean(sign(a$log2FC[ok])==sign(b$log2FC[ok])),primary_q10=sum(a$FDR<.1,na.rm=TRUE),sensitivity_q10=sum(b$FDR<.1,na.rm=TRUE),both_q10=sum(a$FDR<.1 & b$FDR<.1,na.rm=TRUE))
 # Primary normalized counts used for all heatmaps; raw matrices are never changed.
 norm=sweep(Y,2,m$gene_effective_depth,'/')*1e6
 put(data.frame(ann,norm,check.names=FALSE),paste0(t,'.gene_normalized_CPM.tsv'))
 primary=models[[1]];sel=which(keep & !is.na(primary$FDR) & primary$FDR<.1)
 sel=sel[order(primary$FDR[sel],-abs(primary$log2FC[sel]))]
 if(length(sel)){
  # All significant copies, plus a readable top-50 view. No fallback mislabeled as differential.
  for(view in c('all_FDR010','top50_FDR010')){
   ix=if(view=='top50_FDR010')head(sel,50) else sel
   h=log2(1+norm[ix,,drop=FALSE]);h=t(scale(t(h)));h[!is.finite(h)]=0
   labels=paste(primary$TE_subfamily[ix],primary$TE_locus[ix],sep=' | ')
   h[h>2.5]=2.5;h[h< -2.5]= -2.5;rownames(h)=labels
   ac=data.frame(condition=m$condition,sex=m$sex,row.names=m$animal)
   for(ext in c('pdf')){
    fn=file.path(out,paste0(t,'.heatmap_',view,'.',ext));if(ext=='pdf')pdf(fn,width=12,height=if(view=='top50_FDR010')13 else 16) else png(fn,width=1800,height=if(view=='top50_FDR010')1900 else 2200,res=150)
    pheatmap(h,color=colorRampPalette(c('#3288bd','white','#d53e4f'))(101),breaks=seq(-2.5,2.5,length.out=102),annotation_col=ac,cluster_cols=FALSE,cluster_rows=nrow(h)>1,
      show_rownames=view=='top50_FDR010',labels_col=m$animal,fontsize_row=6,main=paste(t,'vs WT_3mo | primary FDR < 0.10',view),border_color=NA,silent=FALSE)
    dev.off()
   }
  }
 }
 put(primary[sel,,drop=FALSE],paste0(t,'.heatmap_selected_loci.tsv'))
 # Sample QC on expressed rows only. Mice remain distinct and the condition is never corrected away.
 logx=cpm(y0,log=TRUE,prior.count=2);pca=prcomp(t(logx[keep,,drop=FALSE]),center=TRUE,scale.=FALSE)
 put(data.frame(m[,c('animal','condition','sex','cells')],PC1=pca$x[,1],PC2=pca$x[,2],relative_log_expression=apply(logx[keep,,drop=FALSE]-apply(logx[keep,,drop=FALSE],1,median),2,median)),paste0(t,'.sample_QC.tsv'))
 qcAll[[t]]=data.frame(target=t,PC1_variance=summary(pca)$importance[2,1],PC2_variance=summary(pca)$importance[2,2],samples=8,design_rank=3,excluded_mice=0)
 cat('COMPLETED_COMPARISON',t,'tested',sum(keep),'of',nrow(Y),'\n')
}
allp=do.call(rbind,globalP);allp$FDR_across_four_contrasts=p.adjust(allp$PValue,'BH');put(allp,'primary_FDR_across_four_contrasts.tsv')
put(do.call(rbind,summaries),'DE_summary.tsv');put(do.call(rbind,normAgreement),'normalization_sensitivity.tsv');put(do.call(rbind,qcAll),'sample_QC_summary.tsv')
capture.output(sessionInfo(),file=file.path(out,'R_sessionInfo.txt'))
write_json(list(status='completed_R_models',replicate='mouse',normalization_primary='independent gene-derived TMM effective depth',normalization_sensitivity='TMMwsp from all 1075 IRescue locus-fit subfamily sums',design='~ sex + condition',fractional_counts_preserved=TRUE,targets=targets),file.path(out,'models_COMPLETE.json'),auto_unbox=TRUE,pretty=TRUE)
