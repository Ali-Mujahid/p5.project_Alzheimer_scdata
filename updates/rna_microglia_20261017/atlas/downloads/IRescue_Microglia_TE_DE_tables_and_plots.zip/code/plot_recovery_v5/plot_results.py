import csv,json,sys,zipfile,hashlib
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
ROOT=Path(sys.argv[1]);R=ROOT/'results_v5';T=R/'tables'
targets=['WT_6mo','WT_21mo','5xFAD_3mo','APOE4_TREM2_3mo']
read=lambda p:list(csv.DictReader(p.open(),delimiter='\t'))
def number(x):return None if x in ('NA','NaN','Inf','-Inf','') else float(x)
data={'status':'completed','primary':'gene_TMM_primary','model':'edgeR 4.8 robust quasi-likelihood; sex + condition','replicate':'mouse','comparisons':[]}
summary=read(T/'DE_summary.tsv')
plt.rcParams.update({'pdf.fonttype':42,'font.size':10})
fig,axs=plt.subplots(2,2,figsize=(14,11),layout='constrained')
for t,ax in zip(targets,axs.flat):
 rows=read(T/f'{t}.gene_TMM_primary.all_TE_results.tsv');tested=[r for r in rows if r['status']=='tested']
 x=np.array([float(r['log2FC']) for r in tested]);q=np.array([float(r['FDR']) for r in tested]);p=np.array([float(r['PValue']) for r in tested])
 colors=np.where(q<.05,np.where(x>0,'#d53e4f','#3288bd'),np.where(q<.1,'#b88a29','#aaa'))
 ax.scatter(x,-np.log10(np.maximum(q,1e-300)),s=10,c=colors,alpha=.65,rasterized=True)
 ax.axhline(-np.log10(.05),color='#555',ls='--',lw=.8);ax.axhline(-np.log10(.1),color='#b88a29',ls=':',lw=.8);ax.axvline(0,color='#888',lw=.7)
 ax.set(xlabel='log₂ fold change: target / WT_3mo',ylabel='−log₁₀ BH-adjusted P-value',title=f'{t}: {len(tested):,} tested / {len(rows):,} TE copies')
 for i in np.argsort(q)[:5]:
  if q[i]<.1:ax.annotate(tested[i]['TE_subfamily'],(x[i],-np.log10(max(q[i],1e-300))),fontsize=7,xytext=(3,4),textcoords='offset points')
 ax.grid(alpha=.12)
 sig=[r for r in tested if float(r['FDR'])<.1];sig.sort(key=lambda r:float(r['FDR']))
 h=read(T/f'{t}.gene_normalized_CPM.tsv');hby={r['TE_locus']:r for r in h};mice=list(h[0])[8:]
 display=sig[:50]
 heat=[]
 for r in display:
  values=np.log2(1+np.array([float(hby[r['TE_locus']][a]) for a in mice]));sd=values.std(ddof=1)
  heat.append({'label':r['TE_subfamily']+' | '+r['TE_locus'],'z':((values-values.mean())/sd if sd else values*0).tolist()})
 data['comparisons'].append({'target':t,'summary':[s for s in summary if s['target']==t],
  'volcano':[{'locus':r['TE_locus'],'TE_subfamily':r['TE_subfamily'],'TE_family':r['TE_family'],'TE_class':r['TE_class'],'log2FC':float(r['log2FC']),'FDR':float(r['FDR']),'PValue':float(r['PValue'])}for r in tested],
  'mice':mice,'heatmap':heat,'significant_loci_FDR010':len(sig),'total_loci':len(rows),'tested_loci':len(tested)})
 # Headless PNG previews; authoritative clustered heatmaps are the R pheatmap PDFs.
 if sig:
  from matplotlib.colors import LinearSegmentedColormap
  cmap=LinearSegmentedColormap.from_list('user_blue_red',['#3288bd','white','#d53e4f'])
  for view in ['all_FDR010','top50_FDR010']:
   selected=sig[:50] if view=='top50_FDR010' else sig
   mat=np.log2(1+np.array([[float(hby[r['TE_locus']][a])for a in mice]for r in selected]));sd=mat.std(axis=1,ddof=1);sd[sd==0]=1;mat=(mat-mat.mean(axis=1,keepdims=True))/sd[:,None]
   f,a=plt.subplots(figsize=(12,14),layout='constrained');im=a.imshow(mat,aspect='auto',cmap=cmap,vmin=-2.5,vmax=2.5,interpolation='nearest')
   a.set_xticks(range(8),mice,rotation=55,ha='right',fontsize=8)
   if view=='top50_FDR010':a.set_yticks(range(len(selected)),[r['TE_subfamily']+' | '+r['TE_locus']for r in selected],fontsize=5)
   else:a.set_yticks([])
   a.set_title(t+' vs WT_3mo | FDR <0.10\nPreview ordered by FDR; clustered version in PDF')
   f.colorbar(im,ax=a,label='Row z-score of log2(1+gene-normalized CPM)');f.savefig(R/f'{t}.heatmap_{view}.png',dpi=150);plt.close(f)
 # Always emit a clearly labeled heatmap page, even when no copies pass the exploratory threshold.
 if not sig:
  for view in ['all_FDR010','top50_FDR010']:
   f,a=plt.subplots(figsize=(12,7));a.axis('off');a.text(.5,.5,f'{t} vs WT_3mo\nNo TE copies pass FDR < 0.10\nNo nonsignificant copies substituted.',ha='center',va='center',fontsize=18)
   f.savefig(R/f'{t}.heatmap_{view}.pdf');f.savefig(R/f'{t}.heatmap_{view}.png',dpi=150);plt.close(f)
fig.suptitle('IRescue Microglia TE-copy differential expression | four mice per condition\nSex-adjusted edgeR QL; gene-derived TMM exposure; red/blue FDR < 0.05, gold exploratory FDR < 0.10',fontsize=14)
fig.savefig(R/'IRescue_Microglia_TE_DE_volcanoes.pdf');fig.savefig(R/'IRescue_Microglia_TE_DE_volcanoes.png',dpi=150);plt.close(fig)
# Matched sample diagnostics, without removing biological condition effects.
fig,axs=plt.subplots(2,2,figsize=(12,10),layout='constrained')
for t,ax in zip(targets,axs.flat):
 rows=read(T/f'{t}.sample_QC.tsv')
 for i,r in enumerate(rows):
  ax.scatter(float(r['PC1']),float(r['PC2']),c='#3288bd' if r['condition']=='WT_3mo' else '#d53e4f',marker='o' if r['sex']=='female' else '^',s=65)
  ax.annotate(r['animal'].replace('female','F').replace('male','M'),(float(r['PC1']),float(r['PC2'])),fontsize=6,xytext=(3,3),textcoords='offset points')
 ax.set(title=t,xlabel='PC1: gene-normalized log counts',ylabel='PC2');ax.grid(alpha=.15)
fig.suptitle('Sample QC: each point is one mouse; no mice removed',fontsize=14)
fig.savefig(R/'IRescue_Microglia_TE_DE_sample_QC.pdf');fig.savefig(R/'IRescue_Microglia_TE_DE_sample_QC.png',dpi=150);plt.close(fig)
(R/'irescue_microglia_DE.json').write_text(json.dumps(data,allow_nan=False,separators=(',',':'))+'\n')
print('PLOTS_AND_INTERACTIVE_DATA_COMPLETE',flush=True)
