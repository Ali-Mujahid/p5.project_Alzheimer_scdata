import hashlib,json,os,shutil,subprocess,time
from pathlib import Path
import resource_guard as g
ROOT=Path.cwd();SRC=Path(__file__).resolve().parent;OLD=ROOT/'results_v4';OUT=ROOT/'results_v5'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert not OUT.exists() and json.load(open(OLD/'models_COMPLETE.json'))['status']=='completed_R_models'
for name,h in json.load(open(SRC/'manifest.json')).items():assert sha(SRC/name)==h
modelmanifest=json.load(open(ROOT/'source_v4/manifest.json'))
for name,h in modelmanifest['source'].items():assert sha(ROOT/'source_v4'/name)==h
for name,h in modelmanifest['inputs'].items():assert sha(Path(modelmanifest['input_root'])/name)==h
g.ROOT=ROOT;finish=g.guard('plot_recovery_'+os.environ['SLURM_JOB_ID']);OUT.mkdir()
inventory={}
for p in OLD.rglob('*'):
    if p.is_file() and p.name not in ['FAILED.json','started.json']:
        rel=p.relative_to(OLD);inventory[str(rel)]=sha(p);d=OUT/rel;d.parent.mkdir(exist_ok=True,parents=True);shutil.copy2(p,d);assert sha(d)==inventory[str(rel)]
g.save(OUT/'models_reused.json',{'completed_model_job':'7752846','count_matrices_unchanged':True,'no_statistical_refits':True,'copied_output_sha256':inventory})
env=os.environ.copy()
for key in ['PYTHONPATH','PYTHONHOME','PYTHONPYCACHEPREFIX']:env.pop(key,None)
r=subprocess.run([g.PYTHON,'-B',str(SRC/'plot_results.py'),str(ROOT)],stdin=subprocess.DEVNULL,env=env);assert r.returncode==0,'Isolated plotter failed'
for name,h in inventory.items():assert sha(OLD/name)==h
for name,h in modelmanifest['inputs'].items():assert sha(Path(modelmanifest['input_root'])/name)==h
finish()
g.save(OUT/'COMPLETE.json',{'status':'completed','job_id':os.environ['SLURM_JOB_ID'],'model_job_id':'7752846','model_source_manifest_sha256':sha(ROOT/'source_v4/manifest.json'),'plot_source_manifest_sha256':sha(SRC/'manifest.json'),'inputs_unchanged':True,'mice':20,'cells':22251,'comparisons':4,'plots_completed':True,'statistical_refits_in_recovery':False})
