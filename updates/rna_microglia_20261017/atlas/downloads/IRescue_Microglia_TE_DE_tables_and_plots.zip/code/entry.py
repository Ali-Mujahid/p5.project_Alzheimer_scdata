import hashlib,json,os,subprocess,time
from pathlib import Path
import resource_guard as g
ROOT=Path.cwd();SRC=Path(__file__).resolve().parent;OUT=ROOT/'results_v4'
assert os.environ['SLURM_JOB_ID'].isdigit() and not OUT.exists()
OUT.mkdir()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
manifest=json.load(open(SRC/'manifest.json'))
for name,h in manifest['source'].items():assert sha(SRC/name)==h,name
for name,h in manifest['inputs'].items():assert sha(Path(manifest['input_root'])/name)==h,name
g.ROOT=ROOT
finish=g.guard('DE_'+os.environ['SLURM_JOB_ID'])
g.save(OUT/'started.json',{'job_id':os.environ['SLURM_JOB_ID'],'manifest_sha256':sha(SRC/'manifest.json'),'time':time.time()})
try:
    r=subprocess.run(['Rscript','--vanilla',str(SRC/'run_de.R'),str(SRC),str(OUT)],stdin=subprocess.DEVNULL)
    assert r.returncode==0,'R modeling failed; preserve partials'
    r=subprocess.run([g.PYTHON,'-B',str(SRC/'plot_results.py'),str(ROOT)],stdin=subprocess.DEVNULL)
    assert r.returncode==0,'Plotting failed; preserve fitted models'
    for name,h in manifest['inputs'].items():assert sha(Path(manifest['input_root'])/name)==h,name
    finish()
    g.save(OUT/'COMPLETE.json',{'status':'completed','job_id':os.environ['SLURM_JOB_ID'],'source_manifest_sha256':sha(SRC/'manifest.json'),'inputs_unchanged':True,'mice':20,'cells':22251,'comparisons':4,'plots_completed':True})
except BaseException as e:
    g.save(OUT/'FAILED.json',{'error':repr(e),'job_id':os.environ['SLURM_JOB_ID']});raise
