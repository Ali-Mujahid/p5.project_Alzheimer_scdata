#!/usr/bin/env python3
"""Plot the verified mouse-level TE-overlapping peak signal table."""
import csv
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D


HERE = Path(__file__).resolve().parent
ROWS = list(csv.DictReader((HERE / "mouse_TE_peak_signal_share.tsv").open(), delimiter="\t"))
GROUPS = ["WT_3mo", "WT_6mo", "WT_21mo", "5xFAD_3mo", "APOE4_TREM2_3mo"]
assert len(ROWS) == 20 and len({r["animal_id"] for r in ROWS}) == 20
assert all(sum(r["condition"] == group for r in ROWS) == 4 for group in GROUPS)
assert all(sorted(r["sex"] for r in ROWS if r["condition"] == group) ==
           ["female", "female", "male", "male"] for group in GROUPS)
assert all(abs(100 * int(r["TE_peak_overlap_counts"]) /
                   int(r["all_peak_overlap_counts"]) -
                   float(r["TE_peak_signal_percent"])) < 1e-9 for r in ROWS)

fig, ax = plt.subplots(figsize=(10.5, 5.8))
fig.subplots_adjust(left=.09, right=.98, top=.88, bottom=.27)
values = [[float(r["TE_peak_signal_percent"]) for r in ROWS
           if r["condition"] == group] for group in GROUPS]
boxes = ax.boxplot(values, patch_artist=True, widths=.58, showfliers=False,
                   medianprops={"color": "#102f35", "linewidth": 1.8},
                   whiskerprops={"color": "#5d767c"},
                   capprops={"color": "#5d767c"})
for idx, patch in enumerate(boxes["boxes"]):
    patch.set(facecolor="#236f78" if idx == 0 else "#c8dee2", edgecolor="#57777d")
for idx, group in enumerate(GROUPS, 1):
    these = sorted((r for r in ROWS if r["condition"] == group),
                   key=lambda r: (r["sex"], r["replicate"]))
    for row, offset in zip(these, [-.16, -.055, .055, .16]):
        ax.scatter(idx + offset, float(row["TE_peak_signal_percent"]), s=40,
                   color="#a22f6d" if row["sex"] == "female" else "#245b98",
                   edgecolor="white", linewidth=.6, zorder=3)
ax.set_xticks(range(1, 6), ["WT 3 mo", "WT 6 mo", "WT 21 mo", "5xFAD 3 mo", "APOE4/TREM2 3 mo"])
ax.tick_params(axis="x", labelrotation=15)
ax.set_ylabel("TE-overlapping peak signal / all peak signal (%)")
ax.set_title("Microglia ATAC signal at TE-overlapping peaks", fontsize=16, pad=16)
ax.set_ylim(53.65, 54.67)
ax.grid(axis="y", color="#e1e9e9", linewidth=.8)
ax.set_axisbelow(True)
ax.legend(handles=[Line2D([0], [0], marker="o", color="none", markerfacecolor="#a22f6d",
                          markeredgecolor="white", markersize=8, label="Female"),
                   Line2D([0], [0], marker="o", color="none", markerfacecolor="#245b98",
                          markeredgecolor="white", markersize=8, label="Male")],
          loc="upper right", frameon=False, ncol=2)
fig.text(.5, .08, "Four mice per group · narrow y-axis · descriptive signal share",
         ha="center", fontsize=10, color="#405b61")
fig.text(.5, .04, "Nonexclusive common-peak overlap counts; not unique TE fragments or copy-normalized enrichment.",
         ha="center", fontsize=9, color="#405b61")
fig.savefig(HERE / "WT3mo_vs_four_groups_TE_peak_signal_boxplot_reviewed.pdf")
fig.savefig(HERE / "WT3mo_vs_four_groups_TE_peak_signal_boxplot_reviewed.png", dpi=160)
