#!/usr/bin/env Rscript
options(warn = 2)
suppressPackageStartupMessages({
  library(Matrix)
  library(MAnorm2)
})
args <- commandArgs(trailingOnly = TRUE)
stopifnot(length(args) == 2L)
source_dir <- args[[1L]]
out_dir <- args[[2L]]
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
read_tsv <- function(p) read.delim(p, check.names = FALSE, stringsAsFactors = FALSE)
peaks <- read_tsv(file.path(source_dir, 'merged/combined/peaks.tsv'))
mice <- read_tsv(file.path(source_dir, 'merged/mice.tsv'))
ann <- read_tsv(file.path(source_dir, 'TE_annotation/combined_peak_TE_annotation.tsv'))
con <- gzfile(file.path(source_dir, 'merged/combined/counts.mtx.gz'), 'rt')
counts <- as(Matrix::readMM(con), 'dgCMatrix')
close(con)
stopifnot(nrow(peaks) == 335546L, nrow(ann) == nrow(peaks),
          identical(peaks$peak_id, ann$peak_id),
          identical(dim(counts), c(nrow(peaks), nrow(mice))),
          nrow(mice) == 20L, length(unique(mice$animal_id)) == 20L,
          all(peaks$assembly == 'mm10'), all(!is.na(counts@x)),
          all(counts@x >= 0), all(counts@x == floor(counts@x)))
groups <- c('WT_3mo', 'WT_6mo', 'WT_21mo', '5xFAD_3mo', 'APOE4_TREM2_3mo')
stopifnot(identical(sort(unique(mice$condition)), sort(groups)),
          all(table(mice$condition) == 4L),
          all(vapply(groups, function(g) identical(sort(mice$sex[mice$condition == g]),
                                                  c('female','female','male','male')), logical(1L))))
is_te <- ann$TE_overlap == 'True' | ann$TE_overlap == TRUE
stopifnot(!anyNA(is_te), sum(is_te) == 176629L)
total_signal <- Matrix::colSums(counts)
te_signal <- Matrix::colSums(counts[is_te, , drop = FALSE])
stopifnot(all(total_signal > 0), all(te_signal <= total_signal))
box <- data.frame(mice, all_peak_overlap_counts = as.numeric(total_signal),
                  TE_peak_overlap_counts = as.numeric(te_signal),
                  TE_peak_signal_percent = 100 * as.numeric(te_signal / total_signal),
                  endpoint = 'Nonexclusive TE-overlapping peak signal share; not unique TE fragments')
write.table(box, file.path(out_dir, 'mouse_TE_peak_signal_share.tsv'), sep='\t',
            row.names=FALSE, quote=FALSE, na='NA')
pdf(file.path(out_dir, 'WT3mo_vs_four_groups_TE_peak_signal_boxplots.pdf'),
    width=11, height=8.5, onefile=TRUE)
par(mar=c(9,5,4,1))
values <- lapply(groups, function(g) box$TE_peak_signal_percent[box$condition == g])
names(values) <- groups
boxplot(values, las=2, col=c('#1f6f70', rep('#c8dee2',4)),
        ylab='TE-overlapping peak signal / all peak signal (%)',
        main='Mouse-level descriptive TE-associated ATAC signal · four mice/group')
for (j in seq_along(groups)) stripchart(values[[j]], at=j, add=TRUE, vertical=TRUE,
                                         method='jitter', jitter=.08, pch=19,
                                         col=ifelse(box$sex[box$condition==groups[[j]]]=='female',
                                                    '#ae4c7e','#245b98'))
mtext('Nonexclusive peak-overlap counts; each mouse is one replicate. Female pink; male blue.',
      side=1, line=7, cex=.75)
for (g in groups[-1L]) {
  boxplot(values[c('WT_3mo',g)], las=2, col=c('#1f6f70','#c8dee2'),
          ylab='TE-overlapping peak signal share (%)',
          main=paste('WT_3mo versus',g,'· descriptive'))
  stripchart(values[c('WT_3mo',g)], add=TRUE, vertical=TRUE,
             method='jitter', jitter=.08, pch=19, col='#245b98')
}
dev.off()

# The occupancy proxy below is explicitly count-positive, not an independently
# called per-mouse peak. MAnorm2 results must be treated as exploratory.
eligible <- Matrix::rowSums(counts >= 10) >= 4L
stopifnot(sum(eligible) > 1000L)
mat <- as.matrix(counts[eligible, , drop=FALSE])
names_count <- paste0('mouse',seq_len(ncol(mat)),'.count')
names_occ <- paste0('mouse',seq_len(ncol(mat)),'.occupancy')
dat <- data.frame(chrom=peaks$chrom[eligible],
                  start=peaks$start[eligible],end=peaks$end[eligible],
                  mat, check.names=FALSE)
names(dat)[4:(3+ncol(mat))] <- names_count
for (j in seq_len(ncol(mat))) dat[[names_occ[[j]]]] <- as.integer(mat[,j] > 0)
autosome <- !dat$chrom %in% c('chrX','chrY','chrM')
stopifnot(sum(autosome) > 1000L)
norm <- MAnorm2::normalize(dat, count=4:(3+ncol(mat)), occupancy=(4+ncol(mat)):(3+2*ncol(mat)),
                           common.peak.regions=autosome,
                           baseline='pseudo-reference')
conds <- setNames(lapply(groups, function(g) {
  j <- which(mice$condition == g)
  MAnorm2::bioCond(norm[3+j], norm[3+ncol(mat)+j], name=g)
}), groups)
conds <- MAnorm2::normBioCond(conds, common.peak.regions=autosome)
fit_method <- 'parametric'
conds <- tryCatch(MAnorm2::fitMeanVarCurve(conds,method='parametric',occupy.only=TRUE),
                  error=function(e) {fit_method <<- paste('local_after_parametric_error:',conditionMessage(e));
                    MAnorm2::fitMeanVarCurve(conds,method='local',occupy.only=TRUE)})
saveRDS(list(conditions=conds, eligible_peak_ids=peaks$peak_id[eligible],
             occupancy='count_positive_proxy', fit_method=fit_method),
        file.path(out_dir,'manorm2_fit.rds'))
omni <- MAnorm2::aovBioCond(conds)
stopifnot(nrow(omni) == sum(eligible))
omni_out <- data.frame(peaks[eligible,],TE_overlap=is_te[eligible],omni,check.names=FALSE)
write.table(omni_out[omni_out$TE_overlap,],file.path(out_dir,'TE_bound_peaks_five_group_MAnorm2_omnibus.tsv'),
            sep='\t',row.names=FALSE,quote=FALSE,na='NA')
summary_rows <- list()
for (g in groups[-1L]) {
  res <- MAnorm2::diffTest(conds[['WT_3mo']],conds[[g]])
  stopifnot(nrow(res)==sum(eligible))
  res$padj_all_eligible_peaks <- p.adjust(res$pval,method='BH')
  res$padj_TE_bound_only <- NA_real_
  res$padj_TE_bound_only[is_te[eligible]] <- p.adjust(res$pval[is_te[eligible]],method='BH')
  row <- data.frame(peaks[eligible,],TE_overlap=is_te[eligible],res,check.names=FALSE)
  te_row <- row[row$TE_overlap,,drop=FALSE]
  file <- paste0('TE_bound_peaks_',g,'_vs_WT_3mo_MAnorm2.tsv')
  write.table(te_row,file.path(out_dir,file),sep='\t',row.names=FALSE,quote=FALSE,na='NA')
  summary_rows[[g]] <- data.frame(comparison=paste(g,'vs WT_3mo'),
       tested_all_eligible_peaks=nrow(row),TE_bound_eligible_peaks=nrow(te_row),
       TE_bound_q05_all_peak_scope=sum(te_row$padj_all_eligible_peaks<.05,na.rm=TRUE),
       TE_bound_q10_all_peak_scope=sum(te_row$padj_all_eligible_peaks<.1,na.rm=TRUE),
       TE_bound_q05_TE_only_scope=sum(te_row$padj_TE_bound_only<.05,na.rm=TRUE),
       TE_bound_q10_TE_only_scope=sum(te_row$padj_TE_bound_only<.1,na.rm=TRUE))
}
write.table(do.call(rbind,summary_rows),file.path(out_dir,'MAnorm2_TE_peak_summary.tsv'),
            sep='\t',row.names=FALSE,quote=FALSE)
writeLines(c(paste('MAnorm2',as.character(packageVersion('MAnorm2'))),
             paste('Eligible peaks',sum(eligible)),paste('Eligible TE peaks',sum(eligible & is_te)),
             paste('Fit method',fit_method),'Occupancy proxy: count > 0, not independent peak calls',
             'Inference exploratory; condition groups are sex balanced (2F,2M) but sex is not modeled',
             capture.output(sessionInfo())),file.path(out_dir,'methods_and_session.txt'))
