Microglia ATAC signal at RepeatMasker TE loci with target-group peak calls and no WT_3mo peak call.
The 14,639-locus panel is the WT_6mo-only set among all five groups, not a WT_3mo-specific TE set.
All five groups, including WT_3mo control, are measured on the identical loci within each panel.
Each animal track is an input bigWig; its generation and normalization must be checked separately before cross-sample inference.
A missing peak call is distinct from zero coverage; zero signal values are assigned only to uncovered bases in present chromosomes.
Locus boxes summarize four-mouse mean signal across TE loci. Mouse boxes summarize four independent mice per group.
No p-values or differential-accessibility claims are made from these descriptive plots.
