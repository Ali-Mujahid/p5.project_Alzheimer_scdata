"""Allocated aggregation of IRescue expected locus UMIs; Stellarscope stays separate."""
import sys,csv,gzip,json,hashlib,collections,os,math,zipfile
from pathlib import Path
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'source'))
from runtime import *
activate()
finish=guard('merge_and_compare')
reference_binding=json.load(open(ROOT/'reference/reference.json'))
assert sha(ROOT/'reference/mm10.TE_loci.BED6')==reference_binding['BED_sha256'], 'Shared TE reference changed since setup'
for name,h in json.load(open(HERE/'analysis_manifest.json')).items():assert sha(HERE/name)==h,name
import numpy as np
from scipy.stats import spearmanr
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.colors import LinearSegmentedColormap
OUT=ROOT/'results';OUT.mkdir(exist_ok=False)
summ=json.load(open(SRC/'stellarscope_summary.json'));meta=summ['per_mouse'];animals=[m['animal'] for m in meta]
targets=['WT_6mo','WT_21mo','5xFAD_3mo','APOE4_TREM2_3mo'];groups=['WT_3mo',*targets]
assert len(meta)==20 and sum(m['cells'] for m in meta)==22251
reports=[json.load(open(ROOT/'animals'/a/'COMPLETE.json')) for a in animals]
assert [r['animal'] for r in reports]==animals and all(r['EM_nonconverged']==0 for r in reports)
for r in reports:
    assert identity(r['source']['path'])==r['source'] and r['source_unchanged']
    for c in r['calls']:
        assert c['returncode']==0
        # Original IRescue command logs were part of the successful producer validation.

membership=collections.defaultdict(set)
with (SRC/'locus_membership.tsv').open() as f:
    for r in csv.DictReader(f,delimiter='\t'):membership[r['set_id']].add(r['locus'])
selected=set.union(*membership.values());assert len(selected)==41965
ref=PROJECT/'te-RNA/Microglia_TE_locus_counts_20261025/source/te_loci.tsv';bef=identity(ref)
index={};names=[];submap={};subindex=[];selected_meta={};selected_index={}
with ref.open() as f:
    for i,r in enumerate(csv.DictReader(f,delimiter='\t')):
        key=r['locus_id'];assert key not in index;index[key]=i;names.append(key)
        subindex.append(submap.setdefault(r['subfamily'],len(submap)))
        coord=f"{r['chrom']}:{r['start']}:{r['end']}:{r['strand']}"
        if coord in selected:
            selected_meta[coord]=r;selected_index[coord]=i
assert len(names)==3651522 and len(selected_meta)==41965 and len(submap)==1075 and bef==identity(ref)
subindex=np.array(subindex,np.int32)
mat=np.zeros((len(names),20),np.float64);subcounts=np.zeros((1075,20),np.float64)
for j,a in enumerate(animals):
    p=ROOT/'animals'/a/'locus_expected_UMIs.tsv.gz';seen=set()
    with gzip.open(p,'rt',newline='') as f:
        for r in csv.DictReader(f,delimiter='\t'):
            key=r['TE_locus'];assert key in index and key not in seen;seen.add(key)
            v=float(r['expected_UMIs']);assert math.isfinite(v) and v>=0;mat[index[key],j]=v
    assert abs(mat[:,j].sum()-reports[j]['expected_UMIs_exported'])<=1e-8*max(1,mat[:,j].sum())
    subcounts[:,j]=np.bincount(subindex,weights=mat[:,j],minlength=1075)
    print('AGGREGATED',a,flush=True)
assert np.isfinite(mat).all() and (mat>=0).all()
with (SRC/'stellarscope_selected_counts.tsv').open() as f:
    rr=csv.reader(f,delimiter='\t');assert next(rr)[1:]==animals
    oldrows=list(rr)
coords=[r[0] for r in oldrows];st=np.array([r[1:] for r in oldrows],float)
coordpos={x:i for i,x in enumerate(coords)}
ir=mat[[selected_index[x] for x in coords],:]
with gzip.open(OUT/'IRescue_selected_TE_loci_all20_expected_UMIs.tsv.gz','wt') as f:
    w=csv.writer(f,delimiter='\t',lineterminator='\n');w.writerow(['locus',*animals])
    for name,row in zip(coords,ir):w.writerow([name,*[f'{v:.12g}' for v in row]])
with (OUT/'IRescue_locus_fit_subfamily_sums.tsv').open('w') as f:
    w=csv.writer(f,delimiter='\t',lineterminator='\n');w.writerow(['TE_subfamily',*animals])
    for sub,i in submap.items():w.writerow([sub,*[f'{v:.12g}' for v in subcounts[i]]])
with (HERE/'model_exposures.tsv').open() as f:exp=list(csv.DictReader(f,delimiter='\t'))
assert [r['animal'] for r in exp]==animals
depth=np.array([float(r['gene_effective_depth']) for r in exp]);assert (depth>0).all()
manifest={'method':'IRescue 1.2.0; PRIMARY','comparison_method':'Stellarscope 1.5 best_exclude; separate comparison','animals':animals,'selected_microglia_cells':22251,'capture_layers_per_cell':2,'loci_reference':3651522,'count_semantics':'fractional expected UMI-cluster allocations; not observed integer transcript counts','coordinate_semantics':'same BED0 RepeatMasker intervals; not reconstructed intact insertions','sets':[]}
boxrows=[];effectrows=[]
for target in targets:
    original=HERE/f'WT_3mo_vs_{target}.TE_RNA_counts.tsv'
    with original.open() as f:rr=csv.reader(f,delimiter='\t');head=next(rr);rows=list(rr)
    columns=head[8:];js=[animals.index(a) for a in columns];assert len(js)==8
    new=OUT/f'IRescue_WT_3mo_vs_{target}.TE_RNA_counts.tsv.gz'
    ii=[]
    with gzip.open(new,'wt',newline='') as f:
        w=csv.writer(f,delimiter='\t',lineterminator='\n');w.writerow(head)
        for row in rows:
            r=selected_meta[row[0].replace('-',':',1)];idx=index[r['locus_id']];ii.append(idx)
            assert row[1:4]==[r['chrom'],r['start'],r['end']]
            assert row[4:8]==[r['strand'],r['subfamily'],r['family'],r['te_class']]
            w.writerow([*row[:8],*[f'{v:.12g}' for v in mat[idx,js]]])
    key=target+'__target_only';assert len(rows)==len(membership[key])
    manifest['sets'].append({'target':target,'file':new.name,'rows':len(rows),'count_columns':columns,'sha256':sha(new),'column_sums':dict(zip(columns,mat[ii][:,js].sum(axis=0).tolist()))})
    # Same loci and same mice, with a fixed independent gene-derived exposure for both methods.
    locpos=[coordpos[x] for x in membership[key]]
    for method,x in [('IRescue',ir),('Stellarscope',st)]:
        for j in js:
            raw=float(x[locpos,j].sum());cpm=raw/depth[j]*1e6
            boxrows.append({'target':target,'method':method,'animal':animals[j],'group':meta[j]['group'],'sex':animals[j].rsplit('_',2)[1],'TE_loci':len(locpos),'raw_set_count':raw,'gene_effective_depth':depth[j],'set_count_per_million_gene_UMIs':cpm,'log2_1plus_gene_normalized_set_expression':math.log2(1+cpm)})
    cj=[j for j,m in enumerate(meta) if m['group']=='WT_3mo'];tj=[j for j,m in enumerate(meta) if m['group']==target]
    imean=ir/depth*1e6;smean=st/depth*1e6
    # One CPM pseudocount is a plotting convention, not a differential-expression test.
    ilfc=np.log2((imean[:,tj].mean(axis=1)+1)/(imean[:,cj].mean(axis=1)+1));slfc=np.log2((smean[:,tj].mean(axis=1)+1)/(smean[:,cj].mean(axis=1)+1))
    use=(ir.sum(axis=1)>=5)|(st.sum(axis=1)>=5)
    effectrows.append({'target':target,'selected_union_loci':41965,'loci_with_at_least_5_counts_either_method':int(use.sum()),'Spearman_log2FC_either_method_total_ge5':float(spearmanr(ilfc[use],slfc[use]).statistic),'positive_expected_any_IRescue':int(np.count_nonzero(ir[:,js].sum(axis=1))),'positive_assigned_any_Stellarscope':int(np.count_nonzero(st[:,js].sum(axis=1)))})
    with gzip.open(OUT/f'{target}.method_log2FC_descriptive.tsv.gz','wt') as f:
        w=csv.writer(f,delimiter='\t',lineterminator='\n');w.writerow(['locus','IRescue_log2FC','Stellarscope_log2FC','total_ge5_either_method'])
        for name,x,y,k in zip(coords,ilfc,slfc,use):w.writerow([name,f'{x:.8g}',f'{y:.8g}',int(k)])

def table(name,rows):
    with (OUT/name).open('w') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter='\t',lineterminator='\n');w.writeheader();w.writerows(rows)
table('same_set_mouse_expression.tsv',boxrows);table('method_effect_comparison.tsv',effectrows)
allpositive=mat.sum(axis=1)>0
save(OUT/'matrix_manifest.json',manifest)
save(OUT/'global_count_summary.json',{'reference_loci':len(names),'expected_UMIs_exported':float(mat.sum()),'positive_expected_loci_any20':int(allpositive.sum()),'zero_loci_any20':int((~allpositive).sum()),'positive_expected_loci_total_ge1_any20':int(np.count_nonzero(mat.sum(axis=1)>=1)),'positive_subfamilies':int(np.count_nonzero(subcounts.sum(axis=1))), 'mouse_reports':reports,'reference':json.load(open(ROOT/'reference/reference.json')),'gene_exposure_source_sha256':sha(HERE/'model_exposures.tsv')})

blue='#3288bd';red='#d53e4f';plt.rcParams.update({'font.size':10,'pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False})
fig,axes=plt.subplots(2,2,figsize=(12,9),layout='constrained')
for ax,target in zip(axes.flat,targets):
    rows=[r for r in boxrows if r['target']==target and r['method']=='IRescue']
    for x,g,col in [(0,'WT_3mo',blue),(1,target,red)]:
        r=[v for v in rows if v['group']==g];y=[v['log2_1plus_gene_normalized_set_expression'] for v in r]
        ax.boxplot([y],positions=[x],widths=.5,patch_artist=True,boxprops={'facecolor':col,'alpha':.3},medianprops={'color':'black'},showfliers=False)
        for i,v in enumerate(r):ax.scatter(x+(i-1.5)*.04,v['log2_1plus_gene_normalized_set_expression'],color=col,marker='^' if v['sex']=='male' else 'o',edgecolor='white',s=45)
    ax.set(xticks=[0,1],xticklabels=['WT_3mo',target],ylabel='log2(1 + set expected UMIs per million gene UMIs)',title=target+'-specific peak-bound TEs');ax.tick_params(axis='x',rotation=15)
fig.suptitle('IRescue PRIMARY: the same TE loci in control and target mice\nFour mice per condition; fixed gene-derived TMM exposure; descriptive',fontsize=14)
fig.savefig(OUT/'IRescue_Microglia_specific_TE_RNA_boxplots.pdf');fig.savefig(OUT/'IRescue_Microglia_specific_TE_RNA_boxplots.png',dpi=140);plt.close(fig)

cmap=LinearSegmentedColormap.from_list('TE',[blue,'#f7f7f7',red])
with PdfPages(OUT/'IRescue_Microglia_specific_TE_RNA_heatmaps.pdf') as pdf:
    for page,target in enumerate(targets):
        js=[j for j,m in enumerate(meta) if m['group'] in ['WT_3mo',target]]
        pos=[coordpos[x] for x in sorted(membership[target+'__target_only'])]
        log=np.log1p(ir[pos][:,js]/depth[js]*1e6);var=log.var(axis=1);chosen=np.argsort(var)[-min(100,len(pos)):][::-1]
        # All original rows are included in an overview, including constant-zero rows.
        order=np.argsort(var)[::-1];sdall=log.std(axis=1)
        zall=(log-log.mean(axis=1,keepdims=True))/np.where(sdall>0,sdall,1)[:,None]
        fig,ax=plt.subplots(figsize=(10,12),layout='constrained')
        im=ax.imshow(zall[order],aspect='auto',cmap=cmap,vmin=-2,vmax=2,interpolation='nearest',rasterized=True)
        ax.set(xticks=range(8),xticklabels=[animals[j] for j in js],yticks=[],ylabel=f'All {len(pos):,} TE loci; sorted by RNA variance',title='IRescue: '+target+' versus WT_3mo\nAll rows, including zero-count rows; within-locus scaled gene-normalized RNA')
        ax.tick_params(axis='x',rotation=65);fig.colorbar(im,ax=ax,label='Within-locus z-score');pdf.savefig(fig);plt.close(fig)
        view=log[chosen];sd=view.std(axis=1);z=(view-view.mean(axis=1,keepdims=True))/np.where(sd>0,sd,1)[:,None]
        fig,ax=plt.subplots(figsize=(10,10),layout='constrained');im=ax.imshow(z,aspect='auto',cmap=cmap,vmin=-2,vmax=2,interpolation='nearest')
        ax.set(xticks=range(8),xticklabels=[animals[j] for j in js],yticks=[],ylabel='100 most variable loci in this fixed TE set',title='IRescue: '+target+' versus WT_3mo\nRow z-score of log(1 + gene-normalized expected UMI counts)')
        ax.set_yticks(range(len(chosen)), [selected_meta[coords[pos[i]]]['subfamily']+' | '+coords[pos[i]] for i in chosen], fontsize=4.5)
        ax.tick_params(axis='x',rotation=65);fig.colorbar(im,ax=ax,label='Within-locus z-score')
        pdf.savefig(fig)
        if page==0:fig.savefig(OUT/'IRescue_Microglia_specific_TE_RNA_heatmaps.png',dpi=120)
        with (OUT/f'{target}.heatmap_display_loci.tsv').open('w') as f:
            f.write('locus\n');f.writelines(coords[pos[i]]+'\n' for i in chosen)
        plt.close(fig)

fig,axes=plt.subplots(2,3,figsize=(15,9),layout='constrained')
ax=axes[0,0];x=np.array([r['expected_UMIs_exported'] for r in reports]);y=np.array([m['te_umi'] for m in meta]);ax.scatter(y,x,color=red);lim=max(max(x),max(y))*1.05;ax.plot([0,lim],[0,lim],color='grey',ls='--');ax.set(xlabel='Stellarscope assigned UMIs',ylabel='IRescue expected UMIs',title='Same Microglia input; mouse totals')
ax=axes[0,1];ga=json.load(open(HERE/'stellarscope_global_audit.json'));ax.bar([0,1],[100*(1-ga['all_loci']['zero_fraction']),100*allpositive.mean()],color=[blue,red]);ax.set(xticks=[0,1],xticklabels=['Stellarscope','IRescue'],ylabel='% loci with positive assigned/expected count',title='Genome-wide positive counts ≠ accuracy')
for ax,target in zip(list(axes.flat)[2:],targets):
    with gzip.open(OUT/f'{target}.method_log2FC_descriptive.tsv.gz','rt') as f:rr=list(csv.DictReader(f,delimiter='\t'))
    r=[v for v in rr if v['total_ge5_either_method']=='1'];a=np.array([float(v['Stellarscope_log2FC']) for v in r]);b=np.array([float(v['IRescue_log2FC']) for v in r])
    ax.hexbin(a,b,gridsize=35,mincnt=1,cmap='Blues');lo=min(a.min(),b.min());hi=max(a.max(),b.max());ax.plot([lo,hi],[lo,hi],color=red,ls='--');rho=next(v['Spearman_log2FC_either_method_total_ge5'] for v in effectrows if v['target']==target)
    ax.set(xlabel='Stellarscope descriptive log2FC',ylabel='IRescue descriptive log2FC',title=f'{target}; Spearman r={rho:.3f}')
fig.suptitle('Separate-method comparison; matched loci and mice\nIRescue per-capture expected allocation versus Stellarscope pseudobulk hard assignment; not a ground-truth benchmark',fontsize=13)
fig.savefig(OUT/'IRescue_vs_Stellarscope_Microglia_locus_comparison.pdf');fig.savefig(OUT/'IRescue_vs_Stellarscope_Microglia_locus_comparison.png',dpi=125);plt.close(fig)
finish();save(OUT/'COMPLETE.json',{'status':'completed','job':os.environ['SLURM_JOB_ID'],'animals':20,'Microglia_cells':22251,'four_count_matrices':4,'zero_rows_retained':True,'Stellarscope_source_unchanged':True,'primary_method':'IRescue','comparison_only':'Stellarscope'})
print('MERGE_AND_COMPARISON_COMPLETE',flush=True)
