"""Build the same interval reference and run allocated locus-level known-answer tests."""
import csv,gzip,json,os,shutil,tarfile
from pathlib import Path
from runtime import *
activate();finish=guard('setup')
import pysam,numpy as np
from scipy.io import mmread
from truth_fixture import generate,CELLS,SOURCE_RUNS
ref=ROOT/'reference';ref.mkdir(exist_ok=False)
source=PROJECT/'te-RNA/Microglia_TE_locus_counts_20261025/source/te_loci.tsv'
before=identity(source);ids=set();n=0
with source.open() as f,(ref/'mm10.TE_loci.BED6').open('x') as out:
    for r in csv.DictReader(f,delimiter='\t'):
        c,s,e,st=r['chrom'],int(r['start']),int(r['end']),r['strand'];key=r['locus_id']
        assert r['assembly']=='mm10' and 0<=s<e and st in '+-' and key not in ids
        assert key==f'{c}:{s}-{e}:{st}:'+r['subfamily']
        ids.add(key);out.write(f'{c}\t{s}\t{e}\t{key}\t0\t{st}\n');n+=1
assert n==3651522 and before==identity(source)
save(ref/'reference.json',{'loci':n,'source':before,'BED_sha256':sha(ref/'mm10.TE_loci.BED6'),'unique_IDs':True,'coordinate_policy':'original BED0 intervals; no fragment joining'})
del ids
test=ROOT/'fixture';test.mkdir(exist_ok=False);g=test/'input';generate(g)
# Three coordinate-defined loci: two instances of the same subfamily stay separate.
features=['chrSynthetic:100-200:+:TE_A','chrSynthetic:300-400:+:TE_B','chrSynthetic:500-600:+:TE_A']
(g/'loci.bed').write_text(''.join(f'chrSynthetic\t{s}\t{s+100}\t{name}\t0\t+\n' for s,name in zip([100,300,500],features)))
# Exercise the exact colon-to-dot capture adapter used on study BAMs.
mapping={c:SOURCE_RUNS[c.split('.')[0]]+':'+c.split('.')[1] for c in CELLS}
lines=(g/'fixture.sam').read_text().splitlines()
for i,line in enumerate(lines):
    for old,new in mapping.items():line=line.replace('CB:Z:'+old,'CB:Z:'+safe_cb(new))
    lines[i]=line
(g/'adapted.sam').write_text('\n'.join(lines)+'\n')
safe=[safe_cb(mapping[c]) for c in CELLS];assert len(set(safe))==4
(g/'whitelist.txt').write_text('\n'.join(safe)+'\n')
samtools=BIN/'samtools';bedtools=BIN/'bedtools'
calls=[]
calls.append(command([samtools,'sort','-@','1','-o',test/'input.bam',g/'adapted.sam'],test/'sort.out',test/'sort.err',60))
calls.append(command([samtools,'index',test/'input.bam'],test/'index.out',test/'index.err',60))
cmd=[PYTHON,'-B',SRC/'irescue_cli.py','-b',test/'input.bam','-r',g/'loci.bed','-w',g/'whitelist.txt','-c','CB','-u','UR','--locus-level','fragment','--strandedness','unstranded','--dump-ec','--keeptmp','--max-iters','1000','-p','2','-o',test/'result','--samtools',samtools,'--bedtools',bedtools,'-v']
calls.append(command(cmd,test/'count.out',test/'count.err',180))
with gzip.open(test/'result/counts/matrix.mtx.gz','rb') as f:m=mmread(f).toarray()
with gzip.open(test/'result/counts/features.tsv.gz','rt') as f:axis=[x.split('\t')[0] for x in f]
with gzip.open(test/'result/counts/barcodes.tsv.gz','rt') as f:bcs=[x.rstrip('\n') for x in f]
expected=np.array([[1,0,.5,1.5],[0,1,.5,1.5],[1,0,0,0]])
for i,x in enumerate(features):
    for j,b in enumerate(safe):assert abs(m[axis.index(x),bcs.index(b)]-expected[i,j])<1e-9
assert m.sum()==7 and (m%1).any()
# A failing producer must not yield a successfully admitted pipeline.
from irescue.misc import run_shell_cmd
try:run_shell_cmd('printf "partial\\n"; exit 19')
except Exception as e:assert getattr(e,'returncode',None)==19
else:raise AssertionError('Producer failure was hidden')
finish();save(ROOT/'setup.COMPLETE.json',{'job':os.environ['SLURM_JOB_ID'],'status':'passed','locus_fixture_expected_mass':7,'subfamily_fixture_mass_was':6,'distinct_same_subfamily_loci_preserved':True,'fractional_assignment_passed':True,'capture_adapter_bijection_passed':True,'checked_producer_failure_passed':True,'calls':calls})
print('REFERENCE_AND_LOCUS_FIXTURE_PASSED',flush=True)
