"""Count selected Microglia from one immutable tagged BAM, then validate mass and axes."""
import csv,gzip,json,os,re,sys,collections
from pathlib import Path
from runtime import *
activate()
import pysam,numpy as np
from scipy.io import mmread
assert json.load(open(ROOT/'setup.COMPLETE.json'))['status']=='passed'
summary=json.load(open(SRC/'stellarscope_summary.json'));metas=summary['per_mouse']
animal=sys.argv[1];meta=next(m for m in metas if m['animal']==animal)
parent=ST/('pilot' if animal=='WT_3mo_female_1' else 'animals')/animal
source=parent/'tagged.bam';before=identity(source)
manifest=next(r for r in json.load(open(SRC/'input_manifest.json')) if r['animal']==animal)
assert before=={k:manifest[k] for k in before},'Source identity changed since deployment'
expected=json.load(open(parent/'tagged.selection.json'))
assert expected==manifest['selection']
assert expected['selected_cells']==meta['cells'] and expected['expected_captures']==expected['observed_captures']==meta['captures']
out=ROOT/'animals'/animal;out.mkdir(parents=True,exist_ok=False);finish=guard(animal)
old_bcs=(parent/'tagged.barcodes.tsv').read_text().splitlines();cbmap={b:safe_cb(b) for b in old_bcs}
assert len(cbmap)==len(set(cbmap.values()))==meta['captures']
with (out/'capture_barcode_bijection.tsv').open('x') as f:
    f.write('source_capture\tIRescue_capture\n');f.writelines(f'{b}\t{x}\n' for b,x in cbmap.items())
(out/'whitelist.tsv').write_text('\n'.join(sorted(cbmap.values()))+'\n')
records=collections.Counter();seen=set()
with pysam.AlignmentFile(str(source),'rb') as src,pysam.AlignmentFile(str(out/'adapted.unsorted.bam'),'wb',template=src) as dst:
    for rec in src.fetch(until_eof=True):
        cb=rec.get_tag('CB');ub=rec.get_tag('UB')
        assert cb in cbmap and len(ub)==8
        records['records']+=1;records['secondary']+=rec.is_secondary;records['supplementary']+=rec.is_supplementary
        records['UMI_N_or_homopolymer_records']+=('N' in ub or len(set(ub))==1)
        rec.set_tag('CB',cbmap[cb],value_type='Z');dst.write(rec);seen.add(cb)
assert seen==set(cbmap) and records['records']==expected['selected_records']
assert records['secondary']==expected.get('selected_secondary',0)
save(out/'selection.json',{'input':before,'source_selection':expected,'records':dict(records),'captures':len(seen),'adapter':'bijective source-qualified colon-to-dot CB, UB unchanged; original BAM untouched'})
calls=[]
calls.append(command([BIN/'samtools','sort','-@','1','-m','1G','-T',out/'sort_tmp','-o',out/'prepared.bam',out/'adapted.unsorted.bam'],out/'sort.out',out/'sort.err',600))
calls.append(command([BIN/'samtools','index',out/'prepared.bam'],out/'index.out',out/'index.err',120))
cmd=[PYTHON,'-B',SRC/'irescue_cli.py','-b',out/'prepared.bam','-r',ROOT/'reference/mm10.TE_loci.BED6','--locus-level','fragment','-w',out/'whitelist.tsv','-c','CB','-u','UB','--strandedness','unstranded','--dump-ec','--keeptmp','--max-iters','1000','--tolerance','0.0001','--convergence-criterion','likelihood','-p','2','-o',out/'irescue','--samtools',BIN/'samtools','--bedtools',BIN/'bedtools','-v']
calls.append(command(cmd,out/'irescue.stdout',out/'irescue.stderr',3300))
logs=(out/'irescue.stderr').read_text();em=re.findall(r'EM cycles: (\w+)\. Converged: (\w+)\.',logs)
assert em and not any(x[1]=='False' for x in em), 'Nonconverged EM capture detected'
r=out/'irescue';c=r/'counts'
with gzip.open(c/'features.tsv.gz','rt') as f:features=[x.rstrip('\n').split('\t')[0] for x in f]
with gzip.open(c/'barcodes.tsv.gz','rt') as f:bcs=[x.rstrip('\n') for x in f]
bcset=set(bcs)
assert len(features)==len(set(features)) and len(bcs)==len(bcset) and bcset<=set(cbmap.values())
with gzip.open(c/'matrix.mtx.gz','rb') as f:mat=mmread(f).tocsr()
assert mat.shape==(len(features),len(bcs)) and np.all(np.isfinite(mat.data)) and np.all(mat.data>0)
roots=collections.Counter();poss=collections.Counter();ecrows=0
with gzip.open(r/'ec_dump.tsv.gz','rt',newline='') as f:
    reader=csv.reader(f,delimiter='\t');assert len(next(reader))==8
    for row in reader:
        assert len(row)==8 and row[1] in bcset
        ecrows+=1;poss[row[1]]+=len(row[4].split(','))
        if row[6]=='':assert row[7]=='';roots[row[1]]+=1
colsum=np.asarray(mat.sum(axis=0)).ravel();nnz=mat.getnnz(axis=0)
for j,b in enumerate(bcs):assert abs(colsum[j]-roots[b])<=.001*poss[b]+.0005*nnz[j]+1e-7,(b,colsum[j],roots[b])
assert len(em)==len(bcs) and before==identity(source)
vals=np.asarray(mat.sum(axis=1)).ravel()
with gzip.open(out/'locus_expected_UMIs.tsv.gz','wt') as f:
    f.write('TE_locus\texpected_UMIs\n');f.writelines(f'{key}\t{v:.9g}\n' for key,v in zip(features,vals))
finish()
save(out/'COMPLETE.json',{'animal':animal,'job':os.environ['SLURM_JOB_ID'],'cells':meta['cells'],'captures_expected':meta['captures'],'captures_with_TE_counts':len(bcs),'TE_features_with_mapping':len(features),'positive_TE_loci':int(np.count_nonzero(vals)), 'expected_UMIs_exported':float(vals.sum()),'algorithm_UMI_clusters_preexport':sum(roots.values()),'export_mass_difference':float(vals.sum()-sum(roots.values())),'EM_captures_logged':len(em),'EM_nonconverged':0,'EM_max_cycles':max([int(x[0]) for x in em if x[0]!='None'] or [0]),'ec_rows':ecrows,'source':before,'source_unchanged':True,'counts_are':'fractional expected UMI allocations, not observed integer molecule counts','calls':calls})
print('ANIMAL_COMPLETE',animal,flush=True)
