"""Fixed source/runtime and per-allocation storage checks; no environment installation."""
import hashlib,json,os,subprocess,sys,threading,time
from pathlib import Path
SRC=Path(__file__).resolve().parent
ROOT=SRC.parent
PROJECT=Path('/lisc/data/scratch/molecular_neurosciences/i-med/p5_Glial_TE_regulation_aging')
ST=PROJECT/'te-RNA/Stellarscope_Microglia_20261026'
PYTHON=ST/'venv/bin/python'
BIN=PROJECT/'software/envs/preprocess/bin'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,v):
    with Path(p).open('x') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def identity(p):
    s=Path(p).stat();return {'path':str(p),'bytes':s.st_size,'inode':s.st_ino,'mtime_ns':s.st_mtime_ns}
def safe_cb(cb):
    import re
    if not re.fullmatch(r'SRR\d+:[ACGTN]{20}',cb):raise ValueError('Unexpected qualified capture barcode '+cb)
    return cb.replace(':','.',1)
def activate():
    assert os.getenv('SLURM_JOB_ID','').isdigit() and sys.platform=='linux'
    for name,digest in json.load(open(SRC/'source_manifest.json')).items():assert sha(SRC/name)==digest,name
    os.environ['PATH']=str(BIN)+':/usr/bin:/bin'
    for n in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[n]='1'
    from dependency_wheels import validate_wheels
    plan=json.load(open(SRC/'wheel_plan.json'))
    validate_wheels([{'path':str(SRC/r['wheel_filename']),'sha256':r['wheel_sha256'],'distribution':r['name'],'version':r['version']} for r in plan])
    pins=json.load(open(SRC/'package_manifest.json'))
    for n,h in pins.items():assert sha(SRC/'package'/n)==h,n
    sys.path.insert(0,str(SRC/'package'))
    import numpy,scipy,pysam,networkx,requests
    assert pysam.__version__ and networkx.__version__=='3.4.2'
def guard(label):
    out=ROOT/'guards';out.mkdir(exist_ok=True)
    p=out/(label+'.jsonl');stop=threading.Event()
    def check():
        v=os.statvfs(ROOT);assert v.f_bavail*v.f_frsize>=605000000000 and v.f_favail>=53000
        files=[x for x in ROOT.rglob('*') if x.is_file()]
        used=0
        for x in files:
            try:used+=x.stat().st_size
            except FileNotFoundError:pass # A samtools-owned temporary name was removed between samples.
        # Account open-unlinked regular files in the live descendant tree, once per inode.
        proc={}
        for entry in Path('/proc').iterdir():
            if not entry.name.isdigit():continue
            try:
                if entry.stat().st_uid!=os.getuid():continue
                raw=(entry/'stat').read_text();fields=raw[raw.rfind(')')+2:].split()
                proc[int(entry.name)]=(int(fields[1]),int(fields[19]))
            except FileNotFoundError:continue
        owned={os.getpid()};changed=True
        while changed:
            more={pid for pid,(ppid,start) in proc.items() if ppid in owned};changed=bool(more-owned);owned|=more
        unlinked={}
        import stat
        for pid in owned:
            fdpath=Path('/proc')/str(pid)/'fd'
            try:
                for fd in fdpath.iterdir():
                    try:s=fd.stat()
                    except FileNotFoundError:continue
                    if stat.S_ISREG(s.st_mode) and s.st_nlink==0:unlinked[(s.st_dev,s.st_ino)]=max(s.st_size,s.st_blocks*512)
            except FileNotFoundError:
                assert not Path('/proc',str(pid)).exists(), 'Live process FD inventory became inaccessible'
        used+=sum(unlinked.values())
        assert len(files)<=4000 and used<=50000000000,('Own-stage bound exceeded',len(files),used)
        receipts={}
        for k,n in [('u','mujahid'),('g','molecular_neurosciences')]:
            q=subprocess.check_output(['/usr/lpp/mmfs/bin/mmlsquota','-'+k,n,'data'],text=True,timeout=20)
            row=next(x for x in q.splitlines() if x.split()[:2]==['data','scratch']).replace('|',' ').split()
            b,qb,hb,ib=map(int,row[3:7]);i,qi,hi,ii=map(int,row[8:12])
            bs=[x for x in (qb,hb) if x>0];ins=[x for x in (qi,hi) if x>0]
            assert not bs or (min(bs)-b-ib)*1024>=605000000000
            assert not ins or min(ins)-i-ii>=53000
            receipts[k]=q
        with p.open('a') as f:f.write(json.dumps({'time':time.time(),'job':os.environ['SLURM_JOB_ID'],'stage_bytes':used,'stage_files':len(files),'open_unlinked_bytes':sum(unlinked.values()),'known_live_descendants':sorted(owned),**receipts})+'\n')
    check()
    def watch():
        while not stop.wait(30):
            try:check()
            except BaseException:
                # Slurm will retire this allocation's processes on nonzero batch exit.
                os._exit(7)
    t=threading.Thread(target=watch,daemon=True);t.start()
    def finish():stop.set();t.join(timeout=25);check()
    return finish
def command(argv,stdout,stderr,seconds=3300):
    with Path(stdout).open('xb') as o,Path(stderr).open('xb') as e:
        r=subprocess.run(list(map(str,argv)),stdin=subprocess.DEVNULL,stdout=o,stderr=e,timeout=seconds)
    assert r.returncode==0,(argv,r.returncode,str(stderr))
    return {'argv':list(map(str,argv)),'returncode':r.returncode,'stdout_sha256':sha(stdout),'stderr_sha256':sha(stderr)}
