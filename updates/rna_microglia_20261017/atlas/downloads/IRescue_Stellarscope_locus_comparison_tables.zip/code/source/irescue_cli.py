import sys
from runtime import activate
activate()
from irescue.main import main
main()
