import csv,json,sys
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
P=Path(sys.argv[1]);R=P/'results'
read=lambda p:list(csv.DictReader(p.open(),delimiter='\t'))
rows=read(R/'boxplot_mouse_values.tsv');summary=read(R/'zero_filter_summary.tsv')
targets=['WT_6mo','WT_21mo','5xFAD_3mo','APOE4_TREM2_3mo']
labels={'all_rows':'All original TE rows','nonzero':'Remove all-zero TE copies','RUVr_k1':'Nonzero + protected RUVr k=1','RUVr_k2':'Nonzero + protected RUVr k=2 (sensitivity)'}
plt.rcParams.update({'pdf.fonttype':42,'font.size':9})
def figure(methods,measure,name,title):
 f,axs=plt.subplots(len(methods),4,figsize=(18,4*len(methods)),squeeze=False,layout='constrained')
 for i,method in enumerate(methods):
  for j,t in enumerate(targets):
   ax=axs[i,j];z=[r for r in rows if r['target']==t and r['method']==method];assert len(z)==8
   vals=[[float(r[measure]) for r in z if r['condition']==g]for g in ['WT_3mo',t]]
   bp=ax.boxplot(vals,positions=[0,1],widths=.5,patch_artist=True,showfliers=False,medianprops={'color':'black'})
   for patch,c in zip(bp['boxes'],['#3288bd','#d53e4f']):patch.set(facecolor=c,alpha=.28,edgecolor=c)
   for x,g,c in [(0,'WT_3mo','#3288bd'),(1,t,'#d53e4f')]:
    for k,r in enumerate([v for v in z if v['condition']==g]):ax.scatter(x+(k-1.5)*.055,float(r[measure]),s=36,c=c,marker='o'if r['sex']=='female'else'^',edgecolors='white',linewidths=.6,zorder=4)
   n=int(z[0]['original_loci']if method=='all_rows'else z[0]['retained_loci'])
   ax.set_title(t+'\n'+labels[method]+f' | {n:,} copies',fontsize=10)
   ax.set_xticks([0,1],['WT_3mo',t],rotation=25,ha='right');ax.grid(axis='y',alpha=.18)
   if measure=='z_score':ax.axhline(0,ls='--',lw=.7,c='#888')
   if j==0:ax.set_ylabel('Z-score of mouse mean normalized TE expression\n(same eight mice)'if measure=='z_score'else'Mean log₂(1 + gene-normalized CPM)\nper TE copy; RUV-adjusted where stated')
 f.suptitle(title+'\nFour mice per condition; circles female, triangles male; descriptive comparison',fontsize=14)
 f.savefig(R/(name+'.pdf'));f.savefig(R/(name+'.png'),dpi=140);plt.close(f)
figure(['all_rows','nonzero'],'mean_log2_1plus_CPM','IRescue_zero_filter_before_after_boxplots','Effect of removing TE copies with zero counts across all eight mice')
figure(['nonzero','RUVr_k1','RUVr_k2'],'mean_log2_1plus_CPM','IRescue_nonzero_RUVr_normalized_boxplots','Microglia TE-copy RNA: gene-normalized versus RUVr-adjusted expression')
figure(['nonzero','RUVr_k1','RUVr_k2'],'z_score','IRescue_nonzero_RUVr_scaled_boxplots','Microglia TE-copy RNA: scaled expression before and after RUVr')
f,ax=plt.subplots(1,2,figsize=(13,5),layout='constrained');fac=read(R/'RUVr_RNA_gene_factors_all20.tsv');groups=list(dict.fromkeys(r['condition']for r in fac));palette=plt.get_cmap('tab10')
for i,g in enumerate(groups):
 z=[r for r in fac if r['condition']==g];ax[0].scatter([float(r['W_1'])for r in z],[float(r['W_2'])for r in z],label=g,c=[palette(i)],s=45)
ax[0].set(xlabel='RUVr RNA-gene residual factor 1',ylabel='Factor 2',title='Residual factors: group and sex protected');ax[0].legend(fontsize=8)
q=read(R/'RNA_gene_RLE_QC.tsv');x=np.arange(20)
ax[1].plot(x,[float(r['RLE_before'])for r in q],'o-',label='Before RUVr');ax[1].plot(x,[float(r['RLE_after_k2'])for r in q],'o-',label='RUVr k=2');ax[1].axhline(0,c='#888',lw=.6);ax[1].set(xlabel='Mouse (order in metadata)',ylabel='Median relative log expression of genes',title='Exploratory RNA-gene RLE');ax[1].legend()
f.savefig(R/'RUVr_gene_factor_QC.pdf');f.savefig(R/'RUVr_gene_factor_QC.png',dpi=140);plt.close(f)
for r in rows:
 for k in ['original_loci','retained_loci']:r[k]=int(r[k])
 for k in ['mean_log2_1plus_CPM','z_score','raw_set_expected_count','set_expected_count_per_million_gene_UMIs']:r[k]=float(r[k])
for r in summary:
 for k in ['original_loci','all_zero_in_same8_removed','retained_loci']:r[k]=int(r[k])
(R/'irescue_nonzero_ruv.json').write_text(json.dumps({'status':'completed','method':'RUVSeq 1.44 RUVr, independent RNA-gene residuals, protected group and sex','points':rows,'filter_summary':summary,'models':['all_rows','nonzero','RUVr_k1','RUVr_k2'],'DE_unchanged':True},separators=(',',':'),allow_nan=False)+'\n')
print('BOXPLOTS_COMPLETE',len(rows),'mouse values',flush=True)
