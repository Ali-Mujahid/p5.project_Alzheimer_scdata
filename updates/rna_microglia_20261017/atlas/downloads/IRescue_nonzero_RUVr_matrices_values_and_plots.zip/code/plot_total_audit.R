# Display-only plot of 64 already computed mouse values; no matrix fitting/counting.
p=commandArgs(trailingOnly=TRUE)[1];z=read.delim(file.path(p,'results/boxplot_mouse_values.tsv'),check.names=FALSE)
targets=c('WT_6mo','WT_21mo','5xFAD_3mo','APOE4_TREM2_3mo')
draw=function(){
 par(mfrow=c(2,4),mar=c(7,4,3,1),oma=c(0,1,3,0),cex=.85)
 for(method in c('all_rows','nonzero'))for(t in targets){
  d=z[z$target==t & z$method==method,];d$group=factor(d$condition,levels=c('WT_3mo',t));d$value=log2(1+d$set_expected_count_per_million_gene_UMIs)
  boxplot(value~group,d,col=c('#3288bd55','#d53e4f55'),outline=FALSE,names=FALSE,ylab=if(t=='WT_6mo')'log2(1 + set counts per million gene UMIs)'else'',xlab='',main=paste(t,if(method=='all_rows')'Before zero-row removal'else'After zero-row removal',sep='\n'),cex.main=.9)
  axis(1,at=1:2,labels=c('WT_3mo',t),las=1,cex.axis=.85)
  for(g in levels(d$group)){a=d[d$group==g,];points(match(g,levels(d$group))+seq(-.08,.08,length.out=4),a$value,pch=ifelse(a$sex=='female',21,24),bg=if(g=='WT_3mo')'#3288bd'else'#d53e4f',col='white',cex=1.1)}
 }
 mtext('Same total-expression endpoint before and after removing all-eight-zero TE copies',outer=TRUE,line=1,font=2,cex=1.2)
}
pdf(file.path(p,'results/IRescue_zero_filter_TOTAL_expression_audit.pdf'),width=16,height=8);draw();dev.off()
png(file.path(p,'results/IRescue_zero_filter_TOTAL_expression_audit.png'),type='cairo',width=2400,height=1200,res=150);draw();dev.off()
