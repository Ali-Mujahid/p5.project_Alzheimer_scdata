import hashlib,json,os,subprocess,time
from pathlib import Path
import resource_guard as g
ROOT=Path.cwd();SRC=ROOT/'source';OUT=ROOT/'results';assert not OUT.exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
manifest=json.load(open(SRC/'manifest.json'))
for n,h in manifest['source'].items():assert sha(SRC/n)==h,n
for n,h in manifest['inputs'].items():assert sha(Path(manifest['input_root'])/n)==h,n
H=Path(manifest['gene_H5']);before={'bytes':H.stat().st_size,'mtime_ns':H.stat().st_mtime_ns,'sha256':sha(H)}
g.ROOT=ROOT;finish=g.guard('RUV_'+os.environ['SLURM_JOB_ID']);OUT.mkdir();(ROOT/'Rlibrary').mkdir()
shell='source /etc/profile.d/z00_lmod.sh; module load R-bundle-Bioconductor/3.22-foss-2025b-R-4.5.2; exec "$@"'
def runR(argv,log):
    with (OUT/log).open('x')as f:r=subprocess.run(['/bin/bash','-c',shell,'RUV',*map(str,argv)],stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT)
    assert r.returncode==0,log
try:
    # Pure-R official Bioconductor packages, isolated task library; no shared environment changes.
    runR(['R','CMD','INSTALL','--no-byte-compile','--library='+str(ROOT/'Rlibrary'),SRC/'EDASeq_2.44.0.tar.gz'],'install_EDASeq.log')
    # R_LIBS_USER makes the new EDASeq dependency visible to the next isolated R process.
    os.environ['R_LIBS_USER']=str(ROOT/'Rlibrary')
    runR(['R','CMD','INSTALL','--no-byte-compile','--library='+str(ROOT/'Rlibrary'),SRC/'RUVSeq_1.44.0.tar.gz'],'install_RUVSeq.log')
    runR(['Rscript','--vanilla',SRC/'run_analysis.R',SRC,OUT],'analysis.log')
    r=subprocess.run([g.PYTHON,'-B',str(SRC/'plot_results.py'),str(ROOT)],stdin=subprocess.DEVNULL);assert r.returncode==0,'plot_results.py'
    for n,h in manifest['inputs'].items():assert sha(Path(manifest['input_root'])/n)==h
    assert before=={'bytes':H.stat().st_size,'mtime_ns':H.stat().st_mtime_ns,'sha256':sha(H)}
    finish();g.save(OUT/'COMPLETE.json',{'status':'completed','job_id':os.environ['SLURM_JOB_ID'],'source_sha256':sha(SRC/'manifest.json'),'unchanged_TE_inputs':True,'gene_H5_before_after':before,'Microglia_cells':22251,'mice':20})
except BaseException as e:g.save(OUT/'FAILED.json',{'error':repr(e),'job_id':os.environ['SLURM_JOB_ID']});raise
