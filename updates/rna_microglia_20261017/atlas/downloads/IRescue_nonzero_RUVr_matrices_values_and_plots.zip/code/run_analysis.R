args=commandArgs(trailingOnly=TRUE);stopifnot(length(args)==2);src=normalizePath(args[1]);out=normalizePath(args[2])
.libPaths(c(file.path(dirname(out),'Rlibrary'),.libPaths()))
suppressPackageStartupMessages({library(RUVSeq);library(rhdf5);library(jsonlite)})
stopifnot(packageVersion('RUVSeq')=='1.44.0')
rd=function(p)read.delim(p,check.names=FALSE,stringsAsFactors=FALSE)
put=function(x,n)write.table(x,file.path(out,n),sep='\t',quote=FALSE,row.names=FALSE,na='NA')
meta=rd(file.path(src,'mouse_metadata.tsv'));stopifnot(nrow(meta)==20,sum(meta$cells)==22251,all(meta$gene_effective_depth>0))
meta$condition=relevel(factor(meta$condition),'WT_3mo');meta$sex=factor(meta$sex)
X=model.matrix(~sex+condition,meta);stopifnot(qr(X)$rank==6)
H='/lisc/data/scratch/molecular_neurosciences/i-med/p5_Glial_TE_regulation_aging/pre_processed_RNA/analysis_source/Microglia_gene_DE_20261025_v1/mouse_cluster_gene_pseudobulk.h5'
G=h5read(H,'Microglia22251_mouse_gene_counts');geneids=as.character(h5read(H,'gene_id'));animals=sort(unique(h5read(H,'group_animal_id')))
stopifnot(identical(dim(G),c(55487L,20L)),length(geneids)==nrow(G),length(animals)==20)
colnames(G)=animals;G=G[,match(meta$animal,animals),drop=FALSE];rownames(G)=geneids
stopifnot(identical(colnames(G),meta$animal),all(colSums(G)==meta$gene_depth),!anyDuplicated(geneids))
gkeep=rowSums(G>=10)>=4;stopifnot(sum(gkeep)>500)
Lg=log2(1+sweep(G[gkeep,,drop=FALSE],2,meta$gene_effective_depth,'/')*1e6)
E=t(qr.resid(qr(X),t(Lg)));stopifnot(max(abs(E%*%X))<1e-8)
# RUVr uses RNA-gene residuals, not post-hoc "stable" TE copies. isLog and round avoid any integer conversion.
rr=RUVr(Lg,cIdx=seq_len(nrow(Lg)),k=2,residuals=E,center=FALSE,round=FALSE,isLog=TRUE)
W=rr$W;stopifnot(identical(dim(W),c(20L,2L)),all(is.finite(W)),max(abs(crossprod(X,W)))<1e-8)
put(data.frame(meta[,c('animal','condition','sex','cells','gene_effective_depth')],W,check.names=FALSE),'RUVr_RNA_gene_factors_all20.tsv')
put(data.frame(gene_id=geneids,used_for_RUVr=gkeep),'RNA_gene_feature_selection.tsv')
sing=svd(E,nu=0,nv=0)$d
geneQC=data.frame(animal=meta$animal,RLE_before=apply(sweep(Lg,1,apply(Lg,1,median),'-'),2,median),
 RLE_after_k2=apply(sweep(rr$normalizedCounts,1,apply(rr$normalizedCounts,1,median),'-'),2,median))
put(geneQC,'RNA_gene_RLE_QC.tsv')
# Tiny known-factor check of protected correction, not a claim of biological validation.
set.seed(2910);d=cbind(1,rep(c(0,1),each=4));wf=qr.resid(qr(d),rnorm(8));wf=wf/sqrt(sum(wf^2));f=matrix(rnorm(80*8,sd=.01),80,8)+outer(seq(0,2,length.out=80),wf)+outer(rep(1,80),d[,2])
ef=t(qr.resid(qr(d),t(f)));rf=RUVr(f,seq_len(nrow(f)),k=1,residuals=ef,center=FALSE,round=FALSE,isLog=TRUE)
stopifnot(abs(cor(rf$W[,1],wf))>.99,max(abs(crossprod(d,rf$W)))<1e-8)
write_json(list(status='passed_known_factor_RUVr_fixture',factor_absolute_correlation=abs(cor(rf$W[,1],wf)),condition_orthogonality=TRUE),file.path(out,'fixture.json'),auto_unbox=TRUE,pretty=TRUE)
inp='/lisc/data/scratch/molecular_neurosciences/i-med/p5_Glial_TE_regulation_aging/te-RNA/IRescue_Microglia_locus_20261028/results'
targets=c('WT_6mo','WT_21mo','5xFAD_3mo','APOE4_TREM2_3mo');summaries=list();points=list();diagnostics=list()
for(t in targets){
 z=rd(gzfile(file.path(inp,paste0('IRescue_WT_3mo_vs_',t,'.TE_RNA_counts.tsv.gz'))));ann=z[,1:8];Y=as.matrix(z[,-(1:8)]);storage.mode(Y)='double';rownames(Y)=ann$TE_locus
 m=meta[match(colnames(Y),meta$animal),];stopifnot(nrow(m)==8,identical(as.character(m$animal),colnames(Y)),all(table(m$condition[m$condition%in%c('WT_3mo',t)],m$sex)[c('WT_3mo',t),]==2))
 m$condition=factor(m$condition,levels=c('WT_3mo',t));D=model.matrix(~sex+condition,m);stopifnot(qr(D)$rank==3)
 keep=rowSums(Y)>0;stopifnot(any(keep),all(Y[!keep,,drop=FALSE]==0));YY=Y[keep,,drop=FALSE];a=ann[keep,,drop=FALSE]
 stopifnot(max(abs(colSums(YY)-colSums(Y)))<1e-8)
 con=gzfile(file.path(out,paste0(t,'.nonzero_raw_IRescue_counts.tsv.gz')),'wt');write.table(z[keep,,drop=FALSE],con,sep='\t',quote=FALSE,row.names=FALSE);close(con)
 put(data.frame(ann,keep_nonzero_any_of_same8=keep),paste0(t,'.zero_filter.tsv'))
 L=log2(1+sweep(YY,2,m$gene_effective_depth,'/')*1e6)
 models=list(all_rows=colSums(L)/nrow(Y),nonzero=colMeans(L));diag=list()
 for(k in 1:2){
  wp=qr.resid(qr(D),W[match(m$animal,meta$animal),seq_len(k),drop=FALSE]);stopifnot(qr(wp)$rank==k)
  wp=qr.Q(qr(wp))[,seq_len(k),drop=FALSE];stopifnot(qr(cbind(D,wp))$rank==3+k,max(abs(crossprod(D,wp)))<1e-8)
  C=L-t(wp%*%crossprod(wp,t(L)));stopifnot(all(is.finite(C)))
  dif=max(sapply(c('WT_3mo',t),function(g)max(abs(rowMeans(C[,m$condition==g,drop=FALSE])-rowMeans(L[,m$condition==g,drop=FALSE])))))
  stopifnot(dif<1e-8)
  models[[paste0('RUVr_k',k)]]=colMeans(C)
  con=gzfile(file.path(out,paste0(t,'.RUVr_k',k,'.adjusted_log2CPM.tsv.gz')),'wt');write.table(data.frame(a,C,check.names=FALSE),con,sep='\t',quote=FALSE,row.names=FALSE);close(con)
  put(data.frame(animal=m$animal,wp,check.names=FALSE),paste0(t,'.protected_RUVr_k',k,'.factors.tsv'))
  diagnostics[[paste(t,k)]]=data.frame(target=t,k=k,model_rank=3+k,residual_df=8-3-k,max_group_mean_difference=dif,max_design_factor_crossproduct=max(abs(crossprod(D,wp))),
     before_mean_within_group_gene_normalized_variance=mean(apply(L[,1:4],1,var)+apply(L[,5:8],1,var)),after_mean_within_group_variance=mean(apply(C[,1:4],1,var)+apply(C[,5:8],1,var)))
 }
 for(nm in names(models)){
  v=as.numeric(models[[nm]]);sdv=sd(v);stopifnot(sdv>0)
  points[[paste(t,nm)]]=data.frame(target=t,method=nm,animal=m$animal,condition=as.character(m$condition),sex=as.character(m$sex),original_loci=nrow(Y),retained_loci=sum(keep),
   mean_log2_1plus_CPM=v,z_score=(v-mean(v))/sdv,raw_set_expected_count=colSums(YY),set_expected_count_per_million_gene_UMIs=colSums(YY)/m$gene_effective_depth*1e6)
 }
 summaries[[t]]=data.frame(target=t,original_loci=nrow(Y),all_zero_in_same8_removed=sum(!keep),retained_loci=sum(keep),original_set_expected_sum=sum(Y),filtered_set_expected_sum=sum(YY),unrounded_counts=TRUE)
 cat('COMPLETED_NONZERO_RUVr',t,'retained',sum(keep),'removed',sum(!keep),'\n')
}
put(do.call(rbind,points),'boxplot_mouse_values.tsv');put(do.call(rbind,summaries),'zero_filter_summary.tsv');put(do.call(rbind,diagnostics),'RUVr_protection_and_variance_QC.tsv')
capture.output(sessionInfo(),file=file.path(out,'R_sessionInfo.txt'))
write_json(list(status='completed_RUVr_analysis',RNA_genes_used=sum(gkeep),RNA_gene_residual_design='sex + five-group condition',RUVSeq_version=as.character(packageVersion('RUVSeq')),primary_k=1,sensitivity_k=2,
 factor_residual_variance_fraction=as.numeric(sing[1:2]^2/sum(sing^2)),genes_count_axes_and_depth_match=TRUE,counts_unrounded=TRUE,adjusted_values_are='protected log2(1+gene-normalized CPM), exploratory; not raw counts',previous_DE_not_changed=TRUE),file.path(out,'analysis_COMPLETE.json'),auto_unbox=TRUE,pretty=TRUE)
