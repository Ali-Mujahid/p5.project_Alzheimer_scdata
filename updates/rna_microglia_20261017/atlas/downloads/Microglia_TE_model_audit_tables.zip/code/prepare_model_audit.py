import csv,gzip,json
from pathlib import Path
import numpy as np
W=Path(__file__).resolve().parent
O=W/'results/model_audit';O.mkdir(parents=True,exist_ok=True)
root=W.parents[1]
meta=json.loads((root/'work/stellarscope_microglia_20261026/combined/summary.json').read_text())['per_mouse']
mice=[r['animal'] for r in meta]
with gzip.open(W/'results/selected_TE_locus_UMI_by_mouse.tsv.gz','rt') as f:r=list(csv.DictReader(f,delimiter='\t'))
unique={};sets={}
for row in r:
 key=':'.join(row[k] for k in ['chr','start','end','strand'])
 counts=tuple(int(row[m]) for m in mice)
 if key in unique:assert unique[key][1]==counts
 unique[key]=(row,counts)
 sets.setdefault((row['target'],row['set']),set()).add(key)
for t in ['WT_21mo','5xFAD_3mo']:
 p=root/'work/MAnorm_targetTE_stability_20261028/final_results'/f'{t}.stable_TEs.bed3'
 coords={tuple(line.split()[:3]) for line in p.read_text().splitlines() if line.strip()}
 original=sets[t,'target_only']
 chosen={k for k in original if tuple(unique[k][0][f] for f in ['chr','start','end']) in coords}
 assert len(chosen)==len(coords)
 sets[t,'target_stable']=chosen
with (O/'locus_counts.tsv').open('w') as f:
 f.write('locus\t'+'\t'.join(mice)+'\n')
 for k,(row,c) in sorted(unique.items()):f.write(k+'\t'+'\t'.join(map(str,c))+'\n')
with (O/'set_counts.tsv').open('w') as f, (O/'set_metadata.tsv').open('w') as g, (O/'locus_membership.tsv').open('w') as h:
 f.write('set_id\t'+'\t'.join(mice)+'\n');g.write('set_id\ttarget\tset\tn_loci\n');h.write('set_id\tlocus\n')
 for (t,kind),keys in sorted(sets.items()):
  sid=t+'__'+kind;a=np.array([unique[k][1] for k in keys]).sum(axis=0)
  f.write(sid+'\t'+'\t'.join(map(str,a))+'\n');g.write(f'{sid}\t{t}\t{kind}\t{len(keys)}\n')
  for k in sorted(keys):h.write(sid+'\t'+k+'\n')
with (O/'mouse_metadata.tsv').open('w') as f:
 f.write('animal\tcondition\tsex\tcells\tTE_UMIs\n')
 for m in meta:f.write(f"{m['animal']}\t{m['group']}\t{m['animal'].rsplit('_',2)[1]}\t{m['cells']}\t{m['te_umi']}\n")
# Small saved mean profiles: quantify centre and outer flanks without reading binned matrices.
with (root/'work/MAnorm_targetTE_stability_20261028/final_results/stable_profile_data.tab').open() as f:profiles=list(csv.reader(f,delimiter='\t'))[2:]
with (O/'pooled_ATAC_profile_audit.tsv').open('w') as f:
 f.write('sample\tset\tcenter_200bp\touter_flank_mean\tcenter_over_flank\tcenter_minus_flank\n')
 for p in profiles:
  a=np.array(p[2:],dtype=float);assert len(a)==100
  center=a[49:51].mean();flank=np.r_[a[:10],a[-10:]].mean()
  f.write(f'{p[0]}\t{p[1]}\t{center}\t{flank}\t{center/flank}\t{center-flank}\n')
print('Prepared',len(unique),'unique loci,',len(sets),'sets,',len(mice),'mice')
