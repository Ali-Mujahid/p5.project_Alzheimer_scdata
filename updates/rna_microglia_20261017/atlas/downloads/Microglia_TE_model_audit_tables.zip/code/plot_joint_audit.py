import csv,json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
W=Path(__file__).resolve().parent;O=W/'results/model_audit'
rd=lambda n:list(csv.DictReader((O/n).open(),delimiter='\t'))
r=rd('joint_mouse_signals.tsv');targets=['WT_6mo','WT_21mo','5xFAD_3mo','APOE4_TREM2_3mo']
summary=[]
with PdfPages(O/'Microglia_TE_matched_ATAC_RNA_audit.pdf') as pdf:
 fig,axes=plt.subplots(2,4,figsize=(16,8),sharey=True,constrained_layout=True)
 for col,t in enumerate(targets):
  a=[x for x in r if x['set_id']==t+'__target_only'];a.sort(key=lambda x:(x['condition']!='WT_3mo',x['animal']))
  pair=[x for x in a if x['condition'] in ['WT_3mo',t]]
  rec={'target':t}
  for row,(field,label) in enumerate([('relative_ATAC','Relative ATAC signal'),('RNA_gene_TMM_CPM','RNA with gene-TMM normalization')]):
   c=[x for x in pair if x['condition']=='WT_3mo'];d=[x for x in pair if x['condition']==t]
   denom=np.median([float(x[field]) for x in c]);v=[np.array([float(x[field])/denom for x in group]) for group in [c,d]]
   rec[field+'_target_over_control_median']=float(np.median(v[1]))
   ax=axes[row,col];b=ax.boxplot(v,positions=[1,2],widths=.5,patch_artist=True,showfliers=False,medianprops={'color':'black'})
   for i,color in enumerate(['#3288bd','#d53e4f']):
    b['boxes'][i].set(facecolor=color,alpha=.3,edgecolor=color)
    for j,x in enumerate([c,d][i]):ax.scatter(i+1+[-.07,.07,-.04,.04][j],v[i][j],s=35,c=color,marker='o' if 'female' in x['animal'] else '^',edgecolor='white',linewidth=.5)
   ax.axhline(1,color='#555',ls='--');ax.set_xticks([1,2],['WT_3mo',t],rotation=22,ha='right',fontsize=9);ax.grid(axis='y',alpha=.2)
   if col==0:ax.set_ylabel(label+'\nWT_3mo median = 1')
   if row==0:ax.set_title(t)
   ax.spines[['top','right']].set_visible(False);ax.set_ylim(.65,2.05)
  summary.append(rec)
 fig.suptitle('Same target-defined TE copies, same 20 animals, two separate assays\nFour independent mice per condition; ATAC sets selected using these animals; ATAC plots are descriptive',fontsize=13)
 pdf.savefig(fig);fig.savefig(O/'Microglia_TE_matched_ATAC_RNA_audit.png',dpi=140);plt.close(fig)
 pred=rd('joint_heldout_prediction.tsv')
 fig,axes=plt.subplots(1,2,figsize=(12,5),constrained_layout=True)
 x=np.arange(4)
 for off,key,label,color in [(-.18,'NB_without_ATAC_NLL','Condition + sex','#3288bd'),(.18,'NB_with_ATAC_NLL','Condition + sex + ATAC','#d53e4f')]:
  axes[0].bar(x+off,[np.mean([float(a[key]) for a in pred if a['target']==t]) for t in targets],.36,label=label,color=color)
 axes[0].set_xticks(x,targets,rotation=25,ha='right');axes[0].set_ylabel('Held-out negative log likelihood (lower is better)');axes[0].legend();axes[0].set_title('Does ATAC improve RNA prediction?')
 corr=rd('joint_locus_partial_correlations.tsv');v=[float(x['partial_Pearson_r']) for x in corr if x['partial_Pearson_r']!='NA']
 axes[1].hist(v,bins=35,color='#3288bd');axes[1].axvline(0,color='#555',ls='--');axes[1].set_xlabel('Partial Pearson r after sex and condition adjustment');axes[1].set_ylabel('RNA-supported TE loci');axes[1].set_title('Exploratory locus-wise ATAC–RNA association')
 fig.suptitle('Gene-TMM RNA exposure; ATAC relative to each track genome-wide mean\nAssociation does not establish causality or autonomous TE transcription',fontsize=12);pdf.savefig(fig);plt.close(fig)
with (O/'matched_ATAC_RNA_group_summary.tsv').open('w',newline='') as f:
 wr=csv.DictWriter(f,fieldnames=list(summary[0]),delimiter='\t',lineterminator='\n');wr.writeheader();wr.writerows(summary)
print(summary)
