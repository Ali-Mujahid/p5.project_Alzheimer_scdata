args=commandArgs(trailingOnly=TRUE);o=args[1]
suppressPackageStartupMessages({library(MASS);library(jsonlite)})
rd=function(n)read.delim(file.path(o,n),check.names=FALSE)
put=function(x,n)write.table(x,file.path(o,n),sep='\t',quote=FALSE,row.names=FALSE,na='NA')
counts=function(n){x=rd(n);rownames(x)=x[,1];as.matrix(x[,-1])}
m=rd('model_exposures.tsv');rownames(m)=m$animal;m$condition=relevel(factor(m$condition),'WT_3mo');m$sex=factor(m$sex)
S=counts('set_counts.tsv');L=counts('locus_counts.tsv');A=counts('animal_TE_body_ATAC.tsv.gz');sets=rd('set_metadata.tsv');mem=rd('locus_membership.tsv')
stopifnot(identical(colnames(A),m$animal),identical(rownames(A),rownames(L)))
headers=fromJSON(file.path(o,'animal_bigwig_headers.json'),simplifyVector=FALSE)
bg=sapply(m$animal,function(a){stem=paste0('Microglia_',sub('_([12])$','_R\\1',a));h=headers[[stem]];stopifnot(h$nBasesCovered>0,h$sumData>0);h$sumData/h$nBasesCovered})
An=sweep(A,2,bg,'/');result=list();pred=list();sample=list()
for(sid in sets$set_id){
 ix=match(mem$locus[mem$set_id==sid],rownames(A));stopifnot(!anyNA(ix));a=An[ix,,drop=FALSE]
 if(any(!is.finite(a)))stop('Absent-chromosome signal must be handled explicitly')
 v=colMeans(a);target=sets$target[match(sid,sets$set_id)]
 dat=data.frame(m,y=as.numeric(S[sid,]),logATAC=log2(v+1),exposure=m$gene_effective_depth)
 for(i in 1:20)sample[[paste(sid,i)]]=data.frame(set_id=sid,target=target,set=sets$set[match(sid,sets$set_id)],animal=m$animal[i],condition=m$condition[i],relative_ATAC=v[i],RNA_gene_TMM_CPM=dat$y[i]/dat$exposure[i]*1e6)
 b=glm.nb(y~sex+condition+offset(log(exposure)),data=dat,control=glm.control(maxit=100))
 full=tryCatch(glm.nb(y~sex+condition+logATAC+offset(log(exposure)),data=dat,control=glm.control(maxit=100)),error=function(e)NULL)
 if(is.null(full)){result[[sid]]=data.frame(set_id=sid,coefficient=NA,p=NA,LR=NA,condition_number=NA);next}
 LR=max(0,2*as.numeric(logLik(full)-logLik(b)))
 result[[sid]]=data.frame(set_id=sid,coefficient=coef(full)['logATAC'],p=pchisq(LR,1,lower.tail=FALSE),LR=LR,condition_number=kappa(model.matrix(full)))
 if(sets$set[match(sid,sets$set_id)]=='target_only')for(i in 1:20){
  tr=dat[-i,];te=dat[i,,drop=FALSE]
  fit=function(f)tryCatch(glm.nb(f,data=tr,control=glm.control(maxit=100)),error=function(e)NULL)
  f0=fit(y~sex+condition+offset(log(exposure)));f1=fit(y~sex+condition+logATAC+offset(log(exposure)))
  nll=function(f)if(is.null(f))NA_real_ else -dnbinom(te$y,mu=predict(f,te,type='response'),size=f$theta,log=TRUE)
  pred[[paste(sid,i)]]=data.frame(set_id=sid,target=target,heldout=m$animal[i],NB_without_ATAC_NLL=nll(f0),NB_with_ATAC_NLL=nll(f1))
 }
}
r=do.call(rbind,result);r$BH_FDR=p.adjust(r$p,'BH');put(r,'joint_set_models.tsv');put(do.call(rbind,pred),'joint_heldout_prediction.tsv');put(do.call(rbind,sample),'joint_mouse_signals.tsv')
# Exploratory partial correlations on RNA-supported loci, after removing sex and condition.
keep=rd('locus_count_filter.tsv');ids=keep$locus[keep$retained];idx=match(ids,rownames(A))
rna=log1p(sweep(L[idx,,drop=FALSE],2,m$gene_effective_depth,'/')*1e6);atac=log1p(An[idx,,drop=FALSE])
X=model.matrix(~sex+condition,m);q=qr(X)
rr=t(qr.resid(q,t(rna)));ar=t(qr.resid(q,t(atac)))
rho=vapply(seq_along(ids),function(i)if(sd(rr[i,])>0&&sd(ar[i,])>0)cor(rr[i,],ar[i,])else NA_real_,numeric(1))
df=20-q$rank-1;p=2*pt(-abs(rho*sqrt(df/pmax(1e-15,1-rho^2))),df)
put(data.frame(locus=ids,partial_Pearson_r=rho,p_value=p,BH_FDR=p.adjust(p,'BH'),residual_test_df=df),'joint_locus_partial_correlations.tsv')
cat('Completed joint models and',length(ids),'exploratory RNA-supported partial correlations\n')
