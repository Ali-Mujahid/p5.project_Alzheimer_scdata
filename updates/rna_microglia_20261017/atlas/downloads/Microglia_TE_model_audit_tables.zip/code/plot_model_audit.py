import csv,json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
W=Path(__file__).resolve().parent;O=W/'results/model_audit'
read=lambda n:list(csv.DictReader((O/n).open(),delimiter='\t'))
results=read('aggregate_model_results.tsv');cv=read('heldout_prediction.tsv');loo=read('leave_one_mouse_out_effects.tsv');profiles=read('pooled_ATAC_profile_audit.tsv');ci=read('DESeq2_target_set_confidence_intervals.tsv')
targets=['WT_6mo','WT_21mo','5xFAD_3mo','APOE4_TREM2_3mo']
selected=[r for r in results if r['set']=='target_only']
for norm in ['gene_TMM','TE_TMM']:
 for model in ['edgeR','DESeq2']:
  records=[r for r in selected if r['normalization']==norm];p=np.array([float(r[model+'_p']) for r in records]);order=np.argsort(p);q=np.empty(4);q[order]=np.minimum(1,np.minimum.accumulate((p[order]*4/np.arange(1,5))[::-1])[::-1])
  for r,v in zip(records,q):r[model+'_primary4_FDR']=v
with (O/'primary_target_set_model_results.tsv').open('w',newline='') as f:
 wr=csv.DictWriter(f,fieldnames=list(selected[0]),delimiter='\t',lineterminator='\n');wr.writeheader();wr.writerows(selected)
summ=[]
for t in targets:
 a=[r for r in cv if r['target']==t];b=[float(r['NB_log2FC']) for r in loo if r['target']==t]
 summ.append({'target':t,'Poisson_mean_heldout_NLL':float(np.mean([float(r['Poisson_NLL']) for r in a])),
              'NB_mean_heldout_NLL':float(np.mean([float(r['NB_NLL']) for r in a])),
              'median_Poisson_overdispersion':float(np.median([float(r['Poisson_overdispersion']) for r in a])),
              'NB_LOO_min_log2FC':min(b),'NB_LOO_max_log2FC':max(b)})
with (O/'prediction_model_summary.tsv').open('w',newline='') as f:
 wr=csv.DictWriter(f,fieldnames=list(summ[0]),delimiter='\t',lineterminator='\n');wr.writeheader();wr.writerows(summ)
with PdfPages(O/'Microglia_TE_RNA_count_model_audit.pdf') as pdf:
 fig,axes=plt.subplots(1,2,figsize=(12,5.8),sharey=True,constrained_layout=True)
 for ax,norm,title in zip(axes,['gene_TMM','TE_TMM'],['Gene-derived TMM exposure','TE-derived TMM exposure']):
  for i,t in enumerate(targets):
   r=next(r for r in selected if r['normalization']==norm and r['target']==t)
   for offset,model,color,marker in [(-.08,'edgeR','#3288bd','o'),(.08,'DESeq2','#d53e4f','^')]:
    ax.scatter(2**float(r[model+'_log2FC']),i+offset,c=color,marker=marker,s=65,label=model if i==0 else None)
    if model=='DESeq2':
     c=next(c for c in ci if c['target']==t and c['normalization']==norm)
     ax.plot([float(c['lower95']),float(c['upper95'])],[i+offset,i+offset],color=color,lw=1.3)
   ax.text(1.23,i,f"edgeR q={float(r['edgeR_primary4_FDR']):.3f}\nDESeq2 q={float(r['DESeq2_primary4_FDR']):.3f}",fontsize=8,va='center')
  ax.set_xlim(.80,1.40);ax.axvline(1,color='#555',ls='--');ax.set_title(title);ax.set_xlabel('Estimated target / WT_3mo RNA fold change');ax.set_yticks(range(4),targets);ax.legend(loc='upper left');ax.grid(axis='x',alpha=.2)
 axes[0].invert_yaxis();fig.suptitle('Sex-adjusted negative-binomial models: same fixed target-only TE sets\n20 mice, 4 per condition; bars: DESeq2 95% Wald confidence intervals; blue points: edgeR QL estimates',fontsize=12)
 pdf.savefig(fig);fig.savefig(O/'Microglia_TE_RNA_count_model_audit.png',dpi=140);plt.close(fig)
 fig,axes=plt.subplots(1,2,figsize=(12,5),constrained_layout=True)
 x=np.arange(4)
 axes[0].bar(x-.18,[s['Poisson_mean_heldout_NLL'] for s in summ],.36,color='#999',label='Poisson')
 axes[0].bar(x+.18,[s['NB_mean_heldout_NLL'] for s in summ],.36,color='#3288bd',label='Negative binomial')
 axes[0].set_xticks(x,targets,rotation=25,ha='right');axes[0].set_ylabel('Mean held-out negative log likelihood (lower is better)');axes[0].legend();axes[0].set_title('Leave-one-mouse-out prediction')
 for i,t in enumerate(targets):
  vals=np.array([float(r['NB_log2FC']) for r in loo if r['target']==t]);axes[1].scatter(i+np.linspace(-.09,.09,len(vals)),vals,s=20,color='#3288bd')
 axes[1].axhline(0,color='#555',ls='--');axes[1].set_xticks(x,targets,rotation=25,ha='right');axes[1].set_ylabel('Estimated RNA log2 fold change');axes[1].set_title('Effect sensitivity to omitting one mouse')
 fig.suptitle('Model-class and sample-sensitivity audit; gene-derived exposure and sex adjustment',fontsize=12);pdf.savefig(fig);plt.close(fig)
 fig,axes=plt.subplots(1,2,figsize=(12,5),constrained_layout=True)
 ratio=[];enrich=[]
 for t in targets:
  group=t+('_original' if t in ['WT_6mo','APOE4_TREM2_3mo'] else '_stable')
  c=next(r for r in profiles if r['sample']=='WT_3mo' and r['set']==group)
  a=next(r for r in profiles if r['sample']==t and r['set']==group)
  ratio.append(float(a['center_200bp'])/float(c['center_200bp']))
  enrich.append(float(a['center_over_flank'])/float(c['center_over_flank']))
 axes[0].bar(x-.18,ratio,.36,label='Central 200 bp signal',color='#3288bd');axes[0].bar(x+.18,enrich,.36,label='Centre / flank ratio',color='#d53e4f')
 axes[0].axhline(1,color='#555',ls='--');axes[0].set_xticks(x,targets,rotation=25,ha='right');axes[0].set_ylabel('Target / WT_3mo ATAC ratio');axes[0].legend();axes[0].set_title('Pooled ATAC profiles: descriptive signal')
 loc=read('locus_model_summary.tsv')
 n=[next(r for r in loc if r['target']==t and r['set']=='target_only' and r['normalization']=='gene_TMM')['tested_loci'] for t in targets]
 total=[next(r for r in selected if r['target']==t and r['normalization']=='gene_TMM')['n_loci'] for t in targets]
 axes[1].bar(x,[int(n)/int(a)*100 for n,a in zip(n,total)],color='#3288bd');axes[1].set_xticks(x,targets,rotation=25,ha='right');axes[1].set_ylabel('Loci meeting RNA count criterion (%)');axes[1].set_title('Count ≥5 in at least four of the 20 mice')
 for i,(nn,tt) in enumerate(zip(n,total)):axes[1].text(i,int(nn)/int(tt)*100+.04,f'{nn}/{tt}',ha='center',fontsize=9)
 fig.suptitle('ATAC accessibility and RNA count support measure different properties',fontsize=12);pdf.savefig(fig);plt.close(fig)
print('Wrote model comparisons, prediction audit and RNA support plots')
