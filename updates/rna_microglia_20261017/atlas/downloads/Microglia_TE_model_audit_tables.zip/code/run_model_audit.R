args=commandArgs(trailingOnly=TRUE);stopifnot(length(args)==2)
o=args[1];root=args[2]
suppressPackageStartupMessages({library(edgeR);library(DESeq2);library(rhdf5);library(MASS)})
read=function(n)read.delim(file.path(o,n),check.names=FALSE)
put=function(x,n)write.table(x,file.path(o,n),sep='\t',quote=FALSE,row.names=FALSE,na='NA')
m=read('mouse_metadata.tsv');rownames(m)=m$animal;m$condition=relevel(factor(m$condition),'WT_3mo');m$sex=factor(m$sex)
sets=read('set_metadata.tsv');membership=read('locus_membership.tsv')
getcounts=function(n){z=read(n);rownames(z)=z[,1];z=as.matrix(z[,-1]);storage.mode(z)='integer';stopifnot(identical(colnames(z),m$animal));z}
S=getcounts('set_counts.tsv');L=getcounts('locus_counts.tsv')
p=file.path(root,'work/TE_cCRE_gene_linkage_20261024/inputs/mouse_cluster_gene_pseudobulk.h5')
G=h5read(p,'Microglia22251_mouse_gene_counts');ga=sort(unique(h5read(p,'group_animal_id')));stopifnot(all(dim(G)==c(55487,20)));colnames(G)=ga;G=G[,m$animal]
d=read.delim(file.path(root,'work/TE_cCRE_gene_linkage_20261024/inputs/Microglia22251_mouse_raw_gene_depth.tsv'))
stopifnot(identical(as.numeric(colSums(G)),as.numeric(d$raw_gene_UMI_sum[match(m$animal,d$animal_id)])))
gene=DGEList(G);gene=calcNormFactors(gene,method='TMM');ge=gene$samples$lib.size*gene$samples$norm.factors
te=read.delim(file.path(root,'work/MAnorm_targetTE_RNA_20261028/results/normalization_audit/TE_TMM_factors.tsv'))
te=te[match(m$animal,te$animal),];stopifnot(all(te$total_assigned_TE_UMIs==m$TE_UMIs));teff=te$TMM_effective_TE_library
put(data.frame(m,gene_depth=colSums(G),gene_TMM_factor=gene$samples$norm.factors,gene_effective_depth=ge,TE_effective_depth=teff),'model_exposures.tsv')
design=model.matrix(~sex+condition,m);stopifnot(qr(design)$rank==ncol(design))
keep=rowSums(L>=5)>=4
put(data.frame(locus=rownames(L),retained=keep,total_counts=rowSums(L),mice_at_least_5=rowSums(L>=5)),'locus_count_filter.tsv')
targets=c('WT_6mo','WT_21mo','5xFAD_3mo','APOE4_TREM2_3mo')
allset=list();lsummary=list();agree=list()
for(norm in c('gene_TMM','TE_TMM')){
 expo=if(norm=='gene_TMM')ge else teff
 for(scope in c('sets','loci')){
  Y=if(scope=='sets')S else L[keep,,drop=FALSE]
  y=DGEList(Y,lib.size=expo);y=estimateDisp(y,design,robust=TRUE,trend.method=if(scope=='sets')'none' else 'locfit')
  fit=glmQLFit(y,design,robust=TRUE,abundance.trend=scope!='sets')
  dd=DESeqDataSetFromMatrix(Y,m,~sex+condition);sizeFactors(dd)=expo/exp(mean(log(expo)))
  dd=DESeq(dd,fitType=if(scope=='sets')'mean' else 'parametric',minReplicatesForReplace=Inf,quiet=TRUE,parallel=FALSE)
  for(t in targets){
   coef=match(paste0('condition',t),colnames(design));stopifnot(!is.na(coef))
   er=topTags(glmQLFTest(fit,coef=coef),n=Inf,sort.by='none')$table
   dr=as.data.frame(results(dd,contrast=c('condition',t,'WT_3mo'),independentFiltering=FALSE))
   z=data.frame(id=rownames(Y),target=t,normalization=norm,edgeR_log2FC=er$logFC,edgeR_p=er$PValue,edgeR_FDR=er$FDR,
                DESeq2_log2FC=dr$log2FoldChange,DESeq2_p=dr$pvalue,DESeq2_FDR=dr$padj,
                DESeq2_converged=mcols(dd)$betaConv,DESeq2_max_Cooks=apply(assays(dd)[['cooks']],1,max))
   if(scope=='sets'){
    z=merge(sets,z,by.x='set_id',by.y='id',sort=FALSE);z=z[z$target.x==t,];z$target=z$target.x;z$target.x=NULL;z$target.y=NULL
    allset[[paste(norm,t)]]=z
   }else{
    gz=gzfile(file.path(o,paste0('loci_',norm,'_',t,'.tsv.gz')),'wt');write.table(z,gz,sep='\t',quote=FALSE,row.names=FALSE);close(gz)
    for(kind in c('target_only','WT_3mo_only','target_stable')){
     key=sets$set_id[sets$target==t & sets$set==kind];if(!length(key))next
     ix=match(membership$locus[membership$set_id==key],z$id);ix=ix[!is.na(ix)];a=z[ix,]
     lsummary[[paste(norm,t,kind)]]=data.frame(target=t,set=kind,normalization=norm,tested_loci=nrow(a),
       edgeR_up_q10=sum(a$edgeR_FDR<.1&a$edgeR_log2FC>0,na.rm=TRUE),edgeR_down_q10=sum(a$edgeR_FDR<.1&a$edgeR_log2FC<0,na.rm=TRUE),
       DESeq2_up_q10=sum(a$DESeq2_FDR<.1&a$DESeq2_log2FC>0,na.rm=TRUE),DESeq2_down_q10=sum(a$DESeq2_FDR<.1&a$DESeq2_log2FC<0,na.rm=TRUE),
       effect_spearman=cor(a$edgeR_log2FC,a$DESeq2_log2FC,method='spearman',use='complete.obs'),DESeq2_nonconverged=sum(!a$DESeq2_converged))
    }
   }
  }
  put(data.frame(id=rownames(Y),edgeR_dispersion=y$tagwise.dispersion,DESeq2_dispersion=dispersions(dd),DESeq2_converged=mcols(dd)$betaConv),paste0(scope,'_',norm,'_fit_diagnostics.tsv'))
 }
}
z=do.call(rbind,allset);z$edgeR_FDR_matched_tests=p.adjust(z$edgeR_p,'BH');z$DESeq2_FDR_matched_tests=p.adjust(z$DESeq2_p,'BH');put(z,'aggregate_model_results.tsv')
put(do.call(rbind,lsummary),'locus_model_summary.tsv')
# Held-out mouse prediction on the four target-defined set totals, identical gene-TMM exposures.
cv=list();stability=list()
for(sid in sets$set_id[sets$set=='target_only']){
 target=sets$target[match(sid,sets$set_id)];dat=data.frame(m,y=as.numeric(S[sid,]),exposure=ge)
 for(i in seq_len(nrow(m))){
  train=dat[-i,];test=dat[i,,drop=FALSE]
  pois=glm(y~sex+condition+offset(log(exposure)),data=train,family=poisson())
  nb=tryCatch(glm.nb(y~sex+condition+offset(log(exposure)),data=train,control=glm.control(maxit=100)),error=function(e)NULL)
  mp=predict(pois,test,type='response');pn=-dpois(test$y,mp,log=TRUE)
  nn=if(is.null(nb))NA_real_ else -dnbinom(test$y,mu=predict(nb,test,type='response'),size=nb$theta,log=TRUE)
  cv[[paste(sid,i)]]=data.frame(set_id=sid,target=target,held_out=test$animal,Poisson_NLL=pn,NB_NLL=nn,
                              Poisson_overdispersion=sum(residuals(pois,type='pearson')^2)/pois$df.residual,
                              NB_theta=if(is.null(nb))NA_real_ else nb$theta)
  coefname=paste0('condition',target)
  stability[[paste(sid,i)]]=data.frame(set_id=sid,target=target,held_out=test$animal,NB_log2FC=if(is.null(nb))NA_real_ else coef(nb)[coefname]/log(2))
 }
}
put(do.call(rbind,cv),'heldout_prediction.tsv');put(do.call(rbind,stability),'leave_one_mouse_out_effects.tsv')
capture.output(sessionInfo(),file=file.path(o,'R_sessionInfo.txt'))
cat('DONE: gene- and TE-TMM exposures; edgeR QL and DESeq2; retained loci',sum(keep),'of',nrow(L),'\n')
